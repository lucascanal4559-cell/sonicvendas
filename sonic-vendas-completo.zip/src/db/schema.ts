import { pgTable, serial, text, integer, boolean, timestamp, decimal, varchar, jsonb } from "drizzle-orm/pg-core";

export const categories = pgTable("categories", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  slug: varchar("slug", { length: 255 }).notNull().unique(),
  description: text("description"),
  isActive: boolean("is_active").default(true).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const products = pgTable("products", {
  id: serial("id").primaryKey(),
  title: varchar("title", { length: 255 }).notNull(),
  slug: varchar("slug", { length: 255 }).notNull().unique(),
  description: text("description").notNull(),
  price: decimal("price", { precision: 10, scale: 2 }).notNull(),
  originalPrice: decimal("original_price", { precision: 10, scale: 2 }),
  categoryId: integer("category_id").references(() => categories.id, { onDelete: "set null" }),
  imageUrl: text("image_url").notNull(),
  images: text("images").array(),
  isActive: boolean("is_active").default(true).notNull(),
  isPromotion: boolean("is_promotion").default(false).notNull(),
  discountPercent: integer("discount_percent").default(0),
  availability: text("availability").default("available"), // available, out_of_stock, pre_order
  hasWarranty: varchar("has_warranty", { length: 100 }).default("sim_loja").notNull(), // sim_loja, sim_fabricante, nao, sim_vitalicia
  warrantyDuration: varchar("warranty_duration", { length: 100 }).default("90 dias de garantia oficial"),
  warrantyConditions: text("warranty_conditions"),
  returnConditions: text("return_conditions"),
  specifications: text("specifications"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const banners = pgTable("banners", {
  id: serial("id").primaryKey(),
  title: varchar("title", { length: 255 }).notNull(),
  subtitle: text("subtitle"),
  imageUrl: text("image_url").notNull(),
  linkUrl: text("link_url"),
  isActive: boolean("is_active").default(true).notNull(),
  order: integer("order").default(0).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const orders = pgTable("orders", {
  id: serial("id").primaryKey(),
  customerName: varchar("customer_name", { length: 255 }).notNull(),
  customerEmail: varchar("customer_email", { length: 255 }).notNull(),
  customerPhone: varchar("customer_phone", { length: 50 }),
  customerAddress: text("customer_address"),
  items: jsonb("items").notNull(), // array of { productId, title, price, qty }
  totalAmount: decimal("total_amount", { precision: 10, scale: 2 }).notNull(),
  status: varchar("status", { length: 50 }).default("pending").notNull(), // pending, approved, rejected, refunded, preparing, shipped, delivered, cancelled
  paymentMethod: varchar("payment_method", { length: 50 }).default("mercadopago"),
  paymentId: varchar("payment_id", { length: 255 }),
  receiptUrl: text("receipt_url"), // comprovante pix
  isPaid: boolean("is_paid").default(false).notNull(),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const pixReceipts = pgTable("pix_receipts", {
  id: serial("id").primaryKey(),
  orderId: integer("order_id").references(() => orders.id, { onDelete: "cascade" }),
  customerName: varchar("customer_name", { length: 255 }).notNull(),
  customerEmail: varchar("customer_email", { length: 255 }).notNull(),
  customerPhone: varchar("customer_phone", { length: 50 }),
  receiptUrl: text("receipt_url").notNull(),
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  status: varchar("status", { length: 50 }).default("pending").notNull(), // pending, approved, rejected
  rejectionReason: text("rejection_reason"),
  reviewedBy: varchar("reviewed_by", { length: 255 }),
  reviewedAt: timestamp("reviewed_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const siteAnnouncements = pgTable("site_announcements", {
  id: serial("id").primaryKey(),
  title: varchar("title", { length: 255 }).notNull(),
  message: text("message").notNull(),
  imageUrl: text("image_url"),
  color: varchar("color", { length: 50 }).default("#f59e0b").notNull(),
  icon: varchar("icon", { length: 50 }).default("bell").notNull(),
  buttonText: varchar("button_text", { length: 100 }),
  buttonUrl: text("button_url"),
  location: varchar("location", { length: 50 }).default("top_bar").notNull(), // top_bar, home_banner, popup_modal, alert_box
  priority: integer("priority").default(1).notNull(),
  targetAudience: varchar("target_audience", { length: 50 }).default("all").notNull(), // all, logged_in
  isClosable: boolean("is_closable").default(true).notNull(),
  isActive: boolean("is_active").default(true).notNull(),
  startDate: timestamp("start_date").defaultNow().notNull(),
  endDate: timestamp("end_date"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const futureFeatures = pgTable("future_features", {
  id: serial("id").primaryKey(),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description").notNull(),
  category: varchar("category", { length: 100 }).default("geral").notNull(),
  aiGeneratedPlan: text("ai_generated_plan"), // Plano / especificação gerada por IA
  status: varchar("status", { length: 50 }).default("planned").notNull(), // planned, in_progress, launched, idea
  priority: varchar("priority", { length: 50 }).default("medium").notNull(), // low, medium, high, urgent
  createdBy: varchar("created_by", { length: 255 }).default("admin").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const adminUsers = pgTable("admin_users", {
  id: serial("id").primaryKey(),
  username: varchar("username", { length: 255 }).notNull().unique(),
  passwordHash: text("password_hash").notNull(),
  role: varchar("role", { length: 50 }).default("admin").notNull(),
  isActive: boolean("is_active").default(true).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const customers = pgTable("customers", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  email: varchar("email", { length: 255 }).notNull().unique(),
  phone: varchar("phone", { length: 50 }),
  passwordHash: text("password_hash").notNull(),
  profileImage: text("profile_image"),
  isActive: boolean("is_active").default(true).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const groups = pgTable("groups", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  description: text("description"),
  imageUrl: text("image_url"),
  linkUrl: text("link_url"),
  platform: varchar("platform", { length: 50 }).default("whatsapp").notNull(), // whatsapp, telegram, discord
  category: varchar("category", { length: 100 }).default("vendas").notNull(), // vendas, games, cripto, afiliados, amizade, emprego, geral
  fee: decimal("fee", { precision: 10, scale: 2 }).default("10.00").notNull(),
  monthlyFee: decimal("monthly_fee", { precision: 10, scale: 2 }).default("10.00").notNull(), // R$ 10 mensais para manter ativo
  freeMinutes: integer("free_minutes").default(60).notNull(), // cortesia grátis definida pelo admin
  premiumPeriod: integer("premium_period").default(30), // dias de divulgação premium
  premiumPrice: decimal("premium_price", { precision: 10, scale: 2 }).default("30.00"),
  ownerId: integer("owner_id").references(() => customers.id, { onDelete: "cascade" }),
  isActive: boolean("is_active").default(true).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const socialOrders = pgTable("social_orders", {
  id: serial("id").primaryKey(),
  customerName: varchar("customer_name", { length: 255 }).notNull(),
  customerEmail: varchar("customer_email", { length: 255 }),
  customerPhone: varchar("customer_phone", { length: 50 }).notNull(),
  network: varchar("network", { length: 50 }).notNull(), // instagram, tiktok, kwai, youtube, facebook, freefire, spotify, threads, twitter
  serviceName: varchar("service_name", { length: 255 }).notNull(),
  targetHandleOrLink: varchar("target_handle_or_link", { length: 255 }).notNull(), // @usuario ou link da publicação/perfil ou ID Free Fire
  quantity: varchar("quantity", { length: 100 }).notNull(),
  totalAmount: decimal("total_amount", { precision: 10, scale: 2 }).notNull(),
  paymentMethod: varchar("payment_method", { length: 50 }).default("pix").notNull(), // pix, credit_card, debit_card
  receiptUrl: text("receipt_url"),
  status: varchar("status", { length: 50 }).default("pending").notNull(), // pending, approved, processing, completed, cancelled
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const groupPremiumConfigs = pgTable("group_premium_configs", {
  id: serial("id").primaryKey(),
  days: integer("days").notNull().unique(),
  price: decimal("price", { precision: 10, scale: 2 }).notNull(),
  isActive: boolean("is_active").default(true).notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const sponsors = pgTable("sponsors", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  description: text("description"),
  imageUrl: text("image_url"),
  linkUrl: text("link_url"),
  weeklyPrice: decimal("weekly_price", { precision: 10, scale: 2 }).default("40.00").notNull(),
  monthlyPrice: decimal("monthly_price", { precision: 10, scale: 2 }).default("80.00").notNull(),
  period: varchar("period", { length: 50 }).default("monthly"),
  isActive: boolean("is_active").default(true).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const notifications = pgTable("notifications", {
  id: serial("id").primaryKey(),
  title: varchar("title", { length: 255 }).notNull(),
  message: text("message"),
  isActive: boolean("is_active").default(true).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const publications = pgTable("publications", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  description: text("description"),
  imageUrl: text("image_url"),
  videoUrl: text("video_url"),
  linkUrl: text("link_url"),
  contactPhone: text("contact_phone"),
  contactEmail: text("contact_email"),
  days: integer("days").default(1).notNull(),
  price: decimal("price", { precision: 10, scale: 2 }).default("1.00").notNull(),
  status: varchar("status", { length: 50 }).default("pending").notNull(),
  customerId: integer("customer_id").references(() => customers.id, { onDelete: "cascade" }),
  startDate: timestamp("start_date"),
  endDate: timestamp("end_date"),
  isActive: boolean("is_active").default(true).notNull(),
  isTop: boolean("is_top").default(false).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const contactAds = pgTable("contact_ads", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  age: varchar("age", { length: 50 }),
  profilePhoto: text("profile_photo"),
  videoUrl: text("video_url"), // Vídeo de até 2 minutos
  description: text("description").notNull(),
  phone: varchar("phone", { length: 50 }).notNull(),
  email: varchar("email", { length: 255 }),
  contactLink: text("contact_link"),
  city: varchar("city", { length: 150 }),
  days: integer("days").default(7).notNull(), // R$ 1,00 por dia
  price: decimal("price", { precision: 10, scale: 2 }).default("7.00").notNull(),
  status: varchar("status", { length: 50 }).default("pending").notNull(), // pending, approved, rejected, active, expired
  viewsCount: integer("views_count").default(0).notNull(),
  clicksWhatsapp: integer("clicks_whatsapp").default(0).notNull(),
  clicksLink: integer("clicks_link").default(0).notNull(),
  isBoosted: boolean("is_boosted").default(false).notNull(),
  boostExpiresAt: timestamp("boost_expires_at"),
  receiptUrl: text("receipt_url"),
  startDate: timestamp("start_date"),
  endDate: timestamp("end_date"),
  isActive: boolean("is_active").default(true).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const businessAds = pgTable("business_ads", {
  id: serial("id").primaryKey(),
  businessName: varchar("business_name", { length: 255 }).notNull(),
  adTitle: varchar("ad_title", { length: 255 }).notNull(),
  description: text("description").notNull(),
  category: varchar("category", { length: 100 }).default("loja").notNull(), // loja, produto, servico, promocao, marca, empresa, site, projeto
  photoUrl: text("photo_url"),
  videoUrl: text("video_url"), // Vídeo de até 2 minutos
  productPrice: decimal("product_price", { precision: 10, scale: 2 }),
  buyLink: text("buy_link"),
  phone: varchar("phone", { length: 50 }).notNull(),
  email: varchar("email", { length: 255 }),
  location: varchar("location", { length: 150 }),
  days: integer("days").default(15).notNull(),
  calculatedPrice: decimal("calculated_price", { precision: 10, scale: 2 }).default("45.00").notNull(),
  aiPricingBreakdown: text("ai_pricing_breakdown"), // Explicação detalhada gerada pela IA
  adminApprovedPrice: decimal("admin_approved_price", { precision: 10, scale: 2 }),
  status: varchar("status", { length: 50 }).default("pending").notNull(), // pending, approved, rejected, active, expired
  viewsCount: integer("views_count").default(0).notNull(),
  clicksWhatsapp: integer("clicks_whatsapp").default(0).notNull(),
  clicksLink: integer("clicks_link").default(0).notNull(),
  clicksBuy: integer("clicks_buy").default(0).notNull(),
  isBoosted: boolean("is_boosted").default(false).notNull(),
  boostPlan: varchar("boost_plan", { length: 100 }), // topo_3d, topo_7d, ouro_15d, maximo_30d
  boostExpiresAt: timestamp("boost_expires_at"),
  receiptUrl: text("receipt_url"),
  startDate: timestamp("start_date"),
  endDate: timestamp("end_date"),
  isActive: boolean("is_active").default(true).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const adBoostOrders = pgTable("ad_boost_orders", {
  id: serial("id").primaryKey(),
  adType: varchar("ad_type", { length: 50 }).notNull(), // contact | business
  adId: integer("ad_id").notNull(),
  customerName: varchar("customer_name", { length: 255 }).notNull(),
  customerPhone: varchar("customer_phone", { length: 50 }).notNull(),
  planName: varchar("plan_name", { length: 100 }).notNull(), // topo_3d, topo_7d, ouro_15d, maximo_30d
  days: integer("days").notNull(),
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  paymentMethod: varchar("payment_method", { length: 50 }).default("pix").notNull(),
  receiptUrl: text("receipt_url"),
  status: varchar("status", { length: 50 }).default("pending").notNull(), // pending, approved, rejected
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const iptvRequests = pgTable("iptv_requests", {
  id: serial("id").primaryKey(),
  customerName: varchar("customer_name", { length: 255 }).notNull(),
  customerEmail: varchar("customer_email", { length: 255 }).notNull(),
  customerPhone: varchar("customer_phone", { length: 50 }).notNull(),
  status: varchar("status", { length: 50 }).default("pending").notNull(), // pending, approved, expired, revoked
  hours: integer("hours").default(12).notNull(),
  serverUrl: text("server_url"),
  username: varchar("username", { length: 255 }),
  password: varchar("password", { length: 255 }),
  m3uUrl: text("m3u_url"),
  instructions: text("instructions"),
  approvedAt: timestamp("approved_at"),
  expiresAt: timestamp("expires_at"),
  adminNotes: text("admin_notes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const raffles = pgTable("raffles", {
  id: serial("id").primaryKey(),
  title: varchar("title", { length: 255 }).notNull(),
  slug: varchar("slug", { length: 255 }).notNull().unique(),
  description: text("description").notNull(),
  imageUrl: text("image_url").notNull(),
  category: varchar("category", { length: 100 }).default("celular").notNull(), // celular, computador, notebook, geladeira, eletrodomesticos, viagens, dinheiro, outros
  totalNumbers: integer("total_numbers").default(1000).notNull(), // 1000, 2000, 5000, 10000...
  pricePerNumber: decimal("price_per_number", { precision: 10, scale: 2 }).default("0.10").notNull(), // R$ 0.10, R$ 0.01 etc
  numbersSold: integer("numbers_sold").default(0).notNull(),
  startDate: timestamp("start_date").defaultNow().notNull(),
  endDate: timestamp("end_date"),
  drawDate: timestamp("draw_date"), // data prevista para apuração
  regulation: text("regulation"),
  instagramLiveUrl: text("instagram_live_url"),
  drawMethod: varchar("draw_method", { length: 100 }).default("loteria_federal").notNull(), // loteria_federal, live_sorteador
  lotteryContestNumber: varchar("lottery_contest_number", { length: 100 }), // Concurso da Loteria Federal
  lotteryDrawnNumbers: text("lottery_drawn_numbers"), // Números do sorteio oficial
  status: varchar("status", { length: 50 }).default("open").notNull(), // draft, pending_approval, open, closed, drawn, cancelled
  winnerCode: varchar("winner_code", { length: 50 }),
  winnerName: varchar("winner_name", { length: 255 }),
  winnerPhoneMasked: varchar("winner_phone_masked", { length: 50 }),
  isFeatured: boolean("is_featured").default(true).notNull(),
  isActive: boolean("is_active").default(true).notNull(),
  revealedBy: varchar("revealed_by", { length: 255 }),
  revealedAt: timestamp("revealed_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const raffleParticipations = pgTable("raffle_participations", {
  id: serial("id").primaryKey(),
  raffleId: integer("raffle_id").references(() => raffles.id, { onDelete: "cascade" }).notNull(),
  customerName: varchar("customer_name", { length: 255 }).notNull(),
  customerEmail: varchar("customer_email", { length: 255 }).notNull(),
  customerPhone: varchar("customer_phone", { length: 50 }).notNull(),
  quantity: integer("quantity").notNull(),
  totalAmount: decimal("total_amount", { precision: 10, scale: 2 }).notNull(),
  ticketCodes: jsonb("ticket_codes").notNull(), // array of strings ["0012", "0482", ...]
  status: varchar("status", { length: 50 }).default("approved").notNull(), // pending, approved, cancelled
  paymentMethod: varchar("payment_method", { length: 50 }).default("mercadopago"),
  paymentId: varchar("payment_id", { length: 255 }),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const raffleTickets = pgTable("raffle_tickets", {
  id: serial("id").primaryKey(),
  raffleId: integer("raffle_id").references(() => raffles.id, { onDelete: "cascade" }).notNull(),
  participationId: integer("participation_id").references(() => raffleParticipations.id, { onDelete: "cascade" }),
  ticketNumber: integer("ticket_number").notNull(), // 1, 2, 3 ...
  ticketCode: varchar("ticket_code", { length: 50 }).notNull(), // "0001", "0482"
  customerName: varchar("customer_name", { length: 255 }).notNull(),
  customerEmail: varchar("customer_email", { length: 255 }).notNull(),
  customerPhone: varchar("customer_phone", { length: 50 }).notNull(),
  isWinner: boolean("is_winner").default(false).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const roulettePrizes = pgTable("roulette_prizes", {
  id: serial("id").primaryKey(),
  title: varchar("title", { length: 255 }).notNull(),
  prizeType: varchar("prize_type", { length: 50 }).notNull(), // discount_coupon, bonus_cota, extra_points, perk
  value: varchar("value", { length: 255 }).notNull(),
  couponCode: varchar("coupon_code", { length: 100 }),
  probability: integer("probability").default(10).notNull(),
  color: varchar("color", { length: 50 }).default("#06b6d4").notNull(),
  isActive: boolean("is_active").default(true).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const rouletteSpins = pgTable("roulette_spins", {
  id: serial("id").primaryKey(),
  customerName: varchar("customer_name", { length: 255 }).notNull(),
  customerEmail: varchar("customer_email", { length: 255 }).notNull(),
  customerPhone: varchar("customer_phone", { length: 50 }),
  prizeWon: varchar("prize_won", { length: 255 }).notNull(),
  prizeCode: varchar("prize_code", { length: 100 }),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const siteConfig = pgTable("site_config", {
  id: serial("id").primaryKey(),
  key: varchar("key", { length: 255 }).notNull().unique(),
  value: text("value").notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});
