import { NextResponse } from "next/server";
import type { NextRequest } from "next/server";

export function middleware(request: NextRequest) {
  const host = request.headers.get("host") || "";
  const { pathname } = request.nextUrl;

  // Check if request is coming from the admin domain (sonicvendasadm.app or subdomains)
  const isAdminDomain =
    host.includes("sonicvendasadm") ||
    host.startsWith("adm.") ||
    host.startsWith("admin.");

  if (isAdminDomain) {
    // If root path on admin domain, rewrite seamlessly to /admin
    if (pathname === "/") {
      const url = request.nextUrl.clone();
      url.pathname = "/admin";
      return NextResponse.rewrite(url);
    }
    // If /login on admin domain, rewrite to /admin/login
    if (pathname === "/login") {
      const url = request.nextUrl.clone();
      url.pathname = "/admin/login";
      return NextResponse.rewrite(url);
    }
  }

  return NextResponse.next();
}

export const config = {
  matcher: [
    /*
     * Match all request paths except static assets
     */
    "/((?!_next/static|_next/image|favicon.ico|images/).*)",
  ],
};
