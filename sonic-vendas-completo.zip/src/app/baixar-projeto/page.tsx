"use client";
import React, { useState } from "react";
import Link from "next/link";
import {
  Download,
  ArrowLeft,
  FileArchive,
  CheckCircle2,
  Server,
  Database,
  Globe,
  ShieldCheck,
  Terminal,
  ExternalLink,
} from "lucide-react";

export default function BaixarProjetoPage() {
  const [downloading, setDownloading] = useState(false);

  return (
    <main className="min-h-screen bg-[#040817] text-slate-100 selection:bg-amber-400 selection:text-black px-4 py-8 md:px-6 md:py-12">
      <div className="mx-auto max-w-4xl">
        <Link
          href="/"
          className="inline-flex items-center gap-2 text-sm font-bold text-amber-400 hover:text-amber-300 transition-colors mb-6"
        >
          <ArrowLeft size={18} /> Voltar à Loja
        </Link>

        {/* Header */}
        <div className="rounded-3xl border-2 border-amber-400/50 bg-gradient-to-b from-slate-950 via-slate-900 to-slate-950 p-6 md:p-10 shadow-2xl backdrop-blur-xl">
          <div className="flex flex-col md:flex-row items-center justify-between gap-6 border-b border-slate-800 pb-8">
            <div className="flex items-center gap-4">
              <div className="flex h-16 w-16 shrink-0 items-center justify-center rounded-2xl bg-gradient-to-tr from-amber-500 to-orange-400 text-slate-950 text-3xl font-black shadow-lg shadow-amber-400/30">
                <FileArchive size={34} />
              </div>
              <div>
                <span className="text-[10px] font-black uppercase tracking-widest text-amber-400">
                  PACOTE COMPLETO DE HOSPEDAGEM
                </span>
                <h1 className="text-2xl md:text-3xl font-black text-white">
                  Download do Projeto Sonic Vendas
                </h1>
                <p className="text-xs text-slate-400 mt-1">
                  Arquivo: <code className="text-amber-300 font-mono">sonic-vendas-completo.zip</code> (~700 KB) • Pronto para Vercel, Hostinger, VPS, Railway, etc.
                </p>
              </div>
            </div>

            <a
              href="/api/download/zip"
              download="sonic-vendas-completo.zip"
              onClick={() => setDownloading(true)}
              className="flex shrink-0 items-center gap-2 rounded-2xl bg-gradient-to-r from-amber-400 via-orange-400 to-amber-300 px-8 py-4 text-sm font-black uppercase tracking-wider text-slate-950 shadow-xl shadow-amber-400/30 hover:brightness-110 hover:scale-105 transition-all"
            >
              <Download size={20} />
              {downloading ? "Baixando ZIP..." : "BAIXAR PROJETO EM ZIP"}
            </a>
          </div>

          {/* Quick Setup Instructions */}
          <div className="mt-8 space-y-6">
            <h3 className="text-base font-black text-white flex items-center gap-2">
              <Server className="text-cyan-400" size={18} />
              Passo a Passo Rápido para Hospedar:
            </h3>

            <div className="grid gap-4 md:grid-cols-3 text-xs text-slate-300">
              <div className="rounded-2xl bg-slate-950 p-5 border border-slate-800 space-y-2">
                <span className="flex h-7 w-7 items-center justify-center rounded-lg bg-amber-400 text-slate-950 font-black text-xs">
                  1
                </span>
                <h4 className="font-bold text-white text-sm">Instalar Dependências</h4>
                <p className="text-slate-400">
                  Extraia o ZIP no seu servidor e execute:
                </p>
                <code className="block rounded-lg bg-slate-900 p-2 font-mono text-[11px] text-amber-300">
                  npm install
                </code>
              </div>

              <div className="rounded-2xl bg-slate-950 p-5 border border-slate-800 space-y-2">
                <span className="flex h-7 w-7 items-center justify-center rounded-lg bg-cyan-400 text-slate-950 font-black text-xs">
                  2
                </span>
                <h4 className="font-bold text-white text-sm">Configurar Banco PostgreSQL</h4>
                <p className="text-slate-400">
                  Configure o <code className="text-cyan-300">.env</code> e crie as tabelas com:
                </p>
                <code className="block rounded-lg bg-slate-900 p-2 font-mono text-[11px] text-cyan-300">
                  npx drizzle-kit push
                </code>
              </div>

              <div className="rounded-2xl bg-slate-950 p-5 border border-slate-800 space-y-2">
                <span className="flex h-7 w-7 items-center justify-center rounded-lg bg-emerald-400 text-slate-950 font-black text-xs">
                  3
                </span>
                <h4 className="font-bold text-white text-sm">Iniciar em Produção</h4>
                <p className="text-slate-400">
                  Compile e inicie o servidor:
                </p>
                <code className="block rounded-lg bg-slate-900 p-2 font-mono text-[11px] text-emerald-300">
                  npm run build && npm start
                </code>
              </div>
            </div>

            {/* Domains & Credentials Recap */}
            <div className="rounded-2xl border border-slate-800 bg-slate-950/80 p-5 space-y-3">
              <h4 className="text-xs font-black uppercase text-amber-400 flex items-center gap-1.5">
                <Globe size={15} /> Domínios e Acessos Padrão Configurados:
              </h4>

              <div className="grid gap-3 sm:grid-cols-2 text-xs">
                <div className="rounded-xl bg-slate-900 p-3 border border-slate-800">
                  <span className="text-[10px] text-slate-400 block uppercase font-bold">Domínio dos Clientes:</span>
                  <span className="font-bold text-white font-mono">https://sonicvendas.app</span>
                </div>

                <div className="rounded-xl bg-slate-900 p-3 border border-slate-800">
                  <span className="text-[10px] text-slate-400 block uppercase font-bold">Domínio do Administrador:</span>
                  <span className="font-bold text-white font-mono">https://sonicvendasadm.app</span>
                </div>

                <div className="rounded-xl bg-slate-900 p-3 border border-slate-800">
                  <span className="text-[10px] text-slate-400 block uppercase font-bold">Login ADM Padrão:</span>
                  <span className="font-bold text-emerald-300 font-mono">lucasgame988@gmail.com</span>
                </div>

                <div className="rounded-xl bg-slate-900 p-3 border border-slate-800">
                  <span className="text-[10px] text-slate-400 block uppercase font-bold">Senha ADM Padrão:</span>
                  <span className="font-bold text-amber-300 font-mono">jogo1212</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </main>
  );
}
