"use client";
import React, { useState, useEffect } from "react";
import Link from "next/link";
import {
  Trophy,
  ArrowLeft,
  Video,
  ShieldCheck,
  CheckCircle2,
  Clock,
  Sparkles,
  ExternalLink,
  Flame,
} from "lucide-react";

export default function RevelacaoPage() {
  const [raffles, setRaffles] = useState<any[]>([]);
  const [selectedRaffle, setSelectedRaffle] = useState<any | null>(null);
  const [loading, setLoading] = useState(true);

  async function load() {
    setLoading(true);
    try {
      const res = await fetch("/api/raffles");
      const data = await res.json();
      if (data.ok && data.data) {
        setRaffles(data.data);
        if (data.data.length > 0) {
          setSelectedRaffle(data.data[0]);
        }
      }
    } catch {
      // ignore
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
  }, []);

  return (
    <main className="min-h-screen bg-[#040817] text-slate-100 selection:bg-amber-400 selection:text-black">
      <div className="relative z-10 mx-auto max-w-5xl px-4 py-8 md:px-6 md:py-12">
        <div className="flex items-center justify-between border-b border-slate-800 pb-6">
          <Link
            href="/sorteios"
            className="inline-flex items-center gap-2 text-sm font-bold text-amber-400 hover:text-amber-300 transition-colors"
          >
            <ArrowLeft size={18} /> Voltar aos Sorteios
          </Link>

          <a
            href="https://instagram.com/sonicvendas"
            target="_blank"
            rel="noreferrer"
            className="inline-flex items-center gap-2 rounded-xl bg-gradient-to-r from-purple-600 to-pink-500 px-4 py-2 text-xs font-black uppercase text-white hover:brightness-110 transition-all shadow-md"
          >
            <Video size={16} /> Abrir Live no Instagram <ExternalLink size={12} />
          </a>
        </div>

        <div className="mt-8 text-center">
          <div className="inline-flex items-center gap-2 rounded-full bg-gradient-to-r from-amber-500/20 via-orange-500/20 to-amber-500/20 px-5 py-2 border border-amber-400/40 shadow-lg shadow-amber-500/20 mb-3">
            <Trophy className="text-amber-400" size={18} />
            <span className="text-xs font-black uppercase tracking-wider text-amber-300">
              REVELAÇÃO OFICIAL DO GANHADOR • LOTERIA FEDERAL
            </span>
          </div>

          <h1 className="text-4xl font-black tracking-tight text-white md:text-6xl drop-shadow-[0_0_30px_rgba(245,158,11,0.5)]">
            APURAÇÃO AO VIVO
          </h1>

          <p className="mx-auto mt-2 max-w-xl text-sm md:text-base text-slate-300">
            Confira a apuração transparente com base nos concursos oficiais da Loteria Federal.
          </p>
        </div>

        {/* Sorteio selector pills */}
        <div className="mt-8 flex flex-wrap items-center justify-center gap-2">
          {raffles.map((r) => (
            <button
              key={r.id}
              onClick={() => setSelectedRaffle(r)}
              className={`rounded-xl px-4 py-2 text-xs font-bold transition-all ${
                selectedRaffle?.id === r.id
                  ? "bg-amber-400 text-slate-950 font-black shadow-md shadow-amber-400/20"
                  : "bg-slate-900 border border-slate-800 text-slate-300 hover:bg-slate-800"
              }`}
            >
              {r.title}
            </button>
          ))}
        </div>

        {/* Selected Raffle Reveal Card */}
        {selectedRaffle && (
          <div className="mt-10 overflow-hidden rounded-3xl border-2 border-amber-400/40 bg-gradient-to-b from-slate-950 via-slate-900 to-slate-950 p-6 md:p-10 shadow-2xl backdrop-blur-xl">
            <div className="grid gap-8 md:grid-cols-12 items-center">
              <div className="md:col-span-5">
                <div className="relative h-64 w-full overflow-hidden rounded-2xl bg-slate-950">
                  <img
                    src={selectedRaffle.imageUrl}
                    alt={selectedRaffle.title}
                    className="h-full w-full object-cover"
                    onError={(e) => {
                      (e.target as HTMLImageElement).src = "https://images.unsplash.com/photo-1695048133142-1a20484d2569?w=800&q=80";
                    }}
                  />
                  <div className="absolute top-3 left-3 rounded-full bg-slate-950/80 px-3 py-1 text-[10px] font-black uppercase text-amber-400 border border-amber-400/30">
                    Sorteio #{selectedRaffle.id}
                  </div>
                </div>
              </div>

              <div className="md:col-span-7 space-y-4">
                <span className="rounded-full bg-amber-400/10 px-3 py-1 text-xs font-bold text-amber-300 border border-amber-400/20">
                  {selectedRaffle.category?.toUpperCase() || "GERAL"}
                </span>

                <h3 className="text-2xl md:text-3xl font-black text-white">{selectedRaffle.title}</h3>
                <p className="text-xs text-slate-300">{selectedRaffle.description}</p>

                {/* Status Box */}
                {selectedRaffle.status === "drawn" ? (
                  <div className="rounded-2xl border-2 border-emerald-400 bg-emerald-950/50 p-6 shadow-xl">
                    <span className="text-xs font-black uppercase tracking-wider text-emerald-300">
                      🏆 GANHADOR CONFIRMADO
                    </span>
                    <div className="mt-2 flex items-baseline gap-3">
                      <span className="text-xs font-bold text-slate-300">Código Sorteado:</span>
                      <span className="text-4xl font-mono font-black text-amber-400 animate-pulse">
                        {selectedRaffle.winnerCode}
                      </span>
                    </div>

                    <p className="mt-1 text-sm font-bold text-white">
                      Ganhador: <span className="text-emerald-300">{selectedRaffle.winnerName || "Participante Premiado"}</span>
                      {selectedRaffle.winnerPhoneMasked && ` (${selectedRaffle.winnerPhoneMasked})`}
                    </p>

                    <div className="mt-3 text-[11px] text-slate-400">
                      Apuração pela Loteria Federal Concurso #{selectedRaffle.lotteryContestNumber || "5982"}
                    </div>
                  </div>
                ) : (
                  <div className="rounded-2xl border border-amber-500/40 bg-amber-950/20 p-6">
                    <div className="flex items-center gap-2 text-amber-300 text-xs font-black uppercase">
                      <Clock size={16} /> AGUARDANDO APURAÇÃO DA LOTERIA FEDERAL
                    </div>
                    <div className="mt-2 text-xl font-black text-white">
                      Data Prevista:{" "}
                      <span className="text-amber-400">
                        {selectedRaffle.drawDate
                          ? new Date(selectedRaffle.drawDate).toLocaleString("pt-BR")
                          : "Em breve"}
                      </span>
                    </div>
                    <p className="mt-2 text-xs text-slate-400">
                      O resultado será extraído do concurso oficial #{selectedRaffle.lotteryContestNumber || "5982"} da Loteria Federal e anunciado ao vivo no Instagram.
                    </p>
                  </div>
                )}

                <div className="flex gap-3 pt-2">
                  <a
                    href="https://instagram.com/sonicvendas"
                    target="_blank"
                    rel="noreferrer"
                    className="flex-1 rounded-2xl bg-gradient-to-r from-purple-600 to-pink-500 py-3 text-center text-xs font-black uppercase text-white shadow-lg hover:brightness-110 transition-all"
                  >
                    Acompanhar Live Oficial
                  </a>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </main>
  );
}
