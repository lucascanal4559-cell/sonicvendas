"use client";
import React, { useState, useEffect } from "react";
import Link from "next/link";
import {
  Trophy,
  Flame,
  Ticket,
  Search,
  Sparkles,
  CheckCircle2,
  Clock,
  ArrowRight,
  ShieldCheck,
  Smartphone,
  Laptop,
  Tv,
  Coins,
  Copy,
  Check,
  Gift,
  HelpCircle,
  Video,
} from "lucide-react";

export default function SorteiosPage() {
  const [raffles, setRaffles] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedCategory, setSelectedCategory] = useState("todos");

  // Buy modal state
  const [buyingRaffle, setBuyingRaffle] = useState<any | null>(null);
  const [buyQty, setBuyQty] = useState(10);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [buying, setBuying] = useState(false);
  const [buySuccess, setBuySuccess] = useState<any | null>(null);
  const [buyError, setBuyError] = useState("");

  // Lookup state
  const [lookupEmail, setLookupEmail] = useState("");
  const [myTickets, setMyTickets] = useState<any[] | null>(null);
  const [lookupLoading, setLookupLoading] = useState(false);
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  async function loadRaffles() {
    setLoading(true);
    try {
      const res = await fetch("/api/raffles");
      const data = await res.json();
      if (data.ok) {
        setRaffles(data.data || []);
      }
    } catch {
      // ignore
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    loadRaffles();
  }, []);

  const filteredRaffles = selectedCategory === "todos"
    ? raffles
    : raffles.filter((r) => r.category?.toLowerCase() === selectedCategory.toLowerCase());

  function openBuyModal(raffle: any, defaultQty = 10) {
    setBuyingRaffle(raffle);
    setBuyQty(defaultQty);
    setBuySuccess(null);
    setBuyError("");
  }

  async function handleBuySubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!buyingRaffle) return;
    setBuying(true);
    setBuyError("");
    setBuySuccess(null);

    try {
      const res = await fetch("/api/raffles/buy", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          raffleId: buyingRaffle.id,
          customerName: name,
          customerEmail: email,
          customerPhone: phone,
          quantity: buyQty,
          paymentMethod: "mercadopago",
        }),
      });

      const data = await res.json();
      if (data.ok) {
        setBuySuccess(data.data);
        loadRaffles();
      } else {
        setBuyError(data.error || "Erro ao processar compra.");
      }
    } catch {
      setBuyError("Erro de conexão com o servidor.");
    } finally {
      setBuying(false);
    }
  }

  async function handleLookupTickets(e: React.FormEvent) {
    e.preventDefault();
    if (!lookupEmail) return;
    setLookupLoading(true);
    try {
      const isEmail = lookupEmail.includes("@");
      const url = isEmail
        ? `/api/raffles/my-tickets?email=${encodeURIComponent(lookupEmail)}`
        : `/api/raffles/my-tickets?phone=${encodeURIComponent(lookupEmail)}`;
      const res = await fetch(url);
      const data = await res.json();
      if (data.ok) {
        setMyTickets(data.data || []);
      } else {
        alert(data.error || "Nenhum bilhete encontrado.");
      }
    } catch {
      alert("Erro ao consultar bilhetes.");
    } finally {
      setLookupLoading(false);
    }
  }

  function handleCopy(text: string, key: string) {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2000);
  }

  const calculatedTotal = buyingRaffle
    ? (buyQty * parseFloat(String(buyingRaffle.pricePerNumber || 0.10))).toFixed(2)
    : "0.00";

  return (
    <main className="min-h-screen bg-[#040817] text-slate-100 selection:bg-amber-400 selection:text-black">
      {/* Background ambient light */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden">
        <div className="absolute -top-40 left-1/2 -translate-x-1/2 w-[800px] h-[500px] bg-gradient-to-b from-amber-500/15 via-blue-600/10 to-transparent blur-3xl" />
        <div className="absolute top-[30%] -left-32 w-[500px] h-[500px] bg-amber-600/10 blur-[140px]" />
        <div className="absolute top-[60%] -right-32 w-[500px] h-[500px] bg-blue-600/10 blur-[140px]" />
      </div>

      <div className="relative z-10 mx-auto max-w-6xl px-4 py-8 md:px-6 md:py-12">
        {/* Top Header Breadcrumb */}
        <div className="flex flex-col md:flex-row items-center justify-between gap-4 border-b border-slate-800 pb-6">
          <div className="flex items-center gap-3">
            <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-gradient-to-tr from-amber-500 to-amber-300 p-2 shadow-lg shadow-amber-500/30">
              <Trophy size={28} className="text-slate-950" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-2xl font-black italic tracking-wider text-white">SORTEIOS</span>
                <span className="rounded bg-amber-400 px-2 py-0.5 text-xs font-black uppercase text-slate-950">SONIC VENDAS</span>
              </div>
              <p className="text-[11px] font-bold uppercase tracking-widest text-amber-400">Cotas a partir de R$ 0,01 • Apuração Loteria Federal</p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <Link
              href="/roleta"
              className="inline-flex items-center gap-2 rounded-xl border border-pink-500/40 bg-pink-950/40 px-4 py-2 text-xs font-black uppercase tracking-wider text-pink-300 hover:bg-pink-500 hover:text-slate-950 transition-all shadow-md shadow-pink-500/20"
            >
              <Gift size={16} /> Girar Roleta da Sorte
            </Link>
            <a
              href="#meus-bilhetes"
              className="rounded-xl border border-amber-400/40 bg-amber-950/40 px-4 py-2 text-xs font-bold text-amber-300 hover:bg-amber-400 hover:text-slate-950 transition-all shadow-md"
            >
              🔍 Meus Bilhetes
            </a>
          </div>
        </div>

        {/* Hero Banner */}
        <div className="mt-8 text-center md:mt-12">
          <div className="inline-flex items-center gap-2 rounded-full bg-gradient-to-r from-amber-500/20 via-orange-500/20 to-amber-500/20 px-5 py-2 border border-amber-400/40 shadow-lg shadow-amber-500/20 mb-4 animate-pulse">
            <Flame className="text-amber-400" size={18} />
            <span className="text-sm font-extrabold text-amber-300 uppercase tracking-wide">
              SORTEIOS OFICIAIS COM RESULTADOS EM TEMPO REAL
            </span>
          </div>

          <h1 className="text-4xl font-black tracking-tight text-white md:text-7xl drop-shadow-[0_0_35px_rgba(245,158,11,0.5)]">
            CONCORRA A <span className="bg-gradient-to-r from-amber-400 via-orange-400 to-amber-200 bg-clip-text text-transparent">SUPER PRÊMIOS!</span>
          </h1>

          <p className="mx-auto mt-4 max-w-2xl text-base md:text-xl font-medium text-slate-300">
            Adquira suas cotas, receba seus códigos exclusivos e acompanhe as apurações ao vivo com total transparência pela Loteria Federal.
          </p>

          {/* Live Stream / Regulation highlight card */}
          <div className="mx-auto mt-8 flex max-w-4xl flex-col items-center justify-between gap-4 rounded-3xl border border-amber-500/30 bg-gradient-to-r from-slate-950 via-amber-950/40 to-slate-950 p-6 shadow-2xl backdrop-blur-xl md:flex-row md:px-8">
            <div className="flex items-center gap-4 text-left">
              <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl bg-gradient-to-tr from-pink-600 to-purple-600 text-white shadow-xl shadow-purple-600/30">
                <Video size={28} />
              </div>
              <div>
                <h3 className="text-lg font-black text-white">Transmissão ao Vivo no Instagram</h3>
                <p className="text-xs text-slate-400">
                  Acompanhe a revelação do resultado da Loteria Federal em tempo real na live oficial!
                </p>
              </div>
            </div>

            <a
              href="https://instagram.com/sonicvendas"
              target="_blank"
              rel="noreferrer"
              className="inline-flex shrink-0 items-center gap-2 rounded-2xl bg-gradient-to-r from-purple-600 to-pink-500 px-5 py-3 text-xs font-black uppercase text-white hover:brightness-110 transition-all shadow-lg shadow-purple-500/30"
            >
              Assistir Live no Instagram <ArrowRight size={14} />
            </a>
          </div>
        </div>

        {/* Category Filter Pills */}
        <div className="mt-10 flex flex-wrap items-center justify-center gap-2">
          {[
            { id: "todos", label: "🌟 Todos os Sorteios" },
            { id: "celular", label: "📱 Celulares" },
            { id: "computador", label: "💻 Computadores" },
            { id: "geladeira", label: "❄️ Eletrodomésticos" },
            { id: "viagens", label: "✈️ Viagens" },
            { id: "dinheiro", label: "💵 Dinheiro / Pix" },
          ].map((cat) => (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id)}
              className={`rounded-xl px-4 py-2 text-xs font-bold transition-all ${
                selectedCategory === cat.id
                  ? "bg-amber-400 text-slate-950 shadow-lg shadow-amber-400/20 scale-105"
                  : "bg-slate-900/80 text-slate-300 border border-slate-800 hover:bg-slate-800"
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* Raffle Cards Grid */}
        <div className="mt-8 grid gap-8 md:grid-cols-2 lg:grid-cols-3">
          {filteredRaffles.map((raffle) => {
            const unitPrice = parseFloat(String(raffle.pricePerNumber || 0.10));
            const percentage = raffle.percentageSold || 0;
            const remaining = raffle.remainingNumbers !== undefined ? raffle.remainingNumbers : raffle.totalNumbers - raffle.numbersSold;

            return (
              <div
                key={raffle.id}
                className="group relative flex flex-col justify-between overflow-hidden rounded-3xl border border-slate-800 bg-slate-900/70 p-6 shadow-xl backdrop-blur-md transition-all hover:-translate-y-1 hover:border-amber-400/50 hover:shadow-2xl hover:shadow-amber-500/10"
              >
                <div>
                  {/* Top Image + Badges */}
                  <div className="relative mb-4 h-52 w-full overflow-hidden rounded-2xl bg-slate-950">
                    <img
                      src={raffle.imageUrl}
                      alt={raffle.title}
                      className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
                      onError={(e) => {
                        (e.target as HTMLImageElement).src = "https://images.unsplash.com/photo-1695048133142-1a20484d2569?w=800&q=80";
                      }}
                    />
                    <div className="absolute top-3 left-3 flex flex-col gap-1">
                      <span className="rounded-full bg-slate-950/80 px-3 py-1 text-[10px] font-black uppercase tracking-wider text-amber-400 backdrop-blur-md border border-amber-400/30">
                        {raffle.category?.toUpperCase() || "SORTEIO"}
                      </span>
                      {raffle.status === "drawn" && (
                        <span className="rounded-full bg-emerald-500 px-3 py-1 text-[10px] font-black uppercase text-slate-950">
                          🏆 APURADO
                        </span>
                      )}
                    </div>

                    <div className="absolute bottom-3 right-3 rounded-xl bg-amber-400 px-3 py-1 text-xs font-black text-slate-950 shadow-lg">
                      R$ {unitPrice.toFixed(2)} / cota
                    </div>
                  </div>

                  {/* Title & Description */}
                  <h3 className="text-xl font-black text-white group-hover:text-amber-400 transition-colors">
                    {raffle.title}
                  </h3>
                  <p className="mt-2 line-clamp-2 text-xs text-slate-400">
                    {raffle.description}
                  </p>

                  {/* Apuração info */}
                  <div className="mt-4 flex items-center gap-2 rounded-xl bg-slate-950/80 p-2.5 border border-slate-800 text-[11px] text-slate-300">
                    <ShieldCheck size={16} className="text-amber-400 shrink-0" />
                    <span>
                      Apuração: <strong>Loteria Federal</strong>{" "}
                      {raffle.lotteryContestNumber ? `(Concurso #${raffle.lotteryContestNumber})` : ""}
                    </span>
                  </div>

                  {/* Quotas Progress Bar */}
                  <div className="mt-4 space-y-1.5">
                    <div className="flex justify-between text-xs font-bold">
                      <span className="text-slate-400">
                        {raffle.numbersSold} de {raffle.totalNumbers} cotas
                      </span>
                      <span className="text-amber-400">{percentage}% vendido</span>
                    </div>
                    <div className="h-2.5 w-full overflow-hidden rounded-full bg-slate-950 border border-slate-800">
                      <div
                        className="h-full bg-gradient-to-r from-amber-500 to-amber-300 transition-all duration-500"
                        style={{ width: `${percentage}%` }}
                      />
                    </div>
                    <p className="text-[10px] text-slate-500 text-right">Restam {remaining} cotas disponíveis</p>
                  </div>
                </div>

                {/* Quick Buy Packages */}
                <div className="mt-6 border-t border-slate-800/80 pt-4">
                  <span className="text-[11px] font-bold text-slate-400 block mb-2">Compre cotas com 1 clique:</span>
                  <div className="grid grid-cols-4 gap-1.5 mb-3">
                    {[10, 50, 100, 500].map((qty) => (
                      <button
                        key={qty}
                        type="button"
                        onClick={() => openBuyModal(raffle, qty)}
                        className="rounded-xl border border-amber-400/30 bg-amber-950/30 py-1.5 text-xs font-black text-amber-300 hover:bg-amber-400 hover:text-slate-950 transition-all"
                      >
                        +{qty}
                      </button>
                    ))}
                  </div>

                  <button
                    type="button"
                    onClick={() => openBuyModal(raffle, 10)}
                    disabled={raffle.status !== "open"}
                    className="w-full rounded-2xl bg-gradient-to-r from-amber-500 via-orange-400 to-amber-400 py-3 text-sm font-black uppercase tracking-wider text-slate-950 shadow-lg shadow-amber-500/20 hover:scale-[1.02] transition-all disabled:opacity-50"
                  >
                    {raffle.status === "open" ? "Participar do Sorteio" : "Sorteio Finalizado"}
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        {/* Section: Meus Bilhetes */}
        <section id="meus-bilhetes" className="mt-16 scroll-mt-24">
          <div className="rounded-3xl border-2 border-amber-400/30 bg-gradient-to-b from-slate-950 via-slate-900 to-slate-950 p-6 md:p-10 shadow-2xl">
            <div className="flex flex-col md:flex-row items-center justify-between gap-4 border-b border-slate-800 pb-6">
              <div>
                <span className="text-xs font-black uppercase tracking-widest text-amber-400">ÁREA DO PARTICIPANTE</span>
                <h3 className="text-2xl font-black text-white md:text-3xl">Consultar Meus Códigos</h3>
                <p className="text-xs text-slate-400 md:text-sm">
                  Digite seu e-mail ou WhatsApp para visualizar todas as cotas e códigos que você adquiriu.
                </p>
              </div>

              <form onSubmit={handleLookupTickets} className="flex w-full md:w-auto items-center gap-2">
                <input
                  type="text"
                  placeholder="Seu e-mail ou WhatsApp..."
                  value={lookupEmail}
                  onChange={(e) => setLookupEmail(e.target.value)}
                  className="w-full md:w-72 rounded-2xl border border-slate-700 bg-slate-950 px-4 py-3 text-sm text-white placeholder-slate-500 focus:border-amber-400 focus:outline-none"
                />
                <button
                  type="submit"
                  disabled={lookupLoading}
                  className="flex shrink-0 items-center gap-2 rounded-2xl bg-amber-400 px-5 py-3 text-sm font-black text-slate-950 hover:bg-amber-300 transition-all shadow-lg shadow-amber-400/20 disabled:opacity-60"
                >
                  <Search size={16} />
                  {lookupLoading ? "Buscando..." : "Consultar"}
                </button>
              </form>
            </div>

            {/* Tickets list */}
            {myTickets && (
              <div className="mt-8 space-y-4">
                {myTickets.map((p) => (
                  <div key={p.id} className="rounded-2xl border border-slate-800 bg-slate-950 p-6">
                    <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800/80 pb-4">
                      <div>
                        <div className="text-xs font-bold text-amber-400 uppercase">Sorteio #{p.raffleId}</div>
                        <h4 className="text-lg font-black text-white">{p.raffleTitle}</h4>
                        <p className="text-xs text-slate-400">
                          Comprado em: {new Date(p.createdAt).toLocaleString("pt-BR")} • Total: R$ {Number(p.totalAmount).toFixed(2)} ({p.quantity} cotas)
                        </p>
                      </div>

                      <div className="flex items-center gap-2">
                        {p.raffleStatus === "drawn" ? (
                          <span className="rounded-full bg-emerald-500/20 px-3 py-1 text-xs font-bold text-emerald-300 border border-emerald-500/30">
                            Resultado Revelado
                          </span>
                        ) : (
                          <span className="rounded-full bg-amber-400/10 px-3 py-1 text-xs font-bold text-amber-300 border border-amber-400/30">
                            Aguardando Apuração
                          </span>
                        )}
                      </div>
                    </div>

                    <div className="mt-4">
                      <span className="text-xs font-bold text-slate-300 block mb-2">Seus Códigos da Sorte:</span>
                      <div className="flex flex-wrap gap-2 max-h-48 overflow-y-auto p-1">
                        {Array.isArray(p.ticketCodes) && p.ticketCodes.map((code: string, idx: number) => {
                          const isWinner = p.winnerCode && p.winnerCode === code;
                          return (
                            <span
                              key={idx}
                              className={`rounded-lg px-2.5 py-1 text-xs font-mono font-bold border ${
                                isWinner
                                  ? "bg-emerald-400 text-slate-950 border-emerald-300 animate-bounce"
                                  : "bg-slate-900 text-amber-300 border-amber-400/30"
                              }`}
                            >
                              {code} {isWinner && "🏆 GANHADOR!"}
                            </span>
                          );
                        })}
                      </div>
                    </div>
                  </div>
                ))}

                {myTickets.length === 0 && (
                  <div className="p-8 text-center text-slate-500">
                    Nenhuma cota encontrada com este e-mail ou WhatsApp.
                  </div>
                )}
              </div>
            )}
          </div>
        </section>
      </div>

      {/* Buy Modal */}
      {buyingRaffle && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 backdrop-blur-md">
          <div className="relative w-full max-w-lg rounded-3xl border-2 border-amber-400/50 bg-slate-950 p-6 md:p-8 shadow-2xl">
            <button
              onClick={() => setBuyingRaffle(null)}
              className="absolute top-6 right-6 rounded-full bg-slate-800 p-2 text-slate-400 hover:bg-slate-700 hover:text-white"
            >
              ✕
            </button>

            {!buySuccess ? (
              <form onSubmit={handleBuySubmit} className="space-y-4">
                <div className="border-b border-slate-800 pb-4">
                  <span className="text-[10px] font-black uppercase tracking-widest text-amber-400">
                    COMPRAR COTAS EXCLUSIVAS
                  </span>
                  <h3 className="text-xl font-black text-white">{buyingRaffle.title}</h3>
                  <p className="text-xs text-slate-400">
                    Preço por cota: <span className="font-bold text-amber-400">R$ {parseFloat(String(buyingRaffle.pricePerNumber || 0.10)).toFixed(2)}</span>
                  </p>
                </div>

                <div>
                  <label className="mb-1 block text-xs font-bold text-slate-300">Quantidade de Cotas</label>
                  <div className="grid grid-cols-4 gap-2 mb-2">
                    {[10, 50, 100, 500].map((q) => (
                      <button
                        key={q}
                        type="button"
                        onClick={() => setBuyQty(q)}
                        className={`rounded-xl py-2 text-xs font-bold transition-all ${
                          buyQty === q
                            ? "bg-amber-400 text-slate-950 font-black shadow-md shadow-amber-400/20"
                            : "bg-slate-900 border border-slate-800 text-slate-300"
                        }`}
                      >
                        +{q}
                      </button>
                    ))}
                  </div>
                  <input
                    type="number"
                    min={1}
                    max={buyingRaffle.remainingNumbers || 1000}
                    value={buyQty}
                    onChange={(e) => setBuyQty(Math.max(1, parseInt(e.target.value || "1", 10)))}
                    className="w-full rounded-2xl border border-slate-700 bg-slate-900 px-4 py-2.5 text-sm text-white focus:border-amber-400 focus:outline-none"
                  />
                </div>

                <div className="grid gap-3 md:grid-cols-2">
                  <div>
                    <label className="mb-1 block text-xs font-bold text-slate-300">Seu Nome Completo</label>
                    <input
                      type="text"
                      required
                      placeholder="Ex: Lucas Gabriel"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      className="w-full rounded-2xl border border-slate-700 bg-slate-900 px-4 py-2.5 text-xs text-white focus:border-amber-400 focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="mb-1 block text-xs font-bold text-slate-300">WhatsApp</label>
                    <input
                      type="text"
                      required
                      placeholder="(75) 98155-8007"
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      className="w-full rounded-2xl border border-slate-700 bg-slate-900 px-4 py-2.5 text-xs text-white focus:border-amber-400 focus:outline-none"
                    />
                  </div>
                </div>

                <div>
                  <label className="mb-1 block text-xs font-bold text-slate-300">E-mail para receber os códigos</label>
                  <input
                    type="email"
                    required
                    placeholder="seu@email.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full rounded-2xl border border-slate-700 bg-slate-900 px-4 py-2.5 text-xs text-white focus:border-amber-400 focus:outline-none"
                  />
                </div>

                {/* Total Price Display */}
                <div className="flex items-center justify-between rounded-2xl border border-amber-400/30 bg-amber-950/40 p-4">
                  <span className="text-xs font-bold text-amber-300">Valor Total ({buyQty} cotas):</span>
                  <span className="text-2xl font-black text-amber-400">R$ {calculatedTotal}</span>
                </div>

                {buyError && (
                  <div className="rounded-xl border border-rose-500/40 bg-rose-950/40 p-3 text-xs text-rose-300">
                    {buyError}
                  </div>
                )}

                <button
                  type="submit"
                  disabled={buying}
                  className="w-full rounded-2xl bg-gradient-to-r from-amber-500 to-orange-400 py-3.5 text-sm font-black uppercase text-slate-950 shadow-lg shadow-amber-500/20 hover:brightness-110 transition-all disabled:opacity-60"
                >
                  {buying ? "Gerando seus códigos..." : `Confirmar e Gerar Códigos (R$ ${calculatedTotal})`}
                </button>
              </form>
            ) : (
              <div className="space-y-4 text-center">
                <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-emerald-400/20 text-3xl text-emerald-400">
                  ✓
                </div>
                <h4 className="text-2xl font-black text-white">Parabéns! Cotas Adquiridas</h4>
                <p className="text-xs text-slate-300">
                  Suas <span className="font-bold text-amber-400">{buySuccess.quantity} cotas</span> foram registradas com sucesso para o sorteio <strong>{buySuccess.raffleTitle}</strong>.
                </p>

                <div className="rounded-2xl border border-slate-800 bg-slate-900 p-4 text-left">
                  <span className="text-xs font-bold text-slate-400 block mb-2">Seus Códigos Atribuídos:</span>
                  <div className="flex flex-wrap gap-1.5 max-h-40 overflow-y-auto p-1">
                    {buySuccess.ticketCodes.map((code: string, i: number) => (
                      <span key={i} className="rounded-lg bg-amber-400/10 px-2.5 py-1 text-xs font-mono font-bold text-amber-300 border border-amber-400/20">
                        {code}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="pt-2">
                  <button
                    onClick={() => {
                      setBuyingRaffle(null);
                      setLookupEmail(email);
                    }}
                    className="w-full rounded-2xl bg-amber-400 py-3 text-xs font-black uppercase text-slate-950 hover:bg-amber-300 transition-colors"
                  >
                    Concluir & Fechar
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </main>
  );
}
