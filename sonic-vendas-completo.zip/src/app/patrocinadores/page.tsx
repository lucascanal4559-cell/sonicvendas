import { db } from "@/db";
import { sponsors } from "@/db/schema";
import { desc, eq } from "drizzle-orm";
import Link from "next/link";
import { ArrowLeft, Star, CreditCard } from "lucide-react";

export const dynamic = "force-dynamic";
export const revalidate = 10;

export default async function PatrocinadoresPage() {
  const data = await db.select().from(sponsors).where(eq(sponsors.isActive, true)).orderBy(desc(sponsors.createdAt));

  return (
    <main className="min-h-screen bg-gradient-to-b from-slate-950 via-slate-900 to-amber-950/20 px-6 py-12">
      <div className="mx-auto max-w-6xl">
        <Link href="/" className="inline-flex items-center gap-2 text-sm font-bold text-amber-400 hover:text-amber-300 transition-colors mb-8"><ArrowLeft size={18} /> Voltar</Link>
        <h1 className="text-4xl font-extrabold tracking-tight text-white">Patrocinadores</h1>
        <p className="mt-2 text-sm text-slate-400">Apoie a Sonic Vendas e tenha sua marca divulgada no site. Valores: R$ 40/semana ou R$ 80/mês.</p>

        <div className="mt-8 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {data.map((s: any) => (
            <div key={s.id} className="rounded-3xl border border-slate-800 bg-slate-900/60 p-6 shadow-xl">
              <img src={s.imageUrl || "https://placehold.co/600x300?text=Patrocinador"} alt={s.name} className="mb-4 h-32 w-full rounded-2xl object-cover bg-slate-950" />
              <h3 className="text-xl font-extrabold text-slate-100">{s.name}</h3>
              <p className="mt-2 text-sm text-slate-400">{s.description || "Patrocinador oficial da Sonic Vendas."}</p>
              <div className="mt-4 flex items-center justify-between">
                <span className="text-sm font-bold text-amber-400">{s.period === "weekly" ? "R$ " + s.weeklyPrice + "/semana" : "R$ " + s.monthlyPrice + "/mês"}</span>
                <a href={s.linkUrl || "#"} className="rounded-lg bg-amber-400 px-4 py-2 text-xs font-extrabold text-slate-950 hover:bg-amber-300 transition-all">Saiba mais</a>
              </div>
            </div>
          ))}
        </div>
      </div>
    </main>
  );
}
