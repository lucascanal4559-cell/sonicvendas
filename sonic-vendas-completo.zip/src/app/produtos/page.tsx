import { db } from "@/db";
import { products, categories } from "@/db/schema";
import { eq, desc, and } from "drizzle-orm";
import Link from "next/link";
import { ArrowLeft } from "lucide-react";

export const dynamic = "force-dynamic";
export const revalidate = 10;

export default async function ProductsPage({ searchParams }: { searchParams: Promise<{ categoria?: string; search?: string }> }) {
  const { categoria, search } = await searchParams || {};

  const conditions = [eq(products.isActive, true)];
  if (categoria) {
    const catRes = await db.select().from(categories).where(eq(categories.slug, categoria)).limit(1);
    const cat = catRes[0];
    if (cat) conditions.push(eq(products.categoryId, cat.id));
  }

  const allProducts = await db.select().from(products).where(and(...conditions)).orderBy(desc(products.createdAt)).limit(20);

  const filtered = search ? allProducts.filter((p) => p.title.toLowerCase().includes(search.toLowerCase()) || p.description.toLowerCase().includes(search.toLowerCase())) : allProducts;

  const cats = await db.select().from(categories).where(eq(categories.isActive, true)).orderBy(categories.name);

  return (
    <main className="min-h-screen bg-gradient-to-b from-slate-950 via-slate-900 to-amber-950/20 px-6 py-12">
      <div className="mx-auto max-w-6xl">
        <Link href="/" className="inline-flex items-center gap-2 text-sm font-bold text-amber-400 hover:text-amber-300 transition-colors mb-8"><ArrowLeft size={18} /> Voltar</Link>
        <h1 className="text-4xl font-extrabold tracking-tight text-white">Todos os Produtos</h1>
        <p className="mt-2 text-sm text-slate-400">Dados atualizados em tempo real do banco de dados.</p>

        <div className="mt-8 flex flex-wrap gap-2">
          <Link href="/produtos" className={`rounded-xl px-4 py-2 text-sm font-bold transition-all ${!categoria ? "bg-amber-400 text-slate-950" : "bg-slate-900 text-slate-300 hover:bg-slate-800"}`}>Todos</Link>
          {cats.map((c) => (
            <Link key={c.id} href={`/produtos?categoria=${c.slug}`} className={`rounded-xl px-4 py-2 text-sm font-bold transition-all ${categoria === c.slug ? "bg-amber-400 text-slate-950" : "bg-slate-900 text-slate-300 hover:bg-slate-800"}`}>{c.name}</Link>
          ))}
        </div>

        <div className="mt-8 grid gap-6 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4">
          {filtered.map((p) => (
            <Link key={p.id} href={`/produto/${p.slug}`} className="group relative overflow-hidden rounded-3xl border border-slate-800 bg-slate-900/60 shadow-xl transition-all hover:scale-[1.02] hover:shadow-2xl">
              <div className="relative h-56 overflow-hidden">
                {p.imageUrl ? (
                  <img src={p.imageUrl} alt={p.title} className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-110" />
                ) : (
                  <div className="h-full w-full flex items-center justify-center bg-slate-800 text-slate-500 text-sm font-medium">Sem imagem disponível</div>
                )}
                {p.isPromotion && <span className="absolute left-3 top-3 rounded-full bg-red-500 px-3 py-1 text-[10px] font-extrabold uppercase tracking-wide text-white shadow-lg">Promoção {p.discountPercent}%</span>}
              </div>
              <div className="p-5">
                <h3 className="text-lg font-extrabold text-slate-100 group-hover:text-amber-400 transition-colors">{p.title}</h3>
                <p className="mt-1 text-xs text-slate-500">{p.categoryId ? "Categoria" : "Sem categoria"}</p>
                <p className="mt-2 line-clamp-2 text-sm text-slate-400">{p.description}</p>
                <div className="mt-4 flex items-baseline gap-2">
                  <span className="text-2xl font-extrabold text-amber-400">R$ {Number(p.price).toFixed(2)}</span>
                </div>
              </div>
            </Link>
          ))}
        </div>
        {filtered.length === 0 && (
          <div className="rounded-3xl border border-slate-800 bg-slate-900/40 p-12 text-center text-slate-500 shadow-xl">Nenhum produto encontrado.</div>
        )}
      </div>
    </main>
  );
}
