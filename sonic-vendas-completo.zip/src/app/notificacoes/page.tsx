import { db } from "@/db";
import { notifications } from "@/db/schema";
import { desc, eq } from "drizzle-orm";
import Link from "next/link";
import { ArrowLeft, Bell } from "lucide-react";

export const dynamic = "force-dynamic";
export const revalidate = 5;

export default async function NotificacoesPage() {
  const data = await db.select().from(notifications).where(eq(notifications.isActive, true)).orderBy(desc(notifications.createdAt)).limit(10);

  return (
    <main className="min-h-screen bg-gradient-to-b from-slate-950 via-slate-900 to-amber-950/20 px-6 py-12">
      <div className="mx-auto max-w-3xl">
        <Link href="/" className="inline-flex items-center gap-2 text-sm font-bold text-amber-400 hover:text-amber-300 transition-colors mb-8"><ArrowLeft size={18} /> Voltar</Link>
        <h1 className="text-4xl font-extrabold tracking-tight text-white">Notificações</h1>
        <p className="mt-2 text-sm text-slate-400">Fique por dentro das novidades e atualizações da Sonic Vendas.</p>

        <div className="mt-8 space-y-4">
          {data.map((n: any) => (
            <div key={n.id} className="rounded-2xl border border-slate-800 bg-slate-900/60 p-6 shadow-xl flex gap-4 items-start">
              <Bell className="text-amber-400 shrink-0" size={24} />
              <div>
                <h3 className="text-base font-extrabold text-slate-100">{n.title}</h3>
                <p className="mt-1 text-sm text-slate-400">{n.message || "Nova atualização disponível no site."}</p>
                <p className="mt-2 text-xs text-slate-500">{new Date(n.createdAt).toLocaleString("pt-BR")}</p>
              </div>
            </div>
          ))}
          {data.length === 0 && <div className="rounded-2xl border border-slate-800 bg-slate-950 p-8 text-center text-slate-500">Nenhuma notificação no momento.</div>}
        </div>
      </div>
    </main>
  );
}
