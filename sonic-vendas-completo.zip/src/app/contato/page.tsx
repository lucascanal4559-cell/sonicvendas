import { ArrowLeft, MessageCircle, ArrowRight } from "lucide-react";
import Link from "next/link";

export default function ContatoPage() {
  return (
    <main className="min-h-screen bg-gradient-to-b from-slate-950 via-slate-900 to-amber-950/20 px-6 py-12">
      <div className="mx-auto max-w-4xl">
        <Link href="/" className="inline-flex items-center gap-2 text-sm font-bold text-amber-400 hover:text-amber-300 transition-colors mb-8"><ArrowLeft size={18} /> Voltar</Link>
        <h1 className="text-4xl font-extrabold tracking-tight text-white">Contato e Suporte</h1>
        <p className="mt-2 text-sm text-slate-400">Entre em contato conosco pelo chat ou pelo telefone 75981558007.</p>

        <div className="mt-8 rounded-3xl border border-slate-800 bg-slate-950/60 p-6 shadow-xl">
          <div className="flex items-center gap-3 mb-4">
            <MessageCircle className="text-amber-400" size={24} />
            <h2 className="text-lg font-extrabold text-slate-100">Chat de Atendimento</h2>
          </div>

          <div className="rounded-2xl bg-slate-900 border border-slate-800 p-6 h-72 overflow-y-auto space-y-3">
            <div className="flex gap-3 items-start">
              <div className="h-8 w-8 rounded-full bg-amber-400 flex items-center justify-center text-xs font-black text-slate-950 shrink-0">SV</div>
              <div className="rounded-2xl bg-slate-800 px-4 py-3 text-sm text-slate-200 max-w-[80%]">
                Olá! Bem-vindo ao Sonic Vendas. Como posso ajudar você hoje?
              </div>
            </div>
            <div className="flex gap-3 items-start justify-end">
              <div className="rounded-2xl bg-amber-400 px-4 py-3 text-sm text-slate-950 max-w-[80%]">
                Gostaria de saber mais sobre o Fone Sonic Pro.
              </div>
            </div>
            <div className="flex gap-3 items-start">
              <div className="h-8 w-8 rounded-full bg-amber-400 flex items-center justify-center text-xs font-black text-slate-950 shrink-0">SV</div>
              <div className="rounded-2xl bg-slate-800 px-4 py-3 text-sm text-slate-200 max-w-[80%]">
                O Fone Sonic Pro está com 20% de desconto e é ideal para música, chamadas e entretenimento. Quer saber mais?
              </div>
            </div>
          </div>

          <form className="mt-4 flex gap-3">
            <input type="text" placeholder="Digite sua mensagem..." className="flex-1 rounded-xl bg-slate-950 border border-slate-700 px-4 py-3 text-sm text-slate-100 focus:border-amber-400 focus:outline-none" />
            <button type="submit" className="rounded-xl bg-amber-400 px-4 py-3 text-sm font-extrabold text-slate-950 hover:bg-amber-300 transition-all"><ArrowRight size={18} /></button>
          </form>
        </div>
      </div>
    </main>
  );
}
