"use client";
import React, { useState } from "react";
import Link from "next/link";
import {
  ArrowLeft,
  CreditCard,
  QrCode,
  Copy,
  Check,
  ShieldCheck,
  FileCheck,
  UploadCloud,
  CheckCircle2,
} from "lucide-react";
import { playSound } from "@/lib/sounds";

export default function CheckoutPage() {
  const [form, setForm] = useState({
    customerName: "",
    customerEmail: "",
    customerPhone: "",
    customerAddress: "",
    notes: "",
  });

  const [paymentMethod, setPaymentMethod] = useState<"pix" | "mercadopago">("pix");
  const [items, setItems] = useState([
    { productId: 1, title: "Fone de Ouvido Sonic Pro", price: 399.9, qty: 1 },
  ]);

  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState("");
  const [orderId, setOrderId] = useState<number | null>(null);

  // Pix Receipt state
  const [receiptUrl, setReceiptUrl] = useState("");
  const [sendingReceipt, setSendingReceipt] = useState(false);
  const [receiptMessage, setReceiptMessage] = useState("");
  const [copiedPix, setCopiedPix] = useState(false);

  const total = items.reduce((s, i) => s + i.price * i.qty, 0);
  const pixKey = "75981558007";

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    setMessage("");
    try {
      const res = await fetch("/api/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...form,
          items,
          totalAmount: total,
          paymentMethod,
          isPaid: false,
          status: "pending",
        }),
      });
      const data = await res.json();
      if (!data.ok) throw new Error(data.error || "Erro ao criar pedido");

      setOrderId(data.data.id);
      playSound("new_order");
      setMessage(
        paymentMethod === "pix"
          ? "🎉 Pedido registrado com sucesso! Faça o pagamento via Pix abaixo e envie o comprovante para liberação imediata."
          : "Pedido registrado com sucesso! Redirecionando para processamento do pagamento."
      );
    } catch (e: any) {
      setMessage(e.message || "Erro ao salvar pedido.");
      playSound("order_cancelled");
    } finally {
      setSaving(false);
    }
  }

  async function handleSendReceipt(e: React.FormEvent) {
    e.preventDefault();
    if (!receiptUrl) return;
    setSendingReceipt(true);
    setReceiptMessage("");

    try {
      const res = await fetch("/api/orders/pix-receipt", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          orderId,
          customerName: form.customerName,
          customerEmail: form.customerEmail,
          customerPhone: form.customerPhone,
          receiptUrl,
          amount: total.toFixed(2),
        }),
      });

      const data = await res.json();
      if (data.ok) {
        playSound("payment_confirmed");
        setReceiptMessage("✅ Comprovante enviado com sucesso! O administrador já foi notificado.");
        setReceiptUrl("");
      } else {
        setReceiptMessage(data.error || "Erro ao enviar comprovante.");
      }
    } catch {
      setReceiptMessage("Erro de conexão ao enviar comprovante.");
    } finally {
      setSendingReceipt(false);
    }
  }

  function handleCopyPix() {
    navigator.clipboard.writeText(pixKey);
    setCopiedPix(true);
    setTimeout(() => setCopiedPix(false), 2000);
  }

  return (
    <main className="min-h-screen bg-gradient-to-b from-slate-950 via-slate-900 to-amber-950/20 px-4 py-8 md:px-6 md:py-12">
      <div className="mx-auto max-w-3xl">
        <Link
          href="/"
          className="inline-flex items-center gap-2 text-sm font-bold text-amber-400 hover:text-amber-300 transition-colors mb-6"
        >
          <ArrowLeft size={18} /> Voltar para a loja
        </Link>

        <h1 className="text-3xl md:text-4xl font-extrabold tracking-tight text-white">Finalizar Compra</h1>
        <p className="mt-1 text-sm text-slate-400">
          Preencha seus dados com segurança. Seu pedido é registrado e sincronizado no banco de dados.
        </p>

        {/* Form */}
        <form onSubmit={handleSubmit} className="mt-8 rounded-3xl border border-slate-800 bg-slate-900/60 p-6 md:p-8 shadow-xl space-y-6">
          <div className="grid gap-4 md:grid-cols-2">
            <div>
              <label className="mb-1 block text-xs font-bold uppercase text-slate-300">Nome completo</label>
              <input
                type="text"
                required
                value={form.customerName}
                onChange={(e) => setForm({ ...form, customerName: e.target.value })}
                className="w-full rounded-xl bg-slate-950 border border-slate-700 px-4 py-3 text-sm text-white focus:border-amber-400 focus:outline-none"
                placeholder="Ex: Lucas Gabriel"
              />
            </div>
            <div>
              <label className="mb-1 block text-xs font-bold uppercase text-slate-300">E-mail</label>
              <input
                type="email"
                required
                value={form.customerEmail}
                onChange={(e) => setForm({ ...form, customerEmail: e.target.value })}
                className="w-full rounded-xl bg-slate-950 border border-slate-700 px-4 py-3 text-sm text-white focus:border-amber-400 focus:outline-none"
                placeholder="seu@email.com"
              />
            </div>
          </div>

          <div className="grid gap-4 md:grid-cols-2">
            <div>
              <label className="mb-1 block text-xs font-bold uppercase text-slate-300">Telefone / WhatsApp</label>
              <input
                type="text"
                required
                value={form.customerPhone}
                onChange={(e) => setForm({ ...form, customerPhone: e.target.value })}
                className="w-full rounded-xl bg-slate-950 border border-slate-700 px-4 py-3 text-sm text-white focus:border-amber-400 focus:outline-none"
                placeholder="(75) 98155-8007"
              />
            </div>
            <div>
              <label className="mb-1 block text-xs font-bold uppercase text-slate-300">Endereço de Entrega</label>
              <input
                type="text"
                required
                value={form.customerAddress}
                onChange={(e) => setForm({ ...form, customerAddress: e.target.value })}
                className="w-full rounded-xl bg-slate-950 border border-slate-700 px-4 py-3 text-sm text-white focus:border-amber-400 focus:outline-none"
                placeholder="Rua, Número, Bairro, Cidade - UF"
              />
            </div>
          </div>

          {/* Payment Method Selector */}
          <div>
            <label className="mb-2 block text-xs font-bold uppercase text-slate-300">Forma de Pagamento</label>
            <div className="grid grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => setPaymentMethod("pix")}
                className={`flex items-center justify-center gap-2 rounded-2xl p-4 border text-sm font-extrabold transition-all ${
                  paymentMethod === "pix"
                    ? "bg-emerald-950/60 border-emerald-400 text-emerald-300 shadow-lg shadow-emerald-500/10"
                    : "bg-slate-950 border-slate-800 text-slate-400 hover:text-white"
                }`}
              >
                <QrCode size={20} /> Pix (Instantâneo)
              </button>

              <button
                type="button"
                onClick={() => setPaymentMethod("mercadopago")}
                className={`flex items-center justify-center gap-2 rounded-2xl p-4 border text-sm font-extrabold transition-all ${
                  paymentMethod === "mercadopago"
                    ? "bg-blue-950/60 border-blue-400 text-cyan-300 shadow-lg shadow-blue-500/10"
                    : "bg-slate-950 border-slate-800 text-slate-400 hover:text-white"
                }`}
              >
                <CreditCard size={20} /> Cartão / Mercado Pago
              </button>
            </div>
          </div>

          {/* Order Summary */}
          <div className="rounded-2xl bg-slate-950 p-5 border border-slate-800">
            <h3 className="text-xs font-black uppercase tracking-wider text-slate-400 mb-3">Resumo do Pedido</h3>
            {items.map((item, idx) => (
              <div key={idx} className="flex items-center justify-between py-2 border-b border-slate-800/80 last:border-0">
                <span className="text-sm font-medium text-slate-200">
                  {item.title} <span className="text-xs text-slate-500">x{item.qty}</span>
                </span>
                <span className="text-sm font-bold text-amber-400">R$ {(item.price * item.qty).toFixed(2)}</span>
              </div>
            ))}
            <div className="flex items-center justify-between pt-3 mt-2 border-t border-slate-800">
              <span className="text-base font-bold text-white">Total</span>
              <span className="text-2xl font-black text-amber-400">R$ {total.toFixed(2)}</span>
            </div>
          </div>

          <button
            type="submit"
            disabled={saving}
            className="w-full rounded-2xl bg-gradient-to-r from-amber-400 to-orange-400 px-6 py-4 text-base font-black uppercase text-slate-950 hover:brightness-110 disabled:opacity-60 transition-all shadow-xl shadow-amber-400/20"
          >
            {saving ? "Processando Pedido..." : "Confirmar Pedido"}
          </button>
        </form>

        {message && (
          <div
            className={`mt-6 rounded-2xl border p-5 text-sm shadow-lg ${
              message.includes("sucesso")
                ? "border-emerald-500/40 bg-emerald-950/40 text-emerald-200"
                : "border-rose-500/40 bg-rose-950/40 text-rose-200"
            }`}
          >
            {message}
            {orderId && (
              <p className="mt-2 text-xs font-bold text-white">
                Número do Pedido: <span className="font-mono text-amber-400 font-black">#{orderId}</span>
              </p>
            )}
          </div>
        )}

        {/* Pix Payment & Receipt Upload Box (Appears when Pix selected or order created) */}
        {paymentMethod === "pix" && orderId && (
          <div className="mt-8 rounded-3xl border-2 border-emerald-400/40 bg-gradient-to-b from-slate-950 via-slate-900 to-slate-950 p-6 md:p-8 shadow-2xl">
            <div className="flex items-center gap-3 border-b border-slate-800 pb-4">
              <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-emerald-400 text-slate-950 text-2xl font-black">
                ❖
              </div>
              <div>
                <span className="text-[10px] font-black uppercase tracking-widest text-emerald-400">PAGAMENTO PIX</span>
                <h3 className="text-xl font-black text-white">Pagar Pedido #{orderId} via Pix</h3>
              </div>
            </div>

            <div className="mt-6 space-y-4">
              <div className="rounded-2xl bg-slate-950 p-4 border border-slate-800">
                <span className="text-xs font-bold text-slate-400 block mb-1">Chave Pix Oficial (Telefone):</span>
                <div className="flex items-center justify-between gap-2">
                  <code className="text-lg font-mono font-black text-emerald-400">{pixKey}</code>
                  <button
                    type="button"
                    onClick={handleCopyPix}
                    className="flex items-center gap-1.5 rounded-xl bg-emerald-400 px-4 py-2 text-xs font-black text-slate-950 hover:bg-emerald-300 transition-all shadow-md"
                  >
                    {copiedPix ? <Check size={14} /> : <Copy size={14} />}
                    <span>{copiedPix ? "Chave Copiada!" : "Copiar Chave"}</span>
                  </button>
                </div>
              </div>

              {/* Receipt Upload Form */}
              <form onSubmit={handleSendReceipt} className="space-y-3 pt-2">
                <label className="block text-xs font-bold uppercase text-slate-300">
                  📄 Enviar Comprovante do Pix
                </label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    required
                    placeholder="Cole a URL ou link da foto do comprovante..."
                    value={receiptUrl}
                    onChange={(e) => setReceiptUrl(e.target.value)}
                    className="flex-1 rounded-xl bg-slate-950 border border-slate-700 px-4 py-2.5 text-xs text-white placeholder-slate-500 focus:border-emerald-400 focus:outline-none"
                  />
                  <button
                    type="submit"
                    disabled={sendingReceipt}
                    className="rounded-xl bg-emerald-400 px-5 py-2.5 text-xs font-black uppercase text-slate-950 hover:bg-emerald-300 transition-all shadow-lg shadow-emerald-400/20 disabled:opacity-60"
                  >
                    {sendingReceipt ? "Enviando..." : "Enviar Comprovante"}
                  </button>
                </div>
                <p className="text-[11px] text-slate-400">
                  O administrador irá conferir o comprovante e aprovar seu pedido com notificação sonora em tempo real.
                </p>
              </form>

              {receiptMessage && (
                <div className="mt-3 rounded-xl border border-emerald-400/40 bg-emerald-950/40 p-3 text-xs font-bold text-emerald-300">
                  {receiptMessage}
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </main>
  );
}
