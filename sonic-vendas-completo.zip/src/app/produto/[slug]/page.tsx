"use client";
import React, { useState, useEffect } from "react";
import { useParams } from "next/navigation";
import Link from "next/link";
import {
  ArrowLeft,
  CheckCircle,
  AlertTriangle,
  ShoppingCart,
  Clock,
  ShieldCheck,
  Truck,
  Award,
} from "lucide-react";

export default function ProductPage() {
  const params = useParams();
  const slug = params?.slug as string;

  const [product, setProduct] = useState<any | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!slug) return;
    fetch("/api/products")
      .then((r) => r.json())
      .then((res) => {
        if (res.ok && res.data) {
          const found = res.data.find((p: any) => p.slug === slug || String(p.id) === slug);
          setProduct(found || null);
        }
      })
      .catch(() => {})
      .finally(() => setLoading(false));
  }, [slug]);

  if (loading) {
    return (
      <main className="min-h-screen bg-[#040817] px-6 py-16 text-center text-slate-100 flex items-center justify-center">
        <div className="rounded-3xl border border-slate-800 bg-slate-900/60 p-8">
          <div className="h-8 w-8 animate-spin rounded-full border-4 border-amber-400 border-t-transparent mx-auto mb-3" />
          <p className="text-sm font-bold text-slate-300">Carregando detalhes do produto...</p>
        </div>
      </main>
    );
  }

  if (!product) {
    return (
      <main className="min-h-screen bg-[#040817] px-6 py-16 text-center text-slate-100">
        <h1 className="text-3xl font-extrabold text-white">Produto não encontrado</h1>
        <p className="mt-2 text-xs text-slate-400">O produto pode ter sido atualizado ou removido pelo administrador.</p>
        <Link
          href="/produtos"
          className="mt-6 inline-flex items-center gap-2 rounded-xl bg-amber-400 px-6 py-3 text-sm font-extrabold text-slate-950 hover:bg-amber-300 transition-all"
        >
          <ArrowLeft size={18} /> Ver Catálogo de Produtos
        </Link>
      </main>
    );
  }

  const warrantyLabel =
    product.hasWarranty === "sim_fabricante"
      ? "Garantia Oficial do Fabricante"
      : product.hasWarranty === "sim_loja"
      ? "Garantia Oficial da Loja Sonic Vendas"
      : product.hasWarranty === "sim_vitalicia"
      ? "Garantia Vitalícia"
      : "Garantia Padrão Sonic Vendas";

  return (
    <main className="min-h-screen bg-[#040817] text-slate-100 selection:bg-amber-400 selection:text-black px-4 py-8 md:px-6 md:py-12">
      <div className="mx-auto max-w-5xl">
        <Link
          href="/produtos"
          className="inline-flex items-center gap-2 text-sm font-bold text-amber-400 hover:text-amber-300 transition-colors mb-8"
        >
          <ArrowLeft size={18} /> Voltar para todos os produtos
        </Link>

        <div className="grid gap-10 md:grid-cols-12 items-start">
          {/* Product Image & Badges */}
          <div className="md:col-span-6 space-y-4">
            <div className="relative overflow-hidden rounded-3xl border border-slate-800 bg-slate-950 shadow-2xl">
              <img
                src={product.imageUrl || "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=800&q=80"}
                alt={product.title}
                className="h-full w-full object-cover"
                onError={(e) => {
                  (e.target as HTMLImageElement).src = "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=800&q=80";
                }}
              />
              {product.isPromotion && (
                <span className="absolute left-4 top-4 rounded-full bg-red-500 px-4 py-1.5 text-xs font-black uppercase tracking-wider text-white shadow-lg">
                  PROMOÇÃO {product.discountPercent}% OFF
                </span>
              )}
            </div>

            {/* Guarantees Box */}
            <div className="grid grid-cols-2 gap-3 text-xs text-slate-300">
              <div className="rounded-2xl border border-emerald-500/30 bg-emerald-950/30 p-3.5 flex items-center gap-2.5">
                <ShieldCheck size={20} className="text-emerald-400 shrink-0" />
                <div>
                  <span className="font-bold text-white block">Compra Protegida</span>
                  <span className="text-[10px] text-slate-400">Entrega garantida ou reembolso</span>
                </div>
              </div>

              <div className="rounded-2xl border border-amber-400/30 bg-amber-950/30 p-3.5 flex items-center gap-2.5">
                <Truck size={20} className="text-amber-400 shrink-0" />
                <div>
                  <span className="font-bold text-white block">Envio Seguro</span>
                  <span className="text-[10px] text-slate-400">Rastreamento para todo o Brasil</span>
                </div>
              </div>
            </div>
          </div>

          {/* Product Info & Purchase Action */}
          <div className="md:col-span-6 space-y-6">
            <div>
              <span className="rounded-full bg-slate-900 border border-slate-800 px-3 py-1 text-xs font-bold uppercase text-amber-400">
                {product.categoryName || "Eletrônicos & Produtos"}
              </span>

              <h1 className="mt-3 text-3xl md:text-4xl font-black tracking-tight text-white">
                {product.title}
              </h1>

              {/* Price */}
              <div className="mt-4 flex items-baseline gap-3">
                <span className="text-4xl md:text-5xl font-black text-amber-400">
                  R$ {Number(product.price).toFixed(2)}
                </span>
                {product.originalPrice && Number(product.originalPrice) > Number(product.price) && (
                  <span className="text-xl text-slate-500 line-through">
                    R$ {Number(product.originalPrice).toFixed(2)}
                  </span>
                )}
              </div>

              {/* Stock / Availability */}
              <div className="mt-3 flex items-center gap-2 text-xs font-bold text-slate-300">
                {product.availability === "available" ? (
                  <span className="inline-flex items-center gap-1.5 text-emerald-400">
                    <CheckCircle size={15} /> Em estoque — Pronto para envio imediato
                  </span>
                ) : product.availability === "out_of_stock" ? (
                  <span className="inline-flex items-center gap-1.5 text-rose-400">
                    <AlertTriangle size={15} /> Produto temporariamente esgotado
                  </span>
                ) : (
                  <span className="inline-flex items-center gap-1.5 text-amber-400">
                    <Clock size={15} /> Pré-venda disponível
                  </span>
                )}
              </div>
            </div>

            {/* Description */}
            <div className="rounded-2xl bg-slate-950/80 p-5 border border-slate-800 space-y-2">
              <span className="text-xs font-bold uppercase text-slate-400 block">Descrição Completa:</span>
              <p className="text-sm text-slate-200 leading-relaxed whitespace-pre-wrap">
                {product.description}
              </p>
            </div>

            {/* Warranty & Terms Breakdown */}
            <div className="rounded-2xl border-2 border-emerald-500/40 bg-emerald-950/20 p-5 space-y-3">
              <div className="flex items-center gap-2 text-emerald-300 font-bold text-sm">
                <Award size={18} /> {warrantyLabel}
              </div>

              <div className="text-xs text-slate-300 space-y-1.5">
                <p>
                  <strong>Prazo de Garantia:</strong>{" "}
                  <span className="text-amber-300 font-semibold">
                    {product.warrantyDuration || "90 dias de garantia oficial com suporte Sonic Vendas"}
                  </span>
                </p>
                <p>
                  <strong>Condições de Troca e Devolução:</strong>{" "}
                  <span className="text-slate-400">
                    {product.returnConditions || "Troca garantida em até 7 dias corridos após o recebimento em caso de defeito ou insatisfação."}
                  </span>
                </p>
              </div>
            </div>

            {/* Buy / Checkout Button */}
            <div className="space-y-3 pt-2">
              <Link
                href="/checkout"
                className="flex w-full items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-amber-400 to-orange-400 py-4 text-base font-black uppercase text-slate-950 shadow-xl shadow-amber-400/20 hover:brightness-110 transition-all"
              >
                <ShoppingCart size={20} /> Comprar Agora via Pix / Cartão
              </Link>

              <a
                href={`https://wa.me/5575981558007?text=Olá,%20tenho%20interesse%20no%20produto:%20${encodeURIComponent(product.title)}%20(R$%20${Number(product.price).toFixed(2)})`}
                target="_blank"
                rel="noreferrer"
                className="flex w-full items-center justify-center gap-2 rounded-2xl border border-emerald-400/40 bg-emerald-950/30 py-3 text-xs font-bold text-emerald-300 hover:bg-emerald-500 hover:text-slate-950 transition-all"
              >
                Tirar Dúvidas com Suporte no WhatsApp
              </a>
            </div>
          </div>
        </div>
      </div>
    </main>
  );
}
