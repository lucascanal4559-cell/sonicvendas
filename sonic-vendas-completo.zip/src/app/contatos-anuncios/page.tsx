"use client";
import React, { useState, useEffect } from "react";
import Link from "next/link";
import {
  User,
  ArrowLeft,
  Sparkles,
  MapPin,
  ExternalLink,
  MessageCircle,
  PlusCircle,
  Zap,
  Eye,
  Video,
  Copy,
  Check,
  ShieldCheck,
  Flame,
} from "lucide-react";
import { playSound } from "@/lib/sounds";

export default function ContatosAnunciosPage() {
  const [ads, setAds] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  // Boost modal
  const [boostAd, setBoostAd] = useState<any | null>(null);
  const [boostPlan, setBoostPlan] = useState("topo_7d");
  const [boostName, setBoostName] = useState("");
  const [boostPhone, setBoostPhone] = useState("");
  const [boostReceiptUrl, setBoostReceiptUrl] = useState("");
  const [boostSending, setBoostSending] = useState(false);
  const [boostSuccess, setBoostSuccess] = useState(false);
  const [copiedPix, setCopiedPix] = useState(false);

  const pixKey = "75981558007";

  const boostPlans = [
    { id: "topo_3d", name: "Destaque Topo 3 Dias", days: 3, price: 5.0 },
    { id: "topo_7d", name: "Destaque Topo 7 Dias (Mais Popular)", days: 7, price: 10.0 },
    { id: "ouro_15d", name: "Destaque Ouro Super Topo 15 Dias", days: 15, price: 20.0 },
    { id: "maximo_30d", name: "Destaque Máximo 30 Dias + Borda Ouro", days: 30, price: 35.0 },
  ];

  const currentBoostPlanObj = boostPlans.find((p) => p.id === boostPlan) || boostPlans[1];

  async function load() {
    setLoading(true);
    try {
      const res = await fetch("/api/contact-ads");
      const data = await res.json();
      if (data.ok) setAds(data.data || []);
    } catch {
      // ignore
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
  }, []);

  async function trackEvent(id: number, type: "view" | "whatsapp" | "link") {
    try {
      fetch("/api/contact-ads/click", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id, type }),
      }).catch(() => {});
    } catch {}
  }

  async function handleBoostSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!boostAd) return;
    setBoostSending(true);

    try {
      const res = await fetch("/api/ads/boost", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          adType: "contact",
          adId: boostAd.id,
          customerName: boostName,
          customerPhone: boostPhone,
          planName: currentBoostPlanObj.name,
          days: currentBoostPlanObj.days,
          amount: currentBoostPlanObj.price.toFixed(2),
          receiptUrl: boostReceiptUrl || null,
        }),
      });

      const data = await res.json();
      if (data.ok) {
        playSound("payment_confirmed");
        setBoostSuccess(true);
        load();
      } else {
        alert(data.error || "Erro ao solicitar impulsionamento.");
      }
    } catch {
      alert("Erro de conexão.");
    } finally {
      setBoostSending(false);
    }
  }

  function handleCopyPix() {
    navigator.clipboard.writeText(pixKey);
    setCopiedPix(true);
    setTimeout(() => setCopiedPix(false), 2000);
  }

  return (
    <main className="min-h-screen bg-[#040817] text-slate-100 selection:bg-amber-400 selection:text-black px-4 py-8 md:px-6 md:py-12">
      <div className="mx-auto max-w-6xl">
        {/* Navigation Breadcrumb */}
        <div className="flex flex-col md:flex-row items-center justify-between gap-4 border-b border-slate-800 pb-6">
          <Link
            href="/"
            className="inline-flex items-center gap-2 text-sm font-bold text-amber-400 hover:text-amber-300 transition-colors"
          >
            <ArrowLeft size={18} /> Voltar à Loja
          </Link>

          <div className="flex items-center gap-3">
            <Link
              href="/negocios-anuncios"
              className="rounded-2xl border border-cyan-400/30 bg-blue-950/40 px-4 py-2 text-xs font-bold text-cyan-300 hover:bg-cyan-500 hover:text-slate-950 transition-all"
            >
              💼 Ver Anúncios de Negócios
            </Link>
            <Link
              href="/divulgar-contatos"
              className="inline-flex items-center gap-2 rounded-2xl bg-gradient-to-r from-amber-400 to-orange-400 px-5 py-2.5 text-xs font-black uppercase text-slate-950 shadow-lg shadow-amber-400/20 hover:scale-105 transition-all"
            >
              <PlusCircle size={16} /> Divulgar Meu Contato (R$ 1/dia)
            </Link>
          </div>
        </div>

        {/* Header */}
        <div className="mt-8 text-center md:mt-10">
          <div className="inline-flex items-center gap-2 rounded-full bg-amber-400/10 px-5 py-2 border border-amber-400/30 shadow-md mb-3">
            <User className="text-amber-400" size={18} />
            <span className="text-xs font-black uppercase tracking-wider text-amber-300">
              PERFIS E CONTATOS VERIFICADOS • SONIC VENDAS
            </span>
          </div>

          <h1 className="text-4xl font-black tracking-tight text-white md:text-6xl">
            DIVULGAÇÃO DE <span className="text-amber-400">CONTATOS</span>
          </h1>

          <p className="mx-auto mt-2 max-w-2xl text-sm md:text-base text-slate-300">
            Conheça pessoas, profissionais, criadores de conteúdo e perfis da comunidade Sonic Vendas.
          </p>
        </div>

        {/* Contacts Grid */}
        <div className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {ads.map((ad) => {
            const isBoosted = ad.isBoosted;
            const waUrl = `https://wa.me/55${ad.phone.replace(/\D/g, "")}?text=Olá%20${encodeURIComponent(ad.name)},%20vi%20seu%20perfil%20na%20Sonic%20Vendas!`;

            return (
              <div
                key={ad.id}
                onMouseEnter={() => trackEvent(ad.id, "view")}
                className={`group relative flex flex-col justify-between overflow-hidden rounded-3xl p-6 shadow-xl backdrop-blur-md transition-all hover:-translate-y-1 ${
                  isBoosted
                    ? "border-2 border-amber-400 bg-gradient-to-b from-amber-950/40 via-slate-900 to-slate-950 shadow-amber-400/15"
                    : "border border-slate-800 bg-slate-900/60 hover:border-slate-700"
                }`}
              >
                <div>
                  {/* Top Image + Badges */}
                  <div className="relative mb-4 h-56 w-full overflow-hidden rounded-2xl bg-slate-950">
                    <img
                      src={ad.profilePhoto || "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=500&q=80"}
                      alt={ad.name}
                      className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
                      onError={(e) => {
                        (e.target as HTMLImageElement).src = "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=500&q=80";
                      }}
                    />
                    <div className="absolute top-3 left-3 flex flex-wrap gap-1">
                      {isBoosted && (
                        <span className="rounded-full bg-amber-400 px-3 py-0.5 text-[10px] font-black uppercase text-slate-950 shadow-md flex items-center gap-1">
                          <Zap size={12} /> TOP DESTAQUE
                        </span>
                      )}
                      {ad.age && (
                        <span className="rounded-full bg-slate-950/80 px-2.5 py-0.5 text-[10px] font-bold text-slate-300 backdrop-blur-md border border-slate-700">
                          {ad.age}
                        </span>
                      )}
                    </div>

                    {ad.city && (
                      <div className="absolute bottom-3 left-3 flex items-center gap-1 rounded-full bg-slate-950/90 px-3 py-1 text-[11px] font-bold text-slate-300 backdrop-blur-md">
                        <MapPin size={12} className="text-amber-400" /> {ad.city}
                      </div>
                    )}
                  </div>

                  <h3 className="text-xl font-black text-white group-hover:text-amber-400 transition-colors">
                    {ad.name}
                  </h3>

                  <p className="mt-2 line-clamp-3 text-xs text-slate-300 leading-relaxed">
                    {ad.description}
                  </p>

                  {/* Video badge if available */}
                  {ad.videoUrl && (
                    <a
                      href={ad.videoUrl}
                      target="_blank"
                      rel="noreferrer"
                      className="mt-3 inline-flex items-center gap-1.5 rounded-lg bg-pink-950/40 border border-pink-500/30 px-2.5 py-1 text-[11px] font-bold text-pink-300 hover:bg-pink-500 hover:text-slate-950 transition-colors"
                    >
                      <Video size={13} /> Assistir Vídeo (2 min)
                    </a>
                  )}

                  {/* Metrics preview */}
                  <div className="mt-4 flex items-center gap-4 text-[11px] text-slate-400 border-t border-slate-800/80 pt-3">
                    <span className="flex items-center gap-1">
                      <Eye size={13} /> {ad.viewsCount || 0} visualizações
                    </span>
                    <span className="flex items-center gap-1">
                      <MessageCircle size={13} /> {ad.clicksWhatsapp || 0} contatos
                    </span>
                  </div>
                </div>

                {/* Actions & WhatsApp button */}
                <div className="mt-5 space-y-2">
                  <a
                    href={waUrl}
                    target="_blank"
                    rel="noreferrer"
                    onClick={() => trackEvent(ad.id, "whatsapp")}
                    className="flex w-full items-center justify-center gap-2 rounded-2xl bg-emerald-500 py-3 text-xs font-black uppercase tracking-wider text-slate-950 shadow-lg shadow-emerald-500/20 hover:bg-emerald-400 transition-all"
                  >
                    <MessageCircle size={16} /> Chamar no WhatsApp
                  </a>

                  <div className="flex gap-2">
                    {ad.contactLink && (
                      <a
                        href={ad.contactLink}
                        target="_blank"
                        rel="noreferrer"
                        onClick={() => trackEvent(ad.id, "link")}
                        className="flex-1 rounded-xl bg-slate-900 border border-slate-800 py-2 text-center text-xs font-bold text-slate-300 hover:text-white hover:bg-slate-800 transition-colors"
                      >
                        Ver Perfil / Link <ExternalLink size={12} className="inline ml-1" />
                      </a>
                    )}
                    <button
                      type="button"
                      onClick={() => {
                        setBoostAd(ad);
                        setBoostName(ad.name);
                        setBoostPhone(ad.phone);
                        setBoostSuccess(false);
                      }}
                      className="rounded-xl border border-amber-400/40 bg-amber-950/30 px-3 py-2 text-xs font-black text-amber-300 hover:bg-amber-400 hover:text-slate-950 transition-all flex items-center gap-1"
                    >
                      <Zap size={14} /> Impulsionar
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {ads.length === 0 && !loading && (
          <div className="mt-12 rounded-3xl border border-slate-800 bg-slate-900/40 p-12 text-center text-slate-500 shadow-xl">
            Nenhum perfil de contato anunciado no momento.
            <div className="mt-4">
              <Link
                href="/divulgar-contatos"
                className="inline-flex items-center gap-2 rounded-xl bg-amber-400 px-5 py-2.5 text-xs font-black uppercase text-slate-950 hover:bg-amber-300 transition-all"
              >
                Cadastrar o Primeiro Contato
              </Link>
            </div>
          </div>
        )}
      </div>

      {/* Boost Modal */}
      {boostAd && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 backdrop-blur-md">
          <div className="relative w-full max-w-lg rounded-3xl border-2 border-amber-400/50 bg-slate-950 p-6 md:p-8 shadow-2xl">
            <button
              onClick={() => setBoostAd(null)}
              className="absolute top-6 right-6 rounded-full bg-slate-800 p-2 text-slate-400 hover:bg-slate-700 hover:text-white"
            >
              ✕
            </button>

            {!boostSuccess ? (
              <form onSubmit={handleBoostSubmit} className="space-y-4">
                <div className="border-b border-slate-800 pb-3">
                  <span className="text-[10px] font-black uppercase tracking-widest text-amber-400">
                    IMPULSIONAR ANÚNCIO NO TOPO
                  </span>
                  <h3 className="text-xl font-black text-white">{boostAd.name}</h3>
                  <p className="text-xs text-slate-400">Ganhe até 5x mais visualizações e cliques no WhatsApp.</p>
                </div>

                <div>
                  <label className="mb-1 block text-xs font-bold text-slate-300">Escolha o Plano de Destaque</label>
                  <div className="space-y-2">
                    {boostPlans.map((plan) => (
                      <div
                        key={plan.id}
                        onClick={() => setBoostPlan(plan.id)}
                        className={`cursor-pointer rounded-2xl p-3 border flex items-center justify-between text-xs transition-all ${
                          boostPlan === plan.id
                            ? "border-amber-400 bg-amber-950/40 text-white font-bold"
                            : "border-slate-800 bg-slate-900 text-slate-400 hover:bg-slate-800"
                        }`}
                      >
                        <div>
                          <span className="font-black text-white block">{plan.name}</span>
                          <span className="text-[10px] text-slate-400">{plan.days} dias de destaque no Topo</span>
                        </div>
                        <span className="text-base font-black text-amber-400">R$ {plan.price.toFixed(2)}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="grid gap-3 md:grid-cols-2">
                  <div>
                    <label className="mb-1 block text-xs font-bold text-slate-300">Seu Nome</label>
                    <input
                      type="text"
                      required
                      value={boostName}
                      onChange={(e) => setBoostName(e.target.value)}
                      className="w-full rounded-xl bg-slate-900 border border-slate-700 px-3 py-2 text-xs text-white"
                    />
                  </div>
                  <div>
                    <label className="mb-1 block text-xs font-bold text-slate-300">WhatsApp</label>
                    <input
                      type="text"
                      required
                      value={boostPhone}
                      onChange={(e) => setBoostPhone(e.target.value)}
                      className="w-full rounded-xl bg-slate-900 border border-slate-700 px-3 py-2 text-xs text-white"
                    />
                  </div>
                </div>

                {/* Comprovante Pix upload */}
                <div className="rounded-2xl border border-amber-400/40 bg-slate-900 p-4">
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-xs font-bold text-amber-400">Pagar R$ {currentBoostPlanObj.price.toFixed(2)} via Pix:</span>
                    <button
                      type="button"
                      onClick={handleCopyPix}
                      className="text-[10px] text-emerald-400 hover:underline font-bold"
                    >
                      {copiedPix ? "Chave Copiada!" : `Copiar Pix: ${pixKey}`}
                    </button>
                  </div>
                  <input
                    type="text"
                    placeholder="Cole a URL ou foto do comprovante..."
                    value={boostReceiptUrl}
                    onChange={(e) => setBoostReceiptUrl(e.target.value)}
                    className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-xs text-white"
                  />
                </div>

                <button
                  type="submit"
                  disabled={boostSending}
                  className="w-full rounded-2xl bg-gradient-to-r from-amber-400 via-orange-400 to-amber-300 py-3.5 text-xs font-black uppercase text-slate-950 hover:brightness-110 shadow-lg shadow-amber-400/20 disabled:opacity-60"
                >
                  {boostSending ? "Enviando..." : `Confirmar Impulsionamento (R$ ${currentBoostPlanObj.price.toFixed(2)})`}
                </button>
              </form>
            ) : (
              <div className="text-center space-y-4 py-4">
                <div className="text-4xl">🚀</div>
                <h4 className="text-xl font-black text-white">Solicitação de Impulsionamento Enviada!</h4>
                <p className="text-xs text-slate-300">
                  O administrador irá conferir o comprovante e ativar o destaque Topo de <strong>{currentBoostPlanObj.name}</strong> para {boostAd.name}.
                </p>
                <button
                  onClick={() => setBoostAd(null)}
                  className="rounded-2xl bg-amber-400 px-6 py-2.5 text-xs font-black uppercase text-slate-950 hover:bg-amber-300"
                >
                  Fechar
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </main>
  );
}
