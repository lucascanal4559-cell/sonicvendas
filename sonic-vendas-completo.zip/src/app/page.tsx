import { db } from "@/db";
import { products, categories, banners, contactAds, businessAds, raffles } from "@/db/schema";
import { desc, eq } from "drizzle-orm";
import Link from "next/link";
import {
  ArrowRight,
  Sparkles,
  User,
  Store,
  Trophy,
  Tv,
  Gift,
  ShieldCheck,
  Truck,
  Clock,
  Star,
  ExternalLink,
  MessageCircle,
  Zap,
} from "lucide-react";

export const dynamic = "force-dynamic";
export const revalidate = 5;

export default async function HomePage() {
  const [productList, bannersList, categoriesList, topContacts, topBusinesses, featuredRaffles] =
    await Promise.all([
      db.select().from(products).where(eq(products.isActive, true)).orderBy(desc(products.createdAt)).limit(8),
      db.select().from(banners).where(eq(banners.isActive, true)).orderBy(banners.order, banners.createdAt).limit(3),
      db.select().from(categories).where(eq(categories.isActive, true)).orderBy(categories.name).limit(8),
      db.select().from(contactAds).where(eq(contactAds.isActive, true)).orderBy(desc(contactAds.isBoosted), desc(contactAds.createdAt)).limit(3),
      db.select().from(businessAds).where(eq(businessAds.isActive, true)).orderBy(desc(businessAds.isBoosted), desc(businessAds.createdAt)).limit(3),
      db.select().from(raffles).where(eq(raffles.isActive, true)).orderBy(desc(raffles.isFeatured), desc(raffles.createdAt)).limit(3),
    ]);

  return (
    <main className="min-h-screen bg-gradient-to-b from-slate-950 via-slate-900 to-amber-950/20 text-slate-100 selection:bg-amber-400 selection:text-black">
      {/* Logotipo & Brand Header */}
      <section className="mx-auto max-w-6xl px-4 sm:px-6 pt-8 pb-3">
        <a href="/" className="inline-flex items-center gap-3">
          <div className="h-12 w-12 rounded-2xl bg-gradient-to-br from-amber-400 to-amber-600 flex items-center justify-center shadow-xl shadow-amber-400/30">
            <span className="text-2xl font-black text-slate-950">S</span>
          </div>
          <div>
            <h1 className="text-2xl font-black tracking-tight text-white leading-none">Sonic Vendas</h1>
            <p className="text-xs font-black text-amber-400 tracking-widest uppercase">PREMIUM STORE</p>
          </div>
        </a>
      </section>

      {/* 1. Hero Banner */}
      <section className="relative overflow-hidden">
        {bannersList.length > 0 && bannersList[0] ? (
          <div className="relative h-[55vh] min-h-[380px] w-full">
            <img src={bannersList[0].imageUrl} alt={bannersList[0].title} className="h-full w-full object-cover" />
            <div className="absolute inset-0 bg-gradient-to-r from-slate-950/90 via-slate-950/50 to-transparent" />
            <div className="absolute inset-0 flex items-center px-6 md:px-16">
              <div className="max-w-2xl">
                <h1 className="text-4xl font-black leading-tight tracking-tight text-white md:text-6xl drop-shadow-lg">
                  {bannersList[0].title}
                </h1>
                <p className="mt-3 text-base text-slate-200 md:text-lg">{bannersList[0].subtitle}</p>
                <div className="mt-6 flex flex-wrap gap-3">
                  <Link
                    href="#produtos"
                    className="inline-flex items-center gap-2 rounded-xl bg-amber-400 px-6 py-3 text-sm font-extrabold text-slate-950 shadow-xl shadow-amber-400/20 hover:bg-amber-300 transition-all"
                  >
                    Ver Produtos <ArrowRight size={18} />
                  </Link>
                  <Link
                    href="/servicos-sociais"
                    className="inline-flex items-center gap-2 rounded-xl border border-pink-400/40 bg-pink-950/60 px-5 py-3 text-xs font-black uppercase text-pink-300 hover:bg-pink-500 hover:text-slate-950 transition-all shadow-md"
                  >
                    📱 Redes Sociais & Seguidores
                  </Link>
                </div>
              </div>
            </div>
          </div>
        ) : (
          <div className="relative h-[55vh] min-h-[380px] w-full bg-gradient-to-r from-amber-500 via-orange-500 to-amber-600 flex items-center px-6 md:px-16">
            <div className="max-w-2xl">
              <h1 className="text-4xl font-black leading-tight tracking-tight text-slate-950 md:text-6xl drop-shadow-md">
                Sonic Vendas
              </h1>
              <p className="mt-3 text-lg text-slate-900/90">A melhor experiência de compras online e publicidade.</p>
              <Link
                href="#produtos"
                className="mt-6 inline-flex items-center gap-2 rounded-xl bg-slate-950 px-6 py-3 text-sm font-extrabold text-white shadow-xl hover:bg-slate-900 transition-all"
              >
                Explorar Produtos <ArrowRight size={18} />
              </Link>
            </div>
          </div>
        )}
      </section>

      {/* 2. Redes Sociais & Engajamento IA Spotlight Banner */}
      <section className="mx-auto max-w-6xl px-4 sm:px-6 py-6">
        <div className="relative overflow-hidden rounded-3xl border-2 border-pink-500/50 bg-gradient-to-r from-pink-950/80 via-slate-950 to-purple-950/80 p-6 md:p-8 shadow-[0_0_40px_rgba(236,72,153,0.25)] backdrop-blur-xl">
          <div className="flex flex-col md:flex-row items-center justify-between gap-6">
            <div className="flex items-center gap-4">
              <div className="flex h-16 w-16 shrink-0 items-center justify-center rounded-2xl bg-gradient-to-tr from-pink-500 to-purple-600 text-3xl shadow-lg shadow-pink-500/40">
                <span>📱</span>
              </div>
              <div>
                <div className="inline-flex items-center gap-2 rounded-full bg-pink-500/20 px-3 py-0.5 text-[11px] font-black uppercase text-pink-300">
                  🔥 INSTAGRAM, TIKTOK, KWAI & FREE FIRE • CALCULADORA IA
                </div>
                <h3 className="mt-1 text-2xl md:text-3xl font-black text-white">
                  SEGUIDORES, CURTIDAS & <span className="text-pink-400">ENGAJAMENTO REAL</span>
                </h3>
                <p className="mt-1 text-xs md:text-sm text-slate-300">
                  Seguidores com reposição até 365 dias, visualizações em Reels e planos mensais. Escolha a quantidade e pague via Pix ou Cartão!
                </p>
              </div>
            </div>

            <Link
              href="/servicos-sociais"
              className="inline-flex shrink-0 items-center gap-2 rounded-2xl bg-gradient-to-r from-pink-500 via-purple-500 to-amber-400 px-6 py-3.5 text-sm font-black uppercase tracking-wider text-slate-950 shadow-xl shadow-pink-500/30 hover:scale-105 transition-all"
            >
              VER TABELA & PREÇOS <ArrowRight size={18} />
            </Link>
          </div>
        </div>
      </section>

      {/* 3. Divulgação de Contatos (Destaques) */}
      <section className="mx-auto max-w-6xl px-4 sm:px-6 py-6">
        <div className="flex flex-col sm:flex-row items-start sm:items-end justify-between gap-2 mb-6">
          <div>
            <div className="flex items-center gap-2 text-xs font-black uppercase text-amber-400">
              <User size={16} /> APRESENTAÇÕES PESSOAIS & PERFIS
            </div>
            <h2 className="text-2xl md:text-3xl font-black text-white mt-1">Divulgação de Contatos</h2>
            <p className="text-xs text-slate-400">Divulgue seu perfil pessoal e WhatsApp por apenas R$ 1,00/dia.</p>
          </div>

          <div className="flex gap-2">
            <Link
              href="/divulgar-contatos"
              className="rounded-xl border border-amber-400/30 bg-amber-950/40 px-3.5 py-1.5 text-xs font-black uppercase text-amber-300 hover:bg-amber-400 hover:text-slate-950 transition-all"
            >
              + Anunciar Contato
            </Link>
            <Link
              href="/contatos-anuncios"
              className="rounded-xl bg-slate-900 border border-slate-800 px-3.5 py-1.5 text-xs font-bold text-slate-300 hover:text-white"
            >
              Ver Todos →
            </Link>
          </div>
        </div>

        <div className="grid gap-6 sm:grid-cols-2 md:grid-cols-3">
          {topContacts.map((ad) => (
            <div
              key={ad.id}
              className={`rounded-3xl p-5 border flex flex-col justify-between shadow-xl ${
                ad.isBoosted
                  ? "border-amber-400/60 bg-gradient-to-b from-amber-950/30 via-slate-900 to-slate-950"
                  : "border-slate-800 bg-slate-900/60"
              }`}
            >
              <div>
                <div className="relative mb-3 h-44 w-full overflow-hidden rounded-2xl bg-slate-950">
                  <img src={ad.profilePhoto || "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=500&q=80"} alt={ad.name} className="h-full w-full object-cover" />
                  {ad.isBoosted && (
                    <span className="absolute top-2 left-2 rounded-full bg-amber-400 px-2.5 py-0.5 text-[9px] font-black uppercase text-slate-950 shadow">
                      ⚡ TOP
                    </span>
                  )}
                  {ad.city && (
                    <span className="absolute bottom-2 left-2 rounded-full bg-slate-950/80 px-2 py-0.5 text-[10px] text-slate-300 backdrop-blur-md">
                      📍 {ad.city}
                    </span>
                  )}
                </div>

                <h4 className="text-lg font-black text-white">{ad.name}</h4>
                <p className="mt-1 text-xs text-slate-300 line-clamp-2">{ad.description}</p>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-800">
                <a
                  href={`https://wa.me/55${ad.phone.replace(/\D/g, "")}`}
                  target="_blank"
                  rel="noreferrer"
                  className="flex w-full items-center justify-center gap-1.5 rounded-xl bg-emerald-500 py-2.5 text-xs font-black uppercase text-slate-950 hover:bg-emerald-400"
                >
                  <MessageCircle size={14} /> Chamar no WhatsApp
                </a>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 4. Divulgação de Vendas e Negócios (Lojas & Empresas) */}
      <section className="mx-auto max-w-6xl px-4 sm:px-6 py-6">
        <div className="flex flex-col sm:flex-row items-start sm:items-end justify-between gap-2 mb-6">
          <div>
            <div className="flex items-center gap-2 text-xs font-black uppercase text-cyan-400">
              <Store size={16} /> LOJAS, PRODUTOS, SERVIÇOS & EMPRESAS
            </div>
            <h2 className="text-2xl md:text-3xl font-black text-white mt-1">Divulgação de Vendas & Negócios</h2>
            <p className="text-xs text-slate-400">Anúncios comerciais com Orçamento Inteligente gerado por IA.</p>
          </div>

          <div className="flex gap-2">
            <Link
              href="/divulgar-negocios"
              className="rounded-xl border border-cyan-400/30 bg-blue-950/40 px-3.5 py-1.5 text-xs font-black uppercase text-cyan-300 hover:bg-cyan-400 hover:text-slate-950 transition-all"
            >
              + Anunciar Meu Negócio
            </Link>
            <Link
              href="/negocios-anuncios"
              className="rounded-xl bg-slate-900 border border-slate-800 px-3.5 py-1.5 text-xs font-bold text-slate-300 hover:text-white"
            >
              Ver Todas as Lojas →
            </Link>
          </div>
        </div>

        <div className="grid gap-6 sm:grid-cols-2 md:grid-cols-3">
          {topBusinesses.map((b) => (
            <div
              key={b.id}
              className={`rounded-3xl p-5 border flex flex-col justify-between shadow-xl ${
                b.isBoosted
                  ? "border-cyan-400/60 bg-gradient-to-b from-blue-950/30 via-slate-900 to-slate-950"
                  : "border-slate-800 bg-slate-900/60"
              }`}
            >
              <div>
                <div className="relative mb-3 h-44 w-full overflow-hidden rounded-2xl bg-slate-950">
                  <img src={b.photoUrl || "https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=600&q=80"} alt={b.businessName} className="h-full w-full object-cover" />
                  <span className="absolute top-2 left-2 rounded-full bg-slate-950/90 px-2.5 py-0.5 text-[9px] font-black uppercase text-cyan-400 border border-cyan-500/30">
                    {b.category}
                  </span>
                  {b.productPrice && (
                    <span className="absolute bottom-2 right-2 rounded-xl bg-amber-400 px-2.5 py-0.5 text-xs font-black text-slate-950">
                      R$ {Number(b.productPrice).toFixed(2)}
                    </span>
                  )}
                </div>

                <span className="text-[11px] font-bold text-cyan-400 block">{b.businessName}</span>
                <h4 className="text-base font-black text-white mt-0.5">{b.adTitle}</h4>
                <p className="mt-1 text-xs text-slate-300 line-clamp-2">{b.description}</p>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-800 space-y-2">
                <a
                  href={`https://wa.me/55${b.phone.replace(/\D/g, "")}`}
                  target="_blank"
                  rel="noreferrer"
                  className="flex w-full items-center justify-center gap-1.5 rounded-xl bg-emerald-500 py-2.5 text-xs font-black uppercase text-slate-950 hover:bg-emerald-400"
                >
                  <MessageCircle size={14} /> WhatsApp Comercial
                </a>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 5. Sorteios & Cotas Spotlight Banner */}
      <section className="mx-auto max-w-6xl px-4 sm:px-6 py-4">
        <div className="relative overflow-hidden rounded-3xl border-2 border-amber-400/50 bg-gradient-to-r from-amber-950/80 via-slate-950 to-orange-950/80 p-6 md:p-8 shadow-[0_0_40px_rgba(245,158,11,0.2)] backdrop-blur-xl">
          <div className="flex flex-col md:flex-row items-center justify-between gap-6">
            <div className="flex items-center gap-4">
              <div className="flex h-16 w-16 shrink-0 items-center justify-center rounded-2xl bg-gradient-to-tr from-amber-500 to-orange-400 text-3xl shadow-lg shadow-amber-500/40">
                <span>🎯</span>
              </div>
              <div>
                <div className="inline-flex items-center gap-2 rounded-full bg-amber-400/20 px-3 py-0.5 text-[11px] font-black uppercase text-amber-300">
                  🏆 SORTEIOS OFICIAIS • LOTERIA FEDERAL
                </div>
                <h3 className="mt-1 text-2xl md:text-3xl font-black text-white">
                  CONCORRA A <span className="text-amber-400">IPHONES & PC GAMER</span>
                </h3>
                <p className="mt-1 text-xs md:text-sm text-slate-300">
                  Cotas a partir de R$ 0,01! Geração automática de códigos sem duplicidades e revelação oficial nas lives.
                </p>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-3">
              <Link
                href="/sorteios"
                className="inline-flex shrink-0 items-center gap-2 rounded-2xl bg-gradient-to-r from-amber-400 to-orange-400 px-6 py-3.5 text-sm font-black uppercase tracking-wider text-slate-950 shadow-xl shadow-amber-400/30 hover:scale-105 transition-all"
              >
                VER SORTEIOS & COTAS <ArrowRight size={18} />
              </Link>
              <Link
                href="/roleta"
                className="inline-flex shrink-0 items-center gap-1.5 rounded-2xl border border-pink-400/40 bg-pink-950/40 px-4 py-3.5 text-xs font-black uppercase text-pink-300 hover:bg-pink-500 hover:text-slate-950 transition-all"
              >
                🎡 Girar Roleta
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* 6. IPTV 12 Hours Banner */}
      <section className="mx-auto max-w-6xl px-4 sm:px-6 py-4">
        <div className="relative overflow-hidden rounded-3xl border-2 border-cyan-400/50 bg-gradient-to-r from-[#030d2e] via-blue-950 to-slate-950 p-6 md:p-8 shadow-[0_0_40px_rgba(6,182,212,0.25)] backdrop-blur-xl">
          <div className="flex flex-col md:flex-row items-center justify-between gap-6">
            <div className="flex items-center gap-4">
              <div className="flex h-16 w-16 shrink-0 items-center justify-center rounded-2xl bg-gradient-to-tr from-blue-600 to-cyan-400 text-3xl shadow-lg shadow-cyan-500/40">
                <span>📺</span>
              </div>
              <div>
                <div className="inline-flex items-center gap-2 rounded-full bg-cyan-400/20 px-3 py-0.5 text-[11px] font-black uppercase text-cyan-300">
                  ⚡ TESTE GRÁTIS DE 12 HORAS
                </div>
                <h3 className="mt-1 text-2xl md:text-3xl font-black text-white">
                  IPTV — ASSISTA POR <span className="text-amber-400">12 HORAS GRÁTIS!</span>
                </h3>
                <p className="mt-1 text-xs md:text-sm text-slate-300">
                  Canais de TV ao vivo, Filmes lançamentos, Séries, Esportes. Teste na sua Smart TV, Celular ou PC!
                </p>
              </div>
            </div>

            <Link
              href="/iptv"
              className="inline-flex shrink-0 items-center gap-2 rounded-2xl bg-gradient-to-r from-cyan-400 to-blue-500 px-6 py-3.5 text-sm font-black uppercase tracking-wider text-slate-950 shadow-xl shadow-cyan-400/30 hover:scale-105 transition-all"
            >
              SOLICITAR ACESSO IPTV 12H <ArrowRight size={18} />
            </Link>
          </div>
        </div>
      </section>

      {/* 7. Produtos da Loja em Destaque com Garantia */}
      <section id="produtos" className="mx-auto max-w-6xl px-4 sm:px-6 py-12">
        <div className="mb-8 flex items-end justify-between">
          <div>
            <span className="text-xs font-black uppercase text-amber-400 tracking-wider">PRODUTOS SELECIONADOS</span>
            <h2 className="text-3xl font-black tracking-tight text-white mt-1">Produtos com Garantia Oficial</h2>
            <p className="mt-1 text-xs text-slate-400">Eletrônicos e acessórios com procedência, garantia da loja e envio para todo o Brasil.</p>
          </div>
          <Link href="/produtos" className="hidden md:inline-flex items-center gap-1.5 text-sm font-bold text-amber-400 hover:text-amber-300 transition-colors">
            Ver catálogo completo <ArrowRight size={16} />
          </Link>
        </div>

        <div className="grid gap-6 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4">
          {productList.map((p: any) => (
            <Link
              key={p.id}
              href={`/produto/${p.slug}`}
              className="group relative overflow-hidden rounded-3xl border border-slate-800 bg-slate-900/60 shadow-xl transition-all hover:scale-[1.02] hover:shadow-2xl hover:shadow-amber-400/5 flex flex-col justify-between"
            >
              <div>
                <div className="relative h-52 overflow-hidden bg-slate-950">
                  {p.imageUrl ? (
                    <img
                      src={p.imageUrl}
                      alt={p.title}
                      className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-110"
                    />
                  ) : (
                    <div className="h-full w-full flex items-center justify-center bg-slate-800 text-slate-500 text-sm font-medium">
                      Sem imagem disponível
                    </div>
                  )}
                  {p.isPromotion && (
                    <span className="absolute left-3 top-3 rounded-full bg-red-500 px-3 py-1 text-[10px] font-extrabold uppercase tracking-wide text-white shadow-lg">
                      Promoção {p.discountPercent}%
                    </span>
                  )}
                </div>

                <div className="p-5">
                  <span className="text-[10px] font-bold uppercase text-slate-500">
                    {p.categoryName || "Eletrônicos"}
                  </span>
                  <h3 className="text-base font-black text-slate-100 group-hover:text-amber-400 transition-colors mt-0.5">
                    {p.title}
                  </h3>
                  <p className="mt-2 line-clamp-2 text-xs text-slate-400">{p.description}</p>

                  <div className="mt-3 flex items-center gap-1 text-[11px] text-emerald-400 font-bold">
                    <ShieldCheck size={14} /> Garantia da Loja
                  </div>
                </div>
              </div>

              <div className="px-5 pb-5 pt-2 border-t border-slate-800/60 flex items-center justify-between">
                <div>
                  <span className="text-xs text-slate-400 block leading-none">Preço:</span>
                  <span className="text-xl font-black text-amber-400">R$ {Number(p.price).toFixed(2)}</span>
                </div>
                <span className="rounded-xl bg-amber-400/20 border border-amber-400/40 px-3 py-1 text-xs font-black text-amber-300 group-hover:bg-amber-400 group-hover:text-slate-950 transition-colors">
                  Ver Detalhes
                </span>
              </div>
            </Link>
          ))}
        </div>
      </section>

      {/* 8. Categorias */}
      <section className="mx-auto max-w-6xl px-4 sm:px-6 pb-12">
        <h2 className="mb-6 text-2xl font-black tracking-tight text-white">Navegar por Categorias</h2>
        <div className="grid gap-4 sm:grid-cols-2 md:grid-cols-4">
          {categoriesList.map((c: any) => (
            <Link
              key={c.id}
              href={`/produtos?categoria=${c.slug}`}
              className="rounded-2xl border border-slate-800 bg-slate-900/40 p-5 shadow-lg hover:bg-slate-800/60 hover:border-amber-400/30 transition-all"
            >
              <h3 className="text-base font-black text-slate-100">{c.name}</h3>
              <p className="mt-1 text-xs text-slate-400">{c.description || "Ver todos os itens disponíveis."}</p>
            </Link>
          ))}
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-slate-800 bg-slate-950 px-6 py-12 text-center text-sm text-slate-500">
        <p className="font-black text-amber-400 text-base">Sonic Vendas Premium</p>
        <p className="mt-2 text-xs text-slate-400">
          Loja oficial, Redes Sociais com Reposição, Divulgação de Contatos e Negócios, Sorteios e IPTV 12H.
        </p>
        <p className="mt-3 text-sm text-slate-300">
          Chave Pix Oficial & WhatsApp Suporte: <span className="font-black text-amber-400">75981558007</span>
        </p>
        <p className="mt-4 text-[11px] text-slate-600">© {new Date().getFullYear()} Sonic Vendas. Todos os direitos reservados.</p>
      </footer>
    </main>
  );
}
