"use client";
import React, { useState, useEffect } from "react";
import Link from "next/link";
import {
  User,
  ArrowLeft,
  Sparkles,
  Camera,
  Video,
  Phone,
  Mail,
  MapPin,
  Calendar,
  CheckCircle2,
  Copy,
  Check,
  ShieldCheck,
  FileCheck,
  UploadCloud,
} from "lucide-react";
import { playSound } from "@/lib/sounds";

export default function DivulgarContatosPage() {
  const [form, setForm] = useState({
    name: "",
    age: "",
    description: "",
    profilePhoto: "",
    videoUrl: "",
    phone: "",
    email: "",
    contactLink: "",
    city: "",
    days: 7,
  });

  const [receiptUrl, setReceiptUrl] = useState("");
  const [selectedFileName, setSelectedFileName] = useState("");
  const [loading, setLoading] = useState(false);
  const [createdAd, setCreatedAd] = useState<any | null>(null);
  const [copiedPix, setCopiedPix] = useState(false);

  const pixKey = "75981558007";
  const totalPrice = (form.days * 1.0).toFixed(2); // R$ 1,00 por dia

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);

    try {
      const res = await fetch("/api/contact-ads", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...form,
          receiptUrl: receiptUrl || null,
        }),
      });

      const data = await res.json();
      if (data.ok) {
        playSound("new_order");
        setCreatedAd(data.data);
      } else {
        alert(data.error || "Erro ao registrar divulgação.");
      }
    } catch {
      alert("Erro de conexão ao enviar.");
    } finally {
      setLoading(false);
    }
  }

  function handleCopyPix() {
    navigator.clipboard.writeText(pixKey);
    setCopiedPix(true);
    setTimeout(() => setCopiedPix(false), 2000);
  }

  return (
    <main className="min-h-screen bg-[#040817] text-slate-100 selection:bg-amber-400 selection:text-black px-4 py-8 md:px-6 md:py-12">
      <div className="mx-auto max-w-4xl">
        {/* Navigation Breadcrumb */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-6">
          <Link
            href="/contatos-anuncios"
            className="inline-flex items-center gap-2 text-sm font-bold text-amber-400 hover:text-amber-300 transition-colors"
          >
            <ArrowLeft size={18} /> Ver Todos os Contatos Anunciados
          </Link>

          <Link
            href="/divulgar-negocios"
            className="rounded-xl border border-cyan-400/30 bg-blue-950/40 px-3.5 py-1.5 text-xs font-black uppercase text-cyan-300 hover:bg-cyan-400 hover:text-slate-950 transition-all"
          >
            💼 É uma Loja ou Empresa? Clique Aqui
          </Link>
        </div>

        {/* Header */}
        <div className="mt-8 text-center md:mt-10">
          <div className="inline-flex items-center gap-2 rounded-full bg-amber-400/10 px-5 py-2 border border-amber-400/30 shadow-md mb-3">
            <User className="text-amber-400" size={18} />
            <span className="text-xs font-black uppercase tracking-wider text-amber-300">
              DIVULGAÇÃO DE CONTATOS • R$ 1,00 POR DIA
            </span>
          </div>

          <h1 className="text-3xl font-black tracking-tight text-white md:text-5xl">
            DIVULGUE SEU <span className="text-amber-400">PERFIL & CONTATO</span>
          </h1>

          <p className="mx-auto mt-2 max-w-2xl text-xs md:text-sm text-slate-300">
            Apresente seu perfil pessoal, redes sociais, trabalhos e WhatsApp para milhares de visitantes diários na Sonic Vendas.
          </p>
        </div>

        {!createdAd ? (
          <form onSubmit={handleSubmit} className="mt-8 rounded-3xl border border-slate-800 bg-slate-900/60 p-6 md:p-8 shadow-2xl backdrop-blur-xl space-y-5">
            <div className="border-b border-slate-800 pb-3">
              <h3 className="text-lg font-black text-white flex items-center gap-2">
                <Sparkles className="text-amber-400" size={18} />
                Informações da Sua Apresentação
              </h3>
            </div>

            <div className="grid gap-4 md:grid-cols-2">
              <div>
                <label className="mb-1 block text-xs font-bold text-slate-300">Seu Nome ou Apelido *</label>
                <input
                  type="text"
                  required
                  placeholder="Ex: Lucas Gabriel"
                  value={form.name}
                  onChange={(e) => setForm({ ...form, name: e.target.value })}
                  className="w-full rounded-2xl border border-slate-700 bg-slate-950 px-4 py-3 text-sm text-white focus:border-amber-400 focus:outline-none"
                />
              </div>

              <div>
                <label className="mb-1 block text-xs font-bold text-slate-300">Idade (Opcional)</label>
                <input
                  type="text"
                  placeholder="Ex: 24 anos"
                  value={form.age}
                  onChange={(e) => setForm({ ...form, age: e.target.value })}
                  className="w-full rounded-2xl border border-slate-700 bg-slate-950 px-4 py-3 text-sm text-white focus:border-amber-400 focus:outline-none"
                />
              </div>
            </div>

            <div className="grid gap-4 md:grid-cols-2">
              <div>
                <label className="mb-1 block text-xs font-bold text-slate-300">WhatsApp para Contato *</label>
                <input
                  type="text"
                  required
                  placeholder="(75) 98155-8007"
                  value={form.phone}
                  onChange={(e) => setForm({ ...form, phone: e.target.value })}
                  className="w-full rounded-2xl border border-slate-700 bg-slate-950 px-4 py-3 text-sm text-white focus:border-amber-400 focus:outline-none"
                />
              </div>

              <div>
                <label className="mb-1 block text-xs font-bold text-slate-300">Cidade / Região (Opcional)</label>
                <input
                  type="text"
                  placeholder="Ex: Feira de Santana - BA"
                  value={form.city}
                  onChange={(e) => setForm({ ...form, city: e.target.value })}
                  className="w-full rounded-2xl border border-slate-700 bg-slate-950 px-4 py-3 text-sm text-white focus:border-amber-400 focus:outline-none"
                />
              </div>
            </div>

            <div className="grid gap-4 md:grid-cols-2">
              <div>
                <label className="mb-1 block text-xs font-bold text-slate-300">Foto de Perfil (URL da Imagem)</label>
                <input
                  type="text"
                  placeholder="https://images.unsplash.com/..."
                  value={form.profilePhoto}
                  onChange={(e) => setForm({ ...form, profilePhoto: e.target.value })}
                  className="w-full rounded-2xl border border-slate-700 bg-slate-950 px-4 py-3 text-xs text-white focus:border-amber-400 focus:outline-none"
                />
              </div>

              <div>
                <label className="mb-1 block text-xs font-bold text-slate-300">Vídeo de Apresentação (Até 2 min)</label>
                <input
                  type="text"
                  placeholder="Link do vídeo (MP4 / WebM / YouTube)"
                  value={form.videoUrl}
                  onChange={(e) => setForm({ ...form, videoUrl: e.target.value })}
                  className="w-full rounded-2xl border border-slate-700 bg-slate-950 px-4 py-3 text-xs text-white focus:border-amber-400 focus:outline-none"
                />
              </div>
            </div>

            <div>
              <label className="mb-1 block text-xs font-bold text-slate-300">Descrição Pessoal / Apresentação *</label>
              <textarea
                required
                rows={3}
                placeholder="Conte sobre você, seus trabalhos, hobbies, projetos ou o que deseja divulgar..."
                value={form.description}
                onChange={(e) => setForm({ ...form, description: e.target.value })}
                className="w-full rounded-2xl border border-slate-700 bg-slate-950 px-4 py-3 text-sm text-white focus:border-amber-400 focus:outline-none"
              />
            </div>

            <div className="grid gap-4 md:grid-cols-2">
              <div>
                <label className="mb-1 block text-xs font-bold text-slate-300">Link Personalizado (Instagram, Portfólio, etc.)</label>
                <input
                  type="text"
                  placeholder="https://instagram.com/seu_usuario"
                  value={form.contactLink}
                  onChange={(e) => setForm({ ...form, contactLink: e.target.value })}
                  className="w-full rounded-2xl border border-slate-700 bg-slate-950 px-4 py-3 text-xs text-white focus:border-amber-400 focus:outline-none"
                />
              </div>

              <div>
                <label className="mb-1 block text-xs font-bold text-slate-300">Quantidade de Dias de Divulgação</label>
                <input
                  type="number"
                  min={1}
                  max={365}
                  value={form.days}
                  onChange={(e) => setForm({ ...form, days: Math.max(1, parseInt(e.target.value || "1", 10)) })}
                  className="w-full rounded-2xl border border-slate-700 bg-slate-950 px-4 py-3 text-sm text-white focus:border-amber-400 focus:outline-none"
                />
              </div>
            </div>

            {/* Total Price Display */}
            <div className="flex items-center justify-between rounded-2xl border-2 border-amber-400/40 bg-amber-950/40 p-4">
              <div>
                <span className="text-xs font-black uppercase text-amber-400 block">VALOR TOTAL:</span>
                <span className="text-xs text-slate-400">{form.days} dias x R$ 1,00/dia</span>
              </div>
              <span className="text-3xl font-black text-amber-400">R$ {totalPrice}</span>
            </div>

            {/* Comprovante Pix Upload with Glowing Highlight */}
            <div className="rounded-2xl border-2 border-amber-400/60 bg-slate-950 p-5 shadow-lg animate-pulse-gentle">
              <div className="flex items-center gap-2 mb-2">
                <UploadCloud className="text-amber-400 animate-bounce" size={20} />
                <span className="text-xs font-black uppercase tracking-wider text-amber-300">
                  ANEXAR COMPROVANTE PIX (CHAVE: 75981558007)
                </span>
              </div>
              <p className="text-xs text-slate-400 mb-3">
                Faça o Pix de <strong>R$ {totalPrice}</strong> para a chave <code>{pixKey}</code> e anexe a URL ou foto do comprovante abaixo para liberação pelo administrador:
              </p>
              <input
                type="text"
                placeholder="Cole o link ou foto do comprovante Pix..."
                value={receiptUrl}
                onChange={(e) => setReceiptUrl(e.target.value)}
                className="w-full rounded-xl border border-amber-400/40 bg-slate-900 px-4 py-2.5 text-xs text-white focus:border-amber-400 focus:outline-none"
              />
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full rounded-2xl bg-gradient-to-r from-amber-400 via-orange-400 to-amber-300 py-4 text-base font-black uppercase tracking-wider text-slate-950 shadow-xl shadow-amber-400/20 hover:brightness-110 transition-all disabled:opacity-60"
            >
              {loading ? "Registrando Divulgação..." : `Publicar Divulgação de Contato (R$ ${totalPrice})`}
            </button>
          </form>
        ) : (
          /* Confirmation card with Pix Key */
          <div className="mt-8 rounded-3xl border-2 border-emerald-400 bg-slate-950 p-8 text-center space-y-4">
            <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-emerald-400/20 text-3xl text-emerald-400">
              ✓
            </div>
            <h3 className="text-2xl font-black text-white">Divulgação de Contato Registrada!</h3>
            <p className="text-xs text-slate-300 max-w-md mx-auto">
              Seu perfil de contato <strong>{createdAd.name}</strong> foi cadastrado para {createdAd.days} dias (R$ {Number(createdAd.price).toFixed(2)}). O administrador já foi notificado para aprovação!
            </p>

            <div className="rounded-2xl border border-slate-800 bg-slate-900 p-4 max-w-md mx-auto text-left">
              <span className="text-xs font-bold text-slate-400 block mb-1">Chave Pix para Pagamento:</span>
              <div className="flex items-center justify-between">
                <code className="text-base font-mono font-black text-emerald-400">{pixKey}</code>
                <button
                  type="button"
                  onClick={handleCopyPix}
                  className="flex items-center gap-1 rounded-xl bg-emerald-400 px-3 py-1.5 text-xs font-black text-slate-950 hover:bg-emerald-300 transition-colors"
                >
                  {copiedPix ? <Check size={14} /> : <Copy size={14} />}
                  <span>{copiedPix ? "Copiado!" : "Copiar Pix"}</span>
                </button>
              </div>
            </div>

            <div className="flex justify-center gap-3 pt-4">
              <Link
                href="/contatos-anuncios"
                className="rounded-2xl bg-amber-400 px-6 py-3 text-xs font-black uppercase text-slate-950 hover:bg-amber-300"
              >
                Ver Lista de Contatos
              </Link>
              <button
                type="button"
                onClick={() => setCreatedAd(null)}
                className="rounded-2xl border border-slate-700 bg-slate-900 px-6 py-3 text-xs font-bold text-slate-300 hover:text-white"
              >
                Cadastrar Outro Contato
              </button>
            </div>
          </div>
        )}
      </div>
    </main>
  );
}
