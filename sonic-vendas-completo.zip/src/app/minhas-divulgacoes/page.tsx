"use client";
import React, { useState } from "react";
import Link from "next/link";
import {
  BarChart3,
  ArrowLeft,
  Search,
  Eye,
  MessageCircle,
  ExternalLink,
  ShoppingBag,
  Zap,
  Clock,
  Sparkles,
  CheckCircle2,
  AlertTriangle,
  User,
  Store,
} from "lucide-react";

export default function MinhasDivulgacoesPage() {
  const [query, setQuery] = useState("");
  const [loading, setLoading] = useState(false);
  const [contactAds, setContactAds] = useState<any[]>([]);
  const [businessAds, setBusinessAds] = useState<any[]>([]);
  const [searched, setSearched] = useState(false);

  async function handleSearch(e: React.FormEvent) {
    e.preventDefault();
    if (!query) return;
    setLoading(true);
    setSearched(true);

    try {
      const [cRes, bRes] = await Promise.all([
        fetch("/api/contact-ads").then((r) => r.json()),
        fetch("/api/business-ads").then((r) => r.json()),
      ]);

      const q = query.trim().toLowerCase();
      const phoneClean = query.replace(/\D/g, "");

      if (cRes.ok && cRes.data) {
        const filtered = cRes.data.filter((a: any) => {
          return (
            a.email?.toLowerCase().includes(q) ||
            a.phone?.replace(/\D/g, "").includes(phoneClean) ||
            a.name?.toLowerCase().includes(q)
          );
        });
        setContactAds(filtered);
      }

      if (bRes.ok && bRes.data) {
        const filtered = bRes.data.filter((a: any) => {
          return (
            a.email?.toLowerCase().includes(q) ||
            a.phone?.replace(/\D/g, "").includes(phoneClean) ||
            a.businessName?.toLowerCase().includes(q)
          );
        });
        setBusinessAds(filtered);
      }
    } catch {
      alert("Erro ao buscar suas divulgações.");
    } finally {
      setLoading(false);
    }
  }

  const totalViews =
    contactAds.reduce((acc, a) => acc + (a.viewsCount || 0), 0) +
    businessAds.reduce((acc, a) => acc + (a.viewsCount || 0), 0);

  const totalWhatsapp =
    contactAds.reduce((acc, a) => acc + (a.clicksWhatsapp || 0), 0) +
    businessAds.reduce((acc, a) => acc + (a.clicksWhatsapp || 0), 0);

  const totalLinks =
    contactAds.reduce((acc, a) => acc + (a.clicksLink || 0), 0) +
    businessAds.reduce((acc, a) => acc + (a.clicksLink || 0), 0);

  return (
    <main className="min-h-screen bg-[#040817] text-slate-100 selection:bg-amber-400 selection:text-black px-4 py-8 md:px-6 md:py-12">
      <div className="mx-auto max-w-5xl">
        {/* Navigation Breadcrumb */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-6">
          <Link
            href="/"
            className="inline-flex items-center gap-2 text-sm font-bold text-amber-400 hover:text-amber-300 transition-colors"
          >
            <ArrowLeft size={18} /> Voltar à Loja
          </Link>

          <div className="flex gap-2">
            <Link
              href="/divulgar-contatos"
              className="rounded-xl border border-amber-400/30 bg-amber-950/40 px-3.5 py-1.5 text-xs font-bold text-amber-300 hover:bg-amber-400 hover:text-slate-950 transition-all"
            >
              + Novo Contato
            </Link>
            <Link
              href="/divulgar-negocios"
              className="rounded-xl border border-cyan-400/30 bg-blue-950/40 px-3.5 py-1.5 text-xs font-bold text-cyan-300 hover:bg-cyan-400 hover:text-slate-950 transition-all"
            >
              + Novo Negócio
            </Link>
          </div>
        </div>

        {/* Header */}
        <div className="mt-8 text-center">
          <div className="inline-flex items-center gap-2 rounded-full bg-amber-400/10 px-5 py-2 border border-amber-400/30 shadow-md mb-3">
            <BarChart3 className="text-amber-400" size={18} />
            <span className="text-xs font-black uppercase tracking-wider text-amber-300">
              PAINEL DO ANUNCIANTE • MÉTRICAS E DESEMPENHO EM TEMPO REAL
            </span>
          </div>

          <h1 className="text-3xl font-black tracking-tight text-white md:text-5xl">
            MINHAS <span className="text-amber-400">DIVULGAÇÕES</span>
          </h1>

          <p className="mx-auto mt-2 max-w-xl text-xs md:text-sm text-slate-300">
            Acompanhe visualizações reais, cliques no WhatsApp, cliques nos links e dias restantes dos seus anúncios.
          </p>
        </div>

        {/* Search Box */}
        <div className="mt-8 rounded-3xl border border-slate-800 bg-slate-900/60 p-6 md:p-8 shadow-xl">
          <form onSubmit={handleSearch} className="flex flex-col md:flex-row items-center gap-3">
            <input
              type="text"
              required
              placeholder="Digite seu WhatsApp ou E-mail cadastrado..."
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              className="w-full rounded-2xl border border-slate-700 bg-slate-950 px-5 py-3.5 text-sm text-white placeholder-slate-500 focus:border-amber-400 focus:outline-none"
            />
            <button
              type="submit"
              disabled={loading}
              className="flex w-full md:w-auto shrink-0 items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-amber-400 to-orange-400 px-8 py-3.5 text-sm font-black uppercase text-slate-950 hover:brightness-110 shadow-lg shadow-amber-400/20 disabled:opacity-60"
            >
              <Search size={16} /> {loading ? "Buscando..." : "Consultar Métricas"}
            </button>
          </form>
        </div>

        {/* Metrics Summary Cards */}
        {searched && (
          <div className="mt-8 space-y-8">
            <div className="grid gap-4 sm:grid-cols-3">
              <div className="rounded-2xl border border-amber-400/30 bg-amber-950/30 p-5 text-center">
                <Eye className="mx-auto mb-2 text-amber-400" size={24} />
                <span className="text-3xl font-black text-white">{totalViews}</span>
                <span className="text-xs text-slate-400 block mt-1 uppercase font-bold">Total de Visualizações</span>
              </div>

              <div className="rounded-2xl border border-emerald-500/30 bg-emerald-950/30 p-5 text-center">
                <MessageCircle className="mx-auto mb-2 text-emerald-400" size={24} />
                <span className="text-3xl font-black text-white">{totalWhatsapp}</span>
                <span className="text-xs text-slate-400 block mt-1 uppercase font-bold">Cliques no WhatsApp</span>
              </div>

              <div className="rounded-2xl border border-cyan-500/30 bg-blue-950/30 p-5 text-center">
                <ExternalLink className="mx-auto mb-2 text-cyan-400" size={24} />
                <span className="text-3xl font-black text-white">{totalLinks}</span>
                <span className="text-xs text-slate-400 block mt-1 uppercase font-bold">Acessos a Links / Perfil</span>
              </div>
            </div>

            {/* Contact Ads List */}
            {contactAds.length > 0 && (
              <div className="rounded-3xl border border-slate-800 bg-slate-900/60 p-6 shadow-xl space-y-4">
                <h3 className="text-lg font-black text-amber-400 flex items-center gap-2">
                  <User size={18} /> Minhas Divulgações de Contatos ({contactAds.length})
                </h3>

                <div className="space-y-3">
                  {contactAds.map((ad) => (
                    <div
                      key={ad.id}
                      className="rounded-2xl border border-slate-800 bg-slate-950 p-4 flex flex-col md:flex-row md:items-center justify-between gap-4"
                    >
                      <div className="flex items-center gap-3">
                        <img
                          src={ad.profilePhoto}
                          alt={ad.name}
                          className="h-14 w-14 rounded-xl object-cover bg-slate-900 shrink-0"
                        />
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-black text-white">{ad.name}</span>
                            <span className="rounded-full bg-slate-900 border border-slate-800 px-2 py-0.5 text-[10px] text-amber-300 font-bold uppercase">
                              {ad.days} dias contratados
                            </span>
                          </div>
                          <p className="text-xs text-slate-400 mt-0.5">{ad.description.slice(0, 70)}...</p>
                        </div>
                      </div>

                      <div className="flex flex-wrap items-center gap-4 text-xs font-bold text-slate-300">
                        <span>👁️ {ad.viewsCount || 0} views</span>
                        <span className="text-emerald-400">💬 {ad.clicksWhatsapp || 0} WhatsApp</span>
                        <Link
                          href="/contatos-anuncios"
                          className="rounded-xl bg-amber-400/20 border border-amber-400/40 px-3 py-1.5 text-xs text-amber-300 hover:bg-amber-400 hover:text-slate-950"
                        >
                          Ver no Site
                        </Link>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Business Ads List */}
            {businessAds.length > 0 && (
              <div className="rounded-3xl border border-slate-800 bg-slate-900/60 p-6 shadow-xl space-y-4">
                <h3 className="text-lg font-black text-cyan-400 flex items-center gap-2">
                  <Store size={18} /> Minhas Divulgações de Negócios ({businessAds.length})
                </h3>

                <div className="space-y-3">
                  {businessAds.map((ad) => (
                    <div
                      key={ad.id}
                      className="rounded-2xl border border-slate-800 bg-slate-950 p-4 flex flex-col md:flex-row md:items-center justify-between gap-4"
                    >
                      <div className="flex items-center gap-3">
                        <img
                          src={ad.photoUrl}
                          alt={ad.businessName}
                          className="h-14 w-14 rounded-xl object-cover bg-slate-900 shrink-0"
                        />
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-black text-white">{ad.businessName}</span>
                            <span className="rounded-full bg-slate-900 border border-slate-800 px-2 py-0.5 text-[10px] text-cyan-300 font-bold uppercase">
                              {ad.category}
                            </span>
                          </div>
                          <p className="text-xs text-slate-400 mt-0.5">{ad.adTitle}</p>
                        </div>
                      </div>

                      <div className="flex flex-wrap items-center gap-4 text-xs font-bold text-slate-300">
                        <span>👁️ {ad.viewsCount || 0} views</span>
                        <span className="text-emerald-400">💬 {ad.clicksWhatsapp || 0} WhatsApp</span>
                        {ad.clicksBuy > 0 && (
                          <span className="text-amber-400">🛒 {ad.clicksBuy} compras</span>
                        )}
                        <Link
                          href="/negocios-anuncios"
                          className="rounded-xl bg-cyan-400/20 border border-cyan-400/40 px-3 py-1.5 text-xs text-cyan-300 hover:bg-cyan-400 hover:text-slate-950"
                        >
                          Ver no Site
                        </Link>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {contactAds.length === 0 && businessAds.length === 0 && (
              <div className="p-8 text-center text-slate-500 rounded-3xl border border-slate-800 bg-slate-900/40">
                Nenhum anúncio encontrado para este WhatsApp ou e-mail.
              </div>
            )}
          </div>
        )}
      </div>
    </main>
  );
}
