import { db } from "@/db";
import { publications } from "@/db/schema";
import { desc, eq, and } from "drizzle-orm";
import Link from "next/link";
import { ArrowLeft, Video, Image as ImageIcon } from "lucide-react";

export const dynamic = "force-dynamic";
export const revalidate = 5;

export default async function TopoPage() {
  const now = new Date();
  const activePubs = await db.select().from(publications).where(and(eq(publications.status, "approved"), eq(publications.isActive, true))).orderBy(desc(publications.startDate)).limit(6);

  return (
    <main className="min-h-screen bg-gradient-to-b from-amber-950 via-amber-900/20 to-slate-950 px-6 py-12">
      <div className="mx-auto max-w-6xl">
        <Link href="/" className="inline-flex items-center gap-2 text-sm font-bold text-amber-400 hover:text-amber-300 transition-colors mb-8"><ArrowLeft size={18} /> Voltar</Link>
        <h1 className="text-5xl font-extrabold tracking-tight text-white">Topo — Divulgação em Destaque</h1>
        <p className="mt-2 text-sm text-amber-300">As divulgações ativas aparecem aqui com destaque premium.</p>

        <div className="mt-8 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {activePubs.map((p: any) => (
            <a key={p.id} href={p.linkUrl || "#"} className="group relative overflow-hidden rounded-3xl border border-amber-400/20 bg-gradient-to-br from-amber-950/40 to-slate-900/60 p-6 shadow-2xl shadow-amber-400/10 hover:shadow-amber-400/30 transition-all">
              {p.videoUrl ? (
                <div className="h-48 w-full rounded-2xl bg-slate-950 flex items-center justify-center mb-4">
                  <Video size={48} className="text-amber-400" />
                  <span className="absolute bottom-4 right-4 rounded-full bg-red-500 px-3 py-1 text-[10px] font-extrabold text-white shadow-lg">VÍDEO</span>
                </div>
              ) : (
                <img src={p.imageUrl || "https://placehold.co/600x300?text=Divulgação"} alt={p.name} className="mb-4 h-48 w-full rounded-2xl object-cover bg-slate-950" />
              )}
              <h3 className="text-xl font-extrabold text-amber-400">{p.name}</h3>
              <p className="mt-2 text-sm text-slate-300">{p.description}</p>
              <div className="mt-4 flex items-center justify-between">
                <span className="text-xs font-bold text-slate-500">{p.days} dias</span>
                <span className="text-lg font-extrabold text-white">R$ {Number(p.price).toFixed(2)}</span>
              </div>
            </a>
          ))}
        </div>
        {activePubs.length === 0 && (
          <div className="rounded-3xl border border-amber-400/20 bg-amber-950/20 p-12 text-center text-amber-300 shadow-xl">
            Nenhuma divulgação ativa no momento. Crie uma divulgação para aparecer aqui.
          </div>
        )}
      </div>
    </main>
  );
}
