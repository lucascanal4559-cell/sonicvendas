"use client";
import React, { useState, useEffect } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  Menu,
  X,
  Home,
  ShoppingBag,
  Smartphone,
  User,
  Store,
  Trophy,
  Gift,
  Tv,
  Users,
  BarChart3,
  Bell,
  MessageCircle,
  ShieldCheck,
  Settings,
  CreditCard,
  ChevronRight,
  ExternalLink,
  Sparkles,
  Download,
} from "lucide-react";

export default function InstagramDrawerMenu() {
  const [isOpen, setIsOpen] = useState(false);
  const pathname = usePathname();

  // Close drawer on route change
  useEffect(() => {
    setIsOpen(false);
  }, [pathname]);

  // Lock background scroll when drawer is open
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "unset";
    }
  }, [isOpen]);

  const menuSections = [
    {
      category: "PRINCIPAL",
      items: [
        { label: "Início", href: "/", icon: Home, badge: null },
        { label: "Loja & Produtos", href: "/produtos", icon: ShoppingBag, badge: null },
        { label: "📱 Redes Sociais & Seguidores", href: "/servicos-sociais", icon: Smartphone, badge: "IA POPULAR", color: "text-pink-400" },
      ],
    },
    {
      category: "PUBLICIDADE & DIVULGAÇÃO",
      items: [
        { label: "Divulgação de Contatos", href: "/contatos-anuncios", icon: User, badge: "R$ 1/dia", color: "text-amber-400" },
        { label: "Divulgação de Negócios & Lojas", href: "/negocios-anuncios", icon: Store, badge: "ORÇAMENTO IA", color: "text-cyan-400" },
        { label: "Minhas Divulgações (Métricas)", href: "/minhas-divulgacoes", icon: BarChart3, badge: "ESTATÍSTICAS" },
      ],
    },
    {
      category: "ENTRETENIMENTO & PRÊMIOS",
      items: [
        { label: "🎯 Sorteios & Cotas", href: "/sorteios", icon: Trophy, badge: "R$ 0,01", color: "text-amber-400" },
        { label: "🎡 Roleta da Sorte", href: "/roleta", icon: Gift, badge: "GIRE & GANHE", color: "text-pink-400" },
        { label: "📺 IPTV 12 Horas", href: "/iptv", icon: Tv, badge: "TESTE GRÁTIS", color: "text-cyan-400" },
        { label: "Grupos (WhatsApp, Telegram, Discord)", href: "/grupos", icon: Users, badge: "R$ 10/mês" },
      ],
    },
    {
      category: "CLIENTE & ATENDIMENTO",
      items: [
        { label: "Meu Perfil", href: "/perfil", icon: User, badge: null },
        { label: "Notificações", href: "/notificacoes", icon: Bell, badge: "3" },
        { label: "Atendimento & Chat", href: "/contato", icon: MessageCircle, badge: null },
        { label: "Finalizar Compra / Pix", href: "/checkout", icon: CreditCard, badge: null },
        { label: "📦 Baixar Projeto em ZIP", href: "/baixar-projeto", icon: Sparkles, badge: "DOWNLOAD", color: "text-amber-400" },
        { label: "Painel do Administrador", href: "/admin", icon: Settings, badge: "ADM", color: "text-red-400" },
      ],
    },
  ];

  return (
    <>
      {/* Hamburger / Instagram Menu Trigger Button */}
      <button
        type="button"
        onClick={() => setIsOpen(true)}
        aria-label="Abrir Menu Principal"
        className="flex items-center justify-center rounded-xl p-2 text-slate-200 hover:bg-slate-800 hover:text-amber-400 transition-colors"
      >
        <Menu size={24} />
      </button>

      {/* Backdrop */}
      {isOpen && (
        <div
          onClick={() => setIsOpen(false)}
          className="fixed inset-0 z-[80] bg-black/70 backdrop-blur-sm transition-opacity"
        />
      )}

      {/* Slide-out Drawer */}
      <div
        className={`fixed top-0 left-0 bottom-0 z-[90] w-[85vw] max-w-[340px] bg-[#020617] border-r border-slate-800 flex flex-col justify-between shadow-2xl transition-transform duration-300 ease-out ${
          isOpen ? "translate-x-0" : "-translate-x-full"
        }`}
      >
        {/* Drawer Header (Instagram style) */}
        <div className="flex items-center justify-between border-b border-slate-800/80 px-6 py-4">
          <Link href="/" className="flex items-center gap-2.5">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-tr from-amber-500 to-amber-300 text-slate-950 font-black text-lg shadow-md shadow-amber-400/20">
              S
            </div>
            <div>
              <span className="text-base font-black italic tracking-wider text-white block leading-none">
                SONIC VENDAS
              </span>
              <span className="text-[10px] font-bold text-amber-400 uppercase tracking-widest">
                PREMIUM
              </span>
            </div>
          </Link>

          <button
            type="button"
            onClick={() => setIsOpen(false)}
            className="rounded-full p-1.5 text-slate-400 hover:bg-slate-800 hover:text-white"
          >
            <X size={20} />
          </button>
        </div>

        {/* Scrollable Navigation List */}
        <div className="flex-1 overflow-y-auto px-4 py-4 space-y-6">
          {menuSections.map((sec, secIdx) => (
            <div key={secIdx} className="space-y-1">
              <span className="px-3 text-[10px] font-black uppercase tracking-widest text-slate-400 block mb-2">
                {sec.category}
              </span>

              {sec.items.map((item, itemIdx) => {
                const isActive = pathname === item.href;
                return (
                  <Link
                    key={itemIdx}
                    href={item.href}
                    className={`group flex items-center justify-between rounded-2xl px-3 py-2.5 text-xs font-bold transition-all ${
                      isActive
                        ? "bg-amber-400/15 border border-amber-400/40 text-amber-300"
                        : "text-slate-300 hover:bg-slate-900 hover:text-white"
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <item.icon
                        size={17}
                        className={item.color || (isActive ? "text-amber-400" : "text-slate-400 group-hover:text-amber-400")}
                      />
                      <span>{item.label}</span>
                    </div>

                    <div className="flex items-center gap-1.5">
                      {item.badge && (
                        <span className="rounded-full bg-slate-950 px-2 py-0.5 text-[9px] font-black uppercase text-amber-400 border border-slate-800">
                          {item.badge}
                        </span>
                      )}
                      <ChevronRight size={13} className="text-slate-600 group-hover:text-slate-300" />
                    </div>
                  </Link>
                );
              })}
            </div>
          ))}
        </div>

        {/* Drawer Footer with Quick WhatsApp Contact */}
        <div className="border-t border-slate-800/80 p-4 bg-slate-950/80">
          <a
            href="https://wa.me/5575981558007?text=Olá%20Sonic%20Vendas,%20preciso%20de%20suporte!"
            target="_blank"
            rel="noreferrer"
            className="flex items-center justify-center gap-2 rounded-2xl bg-emerald-500 py-3 text-xs font-black uppercase text-slate-950 hover:bg-emerald-400 transition-all shadow-md shadow-emerald-500/20"
          >
            <MessageCircle size={16} /> Suporte no WhatsApp
          </a>
        </div>
      </div>
    </>
  );
}
