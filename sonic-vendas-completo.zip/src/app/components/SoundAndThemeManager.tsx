"use client";
import React, { useState, useEffect } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  Volume2,
  VolumeX,
  X,
  Bell,
  Sparkles,
  Flame,
  Trophy,
  Tv,
  ArrowRight,
  ShieldAlert,
  Wrench,
  Clock,
} from "lucide-react";
import { playSound, SOUND_DEFINITIONS, SoundEventType } from "@/lib/sounds";

export default function SoundAndThemeManager() {
  const pathname = usePathname();

  // Theme & config state
  const [theme, setTheme] = useState<Record<string, string>>({
    primaryColor: "#f59e0b",
    secondaryColor: "#06b6d4",
    backgroundColor: "#020617",
    textColor: "#f8fafc",
    soundEnabled: "true",
    soundVolume: "80",
    maintenanceMode: "false",
    maintenanceMessage: "Sonic Vendas está em atualização programada.",
    maintenanceEstimate: "Previsão de retorno em instantes.",
  });

  // Sound settings
  const [soundActive, setSoundActive] = useState(true);
  const [volume, setVolume] = useState(80);
  const [soundModalOpen, setSoundModalOpen] = useState(false);
  const [hasInteracted, setHasInteracted] = useState(false);

  // Announcements state
  const [announcements, setAnnouncements] = useState<any[]>([]);
  const [dismissedAnnouncements, setDismissedAnnouncements] = useState<number[]>([]);
  const [activePopup, setActivePopup] = useState<any | null>(null);

  // Load theme and announcements on mount
  useEffect(() => {
    // Check local storage for sound preferences
    const savedSound = localStorage.getItem("sonic_sound_enabled");
    if (savedSound !== null) setSoundActive(savedSound === "true");

    const savedVol = localStorage.getItem("sonic_sound_volume");
    if (savedVol) setVolume(parseInt(savedVol, 10));

    // Fetch theme from backend
    fetch("/api/theme")
      .then((r) => r.json())
      .then((res) => {
        if (res.ok && res.data) {
          setTheme(res.data);
          if (res.data.soundVolume) setVolume(parseInt(res.data.soundVolume, 10));

          // Dynamically load Google Fonts if specified
          const fontsToLoad = [
            res.data.fontTitle || "Poppins",
            res.data.fontBody || "Inter",
            res.data.fontPrice || "Montserrat",
            res.data.fontButton || "Poppins",
          ].filter(Boolean);

          const uniqueFonts = Array.from(new Set(fontsToLoad)).map((f) => f.replace(/\s+/g, "+"));
          if (uniqueFonts.length > 0 && typeof document !== "undefined") {
            const fontUrl = `https://fonts.googleapis.com/css2?family=${uniqueFonts.map((f) => `${f}:wght@300;400;600;700;800;900`).join("&family=")}&display=swap`;
            let linkEl = document.getElementById("google-fonts-sonic") as HTMLLinkElement;
            if (!linkEl) {
              linkEl = document.createElement("link");
              linkEl.id = "google-fonts-sonic";
              linkEl.rel = "stylesheet";
              document.head.appendChild(linkEl);
            }
            linkEl.href = fontUrl;
          }
        }
      })
      .catch(() => {});

    // Fetch announcements
    fetch("/api/announcements")
      .then((r) => r.json())
      .then((res) => {
        if (res.ok && res.data) {
          setAnnouncements(res.data);
          const popup = res.data.find((a: any) => a.location === "popup_modal" && a.isActive);
          if (popup) {
            const hasSeen = sessionStorage.getItem(`sonic_popup_${popup.id}`);
            if (!hasSeen) {
              setActivePopup(popup);
            }
          }
        }
      })
      .catch(() => {});
  }, []);

  // Listen for user interaction to unlock audio
  useEffect(() => {
    const handleFirstInteraction = () => {
      setHasInteracted(true);
      window.removeEventListener("click", handleFirstInteraction);
      window.removeEventListener("keydown", handleFirstInteraction);
    };
    window.addEventListener("click", handleFirstInteraction);
    window.addEventListener("keydown", handleFirstInteraction);
    return () => {
      window.removeEventListener("click", handleFirstInteraction);
      window.removeEventListener("keydown", handleFirstInteraction);
    };
  }, []);

  function toggleSound() {
    const next = !soundActive;
    setSoundActive(next);
    localStorage.setItem("sonic_sound_enabled", String(next));
    if (next) {
      playSound("payment_confirmed", volume);
    }
  }

  function handleTestSound(type: SoundEventType) {
    playSound(type, volume);
  }

  function dismissPopup(id: number) {
    sessionStorage.setItem(`sonic_popup_${id}`, "true");
    setActivePopup(null);
  }

  function dismissTopBar(id: number) {
    setDismissedAnnouncements((prev) => [...prev, id]);
  }

  // Maintenance mode check: Allow if admin route or login
  const isMaintenance = theme.maintenanceMode === "true";
  const isAdminRoute = pathname?.startsWith("/admin");

  if (isMaintenance && !isAdminRoute) {
    return (
      <div className="fixed inset-0 z-[100] flex min-h-screen items-center justify-center bg-[#020617] px-6 text-center text-slate-100">
        <div className="relative max-w-xl rounded-3xl border-2 border-amber-400/40 bg-slate-950 p-8 shadow-[0_0_80px_rgba(245,158,11,0.2)] backdrop-blur-2xl">
          <div className="mx-auto flex h-20 w-20 items-center justify-center rounded-3xl bg-amber-400/10 border border-amber-400/30 text-amber-400 text-4xl shadow-xl">
            <Wrench size={40} className="animate-spin-slow" />
          </div>

          <div className="mt-6 inline-flex items-center gap-2 rounded-full bg-amber-400/10 px-4 py-1 text-xs font-black uppercase text-amber-300">
            <Clock size={14} /> Manutenção Programada
          </div>

          <h1 className="mt-4 text-3xl font-black text-white md:text-4xl">
            {theme.maintenanceMessage || "Sonic Vendas em Manutenção"}
          </h1>

          <p className="mt-3 text-sm text-slate-300">
            Estamos aplicando atualizações importantes em nosso sistema, servidores e pagamentos para oferecer uma experiência ainda mais rápida e segura.
          </p>

          <div className="mt-6 rounded-2xl border border-slate-800 bg-slate-900/60 p-4">
            <span className="text-xs font-bold text-amber-400 uppercase">Previsão:</span>
            <p className="mt-0.5 text-base font-extrabold text-white">
              {theme.maintenanceEstimate || "Retornamos em instantes!"}
            </p>
          </div>

          <div className="mt-8 flex justify-center gap-3">
            <a
              href="https://wa.me/5575981558007?text=Olá,%20gostaria%20de%20informações%20sobre%20a%20manutenção%20do%20site"
              target="_blank"
              rel="noreferrer"
              className="rounded-2xl bg-amber-400 px-6 py-3 text-xs font-black uppercase text-slate-950 hover:bg-amber-300 transition-all shadow-lg shadow-amber-400/20"
            >
              Falar com Suporte no WhatsApp
            </a>
            <Link
              href="/admin/login"
              className="rounded-2xl border border-slate-700 bg-slate-900 px-4 py-3 text-xs font-bold text-slate-400 hover:text-white"
            >
              Acesso ADM
            </Link>
          </div>
        </div>
      </div>
    );
  }

  // Top Bar Announcement (if active and not dismissed)
  const topBarNotice = announcements.find(
    (a) => a.location === "top_bar" && a.isActive && !dismissedAnnouncements.includes(a.id)
  );

  return (
    <>
      {/* Dynamic Background Image / Video if configured in theme */}
      {theme.backgroundImageUrl && (
        <div
          className="fixed inset-0 pointer-events-none z-[-1]"
          style={{
            backgroundImage: `url(${theme.backgroundImageUrl})`,
            backgroundSize: "cover",
            backgroundPosition: "center",
            opacity: 1 - parseFloat(theme.backgroundOverlayOpacity || "0.85"),
          }}
        />
      )}

      {/* Top Bar Announcement */}
      {topBarNotice && (
        <div
          className="relative z-[60] flex items-center justify-between px-4 py-2 text-xs font-extrabold shadow-lg transition-all"
          style={{
            backgroundColor: topBarNotice.color || "#f59e0b",
            color: "#020617",
          }}
        >
          <div className="mx-auto flex flex-wrap items-center justify-center gap-2 text-center">
            <span>{topBarNotice.title}:</span>
            <span className="font-semibold">{topBarNotice.message}</span>
            {topBarNotice.buttonText && topBarNotice.buttonUrl && (
              <a
                href={topBarNotice.buttonUrl}
                className="ml-2 rounded-full bg-slate-950 px-3 py-0.5 text-[10px] font-black uppercase text-white hover:bg-slate-800 transition-colors"
              >
                {topBarNotice.buttonText} →
              </a>
            )}
          </div>

          {topBarNotice.isClosable && (
            <button
              onClick={() => dismissTopBar(topBarNotice.id)}
              className="rounded-full p-1 hover:bg-black/10 text-slate-950"
            >
              <X size={14} />
            </button>
          )}
        </div>
      )}

      {/* Floating Sound Control Button (Bottom Right) */}
      <div className="fixed bottom-6 right-6 z-40 flex items-center gap-2">
        <button
          type="button"
          onClick={() => setSoundModalOpen(true)}
          className="group flex items-center gap-2 rounded-full border border-amber-400/40 bg-slate-950/90 px-4 py-2.5 text-xs font-black uppercase tracking-wider text-amber-400 shadow-xl shadow-amber-400/20 backdrop-blur-md hover:scale-105 hover:bg-amber-400 hover:text-slate-950 transition-all"
        >
          {soundActive ? <Volume2 size={16} className="animate-pulse" /> : <VolumeX size={16} />}
          <span className="hidden sm:inline">{soundActive ? "Sons Ativados" : "Som Mudo"}</span>
        </button>
      </div>

      {/* Sound Settings & Test Modal */}
      {soundModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 backdrop-blur-md">
          <div className="relative w-full max-w-md rounded-3xl border-2 border-amber-400/50 bg-slate-950 p-6 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-4">
              <div className="flex items-center gap-2">
                <Volume2 className="text-amber-400" size={22} />
                <h3 className="text-lg font-black text-white">Central de Sons & Áudio</h3>
              </div>
              <button
                onClick={() => setSoundModalOpen(false)}
                className="rounded-full bg-slate-800 p-2 text-slate-400 hover:bg-slate-700 hover:text-white"
              >
                ✕
              </button>
            </div>

            <div className="mt-4 space-y-4">
              {/* Toggle switch */}
              <div className="flex items-center justify-between rounded-2xl border border-slate-800 bg-slate-900 p-4">
                <div>
                  <span className="text-sm font-black text-white block">Notificações Sonoras</span>
                  <span className="text-xs text-slate-400">Tocar áudio em novos pedidos, pagamentos e chat</span>
                </div>
                <button
                  type="button"
                  onClick={toggleSound}
                  className={`relative inline-flex h-7 w-12 items-center rounded-full transition-colors ${
                    soundActive ? "bg-amber-400" : "bg-slate-700"
                  }`}
                >
                  <span
                    className={`inline-block h-5 w-5 transform rounded-full bg-slate-950 transition-transform ${
                      soundActive ? "translate-x-6" : "translate-x-1"
                    }`}
                  />
                </button>
              </div>

              {/* Volume slider */}
              <div>
                <div className="flex justify-between text-xs font-bold text-slate-300 mb-1">
                  <span>Volume dos Sons</span>
                  <span className="text-amber-400">{volume}%</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="100"
                  value={volume}
                  onChange={(e) => {
                    const v = parseInt(e.target.value, 10);
                    setVolume(v);
                    localStorage.setItem("sonic_sound_volume", String(v));
                  }}
                  className="w-full accent-amber-400"
                />
              </div>

              {/* Test Sound Buttons */}
              <div>
                <span className="text-xs font-black uppercase text-amber-400 block mb-2">
                  Testar Sons dos Acontecimentos:
                </span>
                <div className="grid grid-cols-2 gap-2">
                  {SOUND_DEFINITIONS.map((s) => (
                    <button
                      key={s.type}
                      type="button"
                      onClick={() => handleTestSound(s.type)}
                      className="rounded-xl border border-slate-800 bg-slate-900/80 p-2.5 text-left text-xs hover:border-amber-400 hover:bg-slate-800 transition-all"
                    >
                      <span className="font-bold text-white block truncate">🔊 {s.name.split("(")[0]}</span>
                      <span className="text-[10px] text-slate-400 block truncate">{s.type}</span>
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <div className="mt-6 border-t border-slate-800 pt-4">
              <button
                type="button"
                onClick={() => setSoundModalOpen(false)}
                className="w-full rounded-2xl bg-amber-400 py-3 text-xs font-black uppercase text-slate-950 hover:bg-amber-300"
              >
                Salvar & Fechar
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Popup Modal Announcement */}
      {activePopup && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 backdrop-blur-md animate-fadeIn">
          <div className="relative w-full max-w-md rounded-3xl border-2 border-cyan-400/50 bg-slate-950 p-6 md:p-8 shadow-2xl">
            <button
              onClick={() => dismissPopup(activePopup.id)}
              className="absolute top-5 right-5 rounded-full bg-slate-800 p-2 text-slate-400 hover:bg-slate-700 hover:text-white"
            >
              ✕
            </button>

            <div className="text-center">
              <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-2xl bg-cyan-400/20 text-3xl text-cyan-400 shadow-lg">
                <Sparkles size={32} />
              </div>

              <span className="mt-4 inline-block text-xs font-black uppercase tracking-widest text-cyan-400">
                COMUNICADO ESPECIAL
              </span>

              <h3 className="mt-1 text-2xl font-black text-white">{activePopup.title}</h3>
              <p className="mt-2 text-sm text-slate-300">{activePopup.message}</p>

              {activePopup.buttonText && activePopup.buttonUrl && (
                <a
                  href={activePopup.buttonUrl}
                  onClick={() => dismissPopup(activePopup.id)}
                  className="mt-6 inline-flex w-full items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-cyan-400 to-blue-500 py-3.5 text-sm font-black uppercase text-slate-950 shadow-xl shadow-cyan-400/30 hover:scale-[1.02] transition-all"
                >
                  {activePopup.buttonText} <ArrowRight size={16} />
                </a>
              )}
            </div>
          </div>
        </div>
      )}
    </>
  );
}
