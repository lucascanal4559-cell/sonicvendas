"use client";
import Link from "next/link";
import { Bell } from "lucide-react";

export default function NotificationBell() {
  return (
    <Link href="/notificacoes" className="relative inline-flex items-center gap-1 rounded-full bg-amber-400/10 px-3 py-1.5 text-sm font-extrabold text-amber-400 hover:bg-amber-400/20 transition-all shadow-lg shadow-amber-400/10">
      <Bell size={16} />
      <span>Notificações</span>
      <span className="absolute -top-1 -right-1 h-4 w-4 rounded-full bg-red-500 text-[10px] font-black text-white flex items-center justify-center shadow-md">3</span>
    </Link>
  );
}
