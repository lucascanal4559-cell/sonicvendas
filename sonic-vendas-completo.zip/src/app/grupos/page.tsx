"use client";
import React, { useState, useEffect } from "react";
import Link from "next/link";
import {
  ArrowLeft,
  Users,
  CreditCard,
  PlusCircle,
  ExternalLink,
  Sparkles,
} from "lucide-react";

export default function GruposPage() {
  const [groupsList, setGroupsList] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedPlatform, setSelectedPlatform] = useState("all");
  const [selectedCategory, setSelectedCategory] = useState("all");

  async function loadGroups(platform = selectedPlatform, category = selectedCategory) {
    setLoading(true);
    try {
      const res = await fetch(`/api/groups?platform=${platform}&category=${category}`);
      const data = await res.json();
      if (data.ok) {
        setGroupsList(data.data || []);
      }
    } catch {
      // ignore
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    loadGroups(selectedPlatform, selectedCategory);
  }, [selectedPlatform, selectedCategory]);

  const platforms = [
    { id: "all", label: "🌟 Todas as Plataformas" },
    { id: "whatsapp", label: "💬 WhatsApp" },
    { id: "telegram", label: "✈️ Telegram" },
    { id: "discord", label: "🎮 Discord" },
  ];

  const categories = [
    { id: "all", label: "Todas as Categorias" },
    { id: "vendas", label: "🛒 Vendas & Descontos" },
    { id: "games", label: "🎮 Games & Free Fire" },
    { id: "cripto", label: "📈 Cripto & Investimentos" },
    { id: "afiliados", label: "🤝 Afiliados & Renda" },
    { id: "amizade", label: "👥 Amizade & Comunidade" },
    { id: "geral", label: "🌐 Geral" },
  ];

  return (
    <main className="min-h-screen bg-[#040817] text-slate-100 selection:bg-amber-400 selection:text-black px-4 py-8 md:px-6 md:py-12">
      <div className="mx-auto max-w-6xl">
        {/* Navigation Breadcrumb */}
        <div className="flex flex-col md:flex-row items-center justify-between gap-4 border-b border-slate-800 pb-6">
          <Link
            href="/"
            className="inline-flex items-center gap-2 text-sm font-bold text-amber-400 hover:text-amber-300 transition-colors"
          >
            <ArrowLeft size={18} /> Voltar à Loja
          </Link>

          <Link
            href="/perfil"
            className="inline-flex items-center gap-2 rounded-2xl bg-gradient-to-r from-amber-400 to-orange-400 px-5 py-2.5 text-xs font-black uppercase text-slate-950 shadow-lg shadow-amber-400/20 hover:scale-105 transition-all"
          >
            <PlusCircle size={16} /> Divulgar Meu Grupo (R$ 10/mês)
          </Link>
        </div>

        {/* Header */}
        <div className="mt-8 text-center md:mt-10">
          <div className="inline-flex items-center gap-2 rounded-full bg-amber-400/10 px-5 py-2 border border-amber-400/30 shadow-md mb-3">
            <Users className="text-amber-400" size={18} />
            <span className="text-xs font-black uppercase tracking-wider text-amber-300">
              COMUNIDADE OFICIAL • WHATSAPP, TELEGRAM & DISCORD
            </span>
          </div>

          <h1 className="text-4xl font-black tracking-tight text-white md:text-6xl">
            GRUPOS DA <span className="text-amber-400">COMUNIDADE</span>
          </h1>

          <p className="mx-auto mt-2 max-w-2xl text-sm md:text-base text-slate-300">
            Encontre os melhores grupos organizados por categorias e plataformas. <br />
            <span className="text-xs text-slate-400">
              Taxa de divulgação: apenas <strong>R$ 10,00 mensais</strong> para manter seu grupo no topo e apoiar a Sonic Vendas!
            </span>
          </p>
        </div>

        {/* Platform Tabs */}
        <div className="mt-8 flex flex-wrap items-center justify-center gap-2">
          {platforms.map((p) => {
            const isActive = selectedPlatform === p.id;
            return (
              <button
                key={p.id}
                type="button"
                onClick={() => setSelectedPlatform(p.id)}
                className={`rounded-2xl px-5 py-2.5 text-xs font-black uppercase tracking-wider transition-all ${
                  isActive
                    ? "bg-amber-400 text-slate-950 shadow-lg shadow-amber-400/20 scale-105"
                    : "bg-slate-900 border border-slate-800 text-slate-300 hover:bg-slate-800"
                }`}
              >
                {p.label}
              </button>
            );
          })}
        </div>

        {/* Category Filter Pills */}
        <div className="mt-4 flex flex-wrap items-center justify-center gap-2">
          {categories.map((c) => {
            const isActive = selectedCategory === c.id;
            return (
              <button
                key={c.id}
                type="button"
                onClick={() => setSelectedCategory(c.id)}
                className={`rounded-xl px-3 py-1.5 text-xs font-bold transition-all ${
                  isActive
                    ? "bg-cyan-500/20 border border-cyan-400 text-cyan-300"
                    : "bg-slate-950 border border-slate-800/80 text-slate-400 hover:text-white"
                }`}
              >
                {c.label}
              </button>
            );
          })}
        </div>

        {/* Groups Cards Grid */}
        <div className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {groupsList.map((g: any) => {
            const platformIcon = g.platform === "discord" ? "🎮 Discord" : g.platform === "telegram" ? "✈️ Telegram" : "💬 WhatsApp";
            const platformColor = g.platform === "discord" ? "border-indigo-500/40 text-indigo-300" : g.platform === "telegram" ? "border-cyan-500/40 text-cyan-300" : "border-emerald-500/40 text-emerald-300";

            return (
              <div
                key={g.id}
                className="group relative flex flex-col justify-between overflow-hidden rounded-3xl border border-slate-800 bg-slate-900/70 p-6 shadow-xl backdrop-blur-md transition-all hover:-translate-y-1 hover:border-amber-400/40 hover:shadow-2xl hover:shadow-amber-400/10"
              >
                <div>
                  <div className="relative mb-4 h-44 w-full overflow-hidden rounded-2xl bg-slate-950">
                    <img
                      src={g.imageUrl || "https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?w=400&q=80"}
                      alt={g.name}
                      className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
                      onError={(e) => {
                        (e.target as HTMLImageElement).src = "https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?w=400&q=80";
                      }}
                    />
                    <div className="absolute top-3 left-3 flex flex-wrap gap-1">
                      <span className={`rounded-full bg-slate-950/90 px-3 py-1 text-[10px] font-black uppercase tracking-wider backdrop-blur-md border ${platformColor}`}>
                        {platformIcon}
                      </span>
                      {g.category && (
                        <span className="rounded-full bg-slate-950/90 px-2.5 py-1 text-[10px] font-bold uppercase text-amber-400 border border-amber-400/30">
                          {g.category}
                        </span>
                      )}
                    </div>
                  </div>

                  <h3 className="text-xl font-black text-white group-hover:text-amber-400 transition-colors">
                    {g.name}
                  </h3>
                  <p className="mt-2 line-clamp-3 text-xs text-slate-400">
                    {g.description || "Grupo oficial da comunidade Sonic Vendas."}
                  </p>
                </div>

                <div className="mt-6 border-t border-slate-800/80 pt-4">
                  <div className="flex items-center justify-between text-xs font-bold text-slate-400 mb-3">
                    <span>Taxa de Manutenção:</span>
                    <span className="text-amber-400 font-black">R$ 10,00 / mês</span>
                  </div>

                  <a
                    href={g.linkUrl || "#"}
                    target="_blank"
                    rel="noreferrer"
                    className="flex w-full items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-amber-400 to-orange-400 py-3 text-xs font-black uppercase tracking-wider text-slate-950 shadow-lg shadow-amber-400/20 hover:brightness-110 transition-all"
                  >
                    Entrar no Grupo <ExternalLink size={14} />
                  </a>
                </div>
              </div>
            );
          })}
        </div>

        {groupsList.length === 0 && !loading && (
          <div className="mt-12 rounded-3xl border border-slate-800 bg-slate-900/40 p-12 text-center text-slate-500 shadow-xl">
            Nenhum grupo encontrado nesta categoria ou plataforma.
            <div className="mt-4">
              <Link
                href="/perfil"
                className="inline-flex items-center gap-2 rounded-xl bg-amber-400 px-5 py-2.5 text-xs font-black uppercase text-slate-950 hover:bg-amber-300 transition-all"
              >
                Cadastrar o Primeiro Grupo
              </Link>
            </div>
          </div>
        )}
      </div>
    </main>
  );
}
