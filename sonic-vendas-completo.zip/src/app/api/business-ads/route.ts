import { db } from "@/db";
import { businessAds, notifications } from "@/db/schema";
import { desc, eq } from "drizzle-orm";
import { NextResponse } from "next/server";

export async function GET() {
  try {
    const data = await db
      .select()
      .from(businessAds)
      .where(eq(businessAds.isActive, true))
      .orderBy(desc(businessAds.isBoosted), desc(businessAds.createdAt));

    return NextResponse.json(
      { ok: true, data },
      { headers: { "Cache-Control": "public, max-age=5, stale-while-revalidate=15" } }
    );
  } catch (e: any) {
    return NextResponse.json({ ok: false, error: e.message || "Failed" }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const {
      businessName,
      adTitle,
      description,
      category,
      photoUrl,
      videoUrl,
      productPrice,
      buyLink,
      phone,
      email,
      location,
      days,
      calculatedPrice,
      aiPricingBreakdown,
      receiptUrl,
    } = body || {};

    if (!businessName || !adTitle || !description || !phone) {
      return NextResponse.json(
        { ok: false, error: "Nome do negócio, título do anúncio, descrição e WhatsApp são obrigatórios." },
        { status: 400, headers: { "Cache-Control": "no-store, max-age=0" } }
      );
    }

    const durationDays = Math.max(1, parseInt(String(days || 15), 10));
    const price = calculatedPrice ? String(calculatedPrice) : (durationDays * 2.5).toFixed(2);

    const inserted = await db
      .insert(businessAds)
      .values({
        businessName: businessName.trim(),
        adTitle: adTitle.trim(),
        description: description.trim(),
        category: category || "loja",
        photoUrl: photoUrl || "https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=600&q=80",
        videoUrl: videoUrl || null,
        productPrice: productPrice ? String(productPrice) : null,
        buyLink: buyLink ? buyLink.trim() : null,
        phone: phone.trim(),
        email: email ? email.trim().toLowerCase() : null,
        location: location ? location.trim() : null,
        days: durationDays,
        calculatedPrice: price,
        aiPricingBreakdown: aiPricingBreakdown || `Orçamento de ${durationDays} dias calculado automaticamente pela IA com base em categoria (${category || "loja"}).`,
        status: "pending",
        receiptUrl: receiptUrl || null,
        isActive: true,
        viewsCount: 0,
        clicksWhatsapp: 0,
        clicksLink: 0,
        clicksBuy: 0,
        isBoosted: false,
      })
      .returning();

    const ad = inserted[0];

    // Notification for admin
    try {
      await db.insert(notifications).values({
        title: `💼 Nova Divulgação de Vendas & Negócios (#${ad.id})`,
        message: `${businessName} cadastrou anúncio "${adTitle}" por ${durationDays} dias (Orçamento IA: R$ ${price}). Aguardando análise/aprovação.`,
        isActive: true,
      });
    } catch {}

    return NextResponse.json(
      {
        ok: true,
        message: "Divulgação de negócios registrada com sucesso! O administrador irá analisar a proposta e o comprovante.",
        data: ad,
      },
      { headers: { "Cache-Control": "no-store, max-age=0" } }
    );
  } catch (e: any) {
    return NextResponse.json(
      { ok: false, error: e.message || "Erro ao registrar anúncio de negócios" },
      { status: 500, headers: { "Cache-Control": "no-store, max-age=0" } }
    );
  }
}
