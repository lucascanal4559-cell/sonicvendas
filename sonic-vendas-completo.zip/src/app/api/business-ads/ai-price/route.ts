import { NextResponse } from "next/server";

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const {
      days = 15,
      category = "loja",
      hasVideo = false,
      hasBuyLink = false,
      placement = "home_destaque", // home_destaque, topo_fixo, padrao
      boostRequested = false,
    } = body || {};

    const durationDays = Math.max(1, parseInt(String(days), 10));

    // Base rate per day according to category & commercial exposure
    let baseRatePerDay = 2.0; // R$ 2,00/dia base for businesses
    if (category === "promocao" || category === "loja") {
      baseRatePerDay = 2.5;
    } else if (category === "empresa" || category === "marca") {
      baseRatePerDay = 3.0;
    } else if (category === "servico") {
      baseRatePerDay = 2.2;
    }

    // Discounts for longer commitments (incentive)
    let durationMultiplier = 1.0;
    if (durationDays >= 30) {
      durationMultiplier = 0.75; // 25% discount on 30+ days
    } else if (durationDays >= 15) {
      durationMultiplier = 0.85; // 15% discount on 15+ days
    }

    let subtotal = durationDays * baseRatePerDay * durationMultiplier;

    // Feature additions
    let videoFee = hasVideo ? 10.0 : 0.0; // Adicional de suporte a vídeo 2min
    let linkFee = hasBuyLink ? 5.0 : 0.0; // Botão de compra direta / WhatsApp
    let placementFee = placement === "topo_fixo" ? 15.0 : placement === "home_destaque" ? 10.0 : 0.0;
    let boostFee = boostRequested ? 20.0 : 0.0;

    let total = Math.max(15.0, subtotal + videoFee + linkFee + placementFee + boostFee);

    // AI Explanation breakdown text
    const breakdown = [
      `📊 Orçamento Inteligente IA para ${durationDays} dias (${category.toUpperCase()}):`,
      `• Tarifa Base: R$ ${baseRatePerDay.toFixed(2)}/dia (${durationDays >= 15 ? "com desconto progressivo de período" : "diária avulsa"}) = R$ ${subtotal.toFixed(2)}`,
      hasVideo ? `• Mídia em Vídeo (até 2 min): +R$ ${videoFee.toFixed(2)}` : null,
      hasBuyLink ? `• Botão de Compra / Link Direto: +R$ ${linkFee.toFixed(2)}` : null,
      placement !== "padrao" ? `• Posição em Destaque Especial (${placement}): +R$ ${placementFee.toFixed(2)}` : null,
      boostRequested ? `• Impulsionamento Inicial Prioritário: +R$ ${boostFee.toFixed(2)}` : null,
      `✨ Total Sugerido pela IA: R$ ${total.toFixed(2)} (Economia estimada para negócios locais).`,
    ]
      .filter(Boolean)
      .join("\n");

    return NextResponse.json({
      ok: true,
      data: {
        days: durationDays,
        baseRatePerDay,
        subtotal: subtotal.toFixed(2),
        total: total.toFixed(2),
        breakdown,
        hasDiscount: durationDays >= 15,
        discountPercent: durationDays >= 30 ? 25 : durationDays >= 15 ? 15 : 0,
      },
    });
  } catch (e: any) {
    return NextResponse.json({ ok: false, error: e.message || "Failed" }, { status: 500 });
  }
}
