import { db } from "@/db";
import { raffles } from "@/db/schema";
import { desc, eq } from "drizzle-orm";
import { NextResponse } from "next/server";

export async function GET() {
  try {
    const data = await db
      .select()
      .from(raffles)
      .where(eq(raffles.isActive, true))
      .orderBy(desc(raffles.isFeatured), desc(raffles.createdAt));

    const enriched = data.map((r) => {
      const total = r.totalNumbers || 1000;
      const sold = r.numbersSold || 0;
      const remaining = Math.max(0, total - sold);
      const percentage = Math.min(100, Math.round((sold / total) * 100));
      return {
        ...r,
        remainingNumbers: remaining,
        percentageSold: percentage,
      };
    });

    return NextResponse.json(
      { ok: true, data: enriched },
      { headers: { "Cache-Control": "public, max-age=5, stale-while-revalidate=15" } }
    );
  } catch (e: any) {
    return NextResponse.json({ ok: false, error: e.message || "Failed to fetch raffles" }, { status: 500 });
  }
}
