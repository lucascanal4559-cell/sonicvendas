import { db } from "@/db";
import { raffles, raffleParticipations, raffleTickets, notifications } from "@/db/schema";
import { eq, sql } from "drizzle-orm";
import { NextResponse } from "next/server";

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { raffleId, customerName, customerEmail, customerPhone, quantity, paymentMethod } = body || {};

    if (!raffleId || !customerName || !customerEmail || !customerPhone || !quantity || quantity <= 0) {
      return NextResponse.json(
        { ok: false, error: "Preencha todos os campos obrigatórios e escolha uma quantidade válida de cotas." },
        { status: 400, headers: { "Cache-Control": "no-store, max-age=0" } }
      );
    }

    const qty = parseInt(String(quantity), 10);
    const raffleList = await db.select().from(raffles).where(eq(raffles.id, parseInt(String(raffleId), 10))).limit(1);

    if (!raffleList.length) {
      return NextResponse.json({ ok: false, error: "Sorteio não encontrado." }, { status: 404 });
    }

    const raffle = raffleList[0];
    if (raffle.status !== "open" || !raffle.isActive) {
      return NextResponse.json({ ok: false, error: "Este sorteio não está aberto para novas participações no momento." }, { status: 400 });
    }

    const totalAvailable = raffle.totalNumbers || 1000;
    const currentSold = raffle.numbersSold || 0;
    const remaining = totalAvailable - currentSold;

    if (qty > remaining) {
      return NextResponse.json(
        { ok: false, error: `Restam apenas ${remaining} cotas disponíveis para este sorteio.` },
        { status: 400 }
      );
    }

    const unitPrice = parseFloat(String(raffle.pricePerNumber)) || 0.10;
    const totalAmount = (qty * unitPrice).toFixed(2);

    // Get all currently used ticket numbers for this raffle
    const existingTickets = await db
      .select({ ticketNumber: raffleTickets.ticketNumber })
      .from(raffleTickets)
      .where(eq(raffleTickets.raffleId, raffle.id));

    const usedNumbersSet = new Set(existingTickets.map((t) => t.ticketNumber));

    // Pad length determination (e.g. 1000 -> 4 digits '0001', 2000 -> 4 digits '0001')
    const padLength = Math.max(4, String(totalAvailable).length);

    // Allocate next available numbers
    const allocatedNumbers: number[] = [];
    const allocatedCodes: string[] = [];

    // Find available numbers
    let candidate = 1;
    while (allocatedNumbers.length < qty && candidate <= totalAvailable) {
      if (!usedNumbersSet.has(candidate)) {
        allocatedNumbers.push(candidate);
        allocatedCodes.push(String(candidate).padStart(padLength, "0"));
      }
      candidate++;
    }

    if (allocatedNumbers.length < qty) {
      return NextResponse.json(
        { ok: false, error: "Não há cotas suficientes disponíveis para atender esta quantidade." },
        { status: 400 }
      );
    }

    // Insert participation
    const participationRes = await db
      .insert(raffleParticipations)
      .values({
        raffleId: raffle.id,
        customerName: customerName.trim(),
        customerEmail: customerEmail.trim().toLowerCase(),
        customerPhone: customerPhone.trim(),
        quantity: qty,
        totalAmount: totalAmount,
        ticketCodes: allocatedCodes,
        status: "approved",
        paymentMethod: paymentMethod || "mercadopago",
      })
      .returning();

    const participation = participationRes[0];

    // Bulk insert tickets
    const ticketInserts = allocatedNumbers.map((num, i) => ({
      raffleId: raffle.id,
      participationId: participation.id,
      ticketNumber: num,
      ticketCode: allocatedCodes[i],
      customerName: customerName.trim(),
      customerEmail: customerEmail.trim().toLowerCase(),
      customerPhone: customerPhone.trim(),
      isWinner: false,
    }));

    await db.insert(raffleTickets).values(ticketInserts);

    // Update numbers sold on raffle
    await db
      .update(raffles)
      .set({
        numbersSold: sql`${raffles.numbersSold} + ${qty}`,
        updatedAt: new Date(),
      })
      .where(eq(raffles.id, raffle.id));

    // Add admin notification
    try {
      await db.insert(notifications).values({
        title: `🎟️ Nova Participação no Sorteio #${raffle.id}`,
        message: `${customerName} comprou ${qty} cotas (R$ ${totalAmount}) para o sorteio "${raffle.title}". Códigos atribuídos: ${allocatedCodes.slice(0, 5).join(", ")}${allocatedCodes.length > 5 ? "..." : ""}`,
        isActive: true,
      });
    } catch {}

    return NextResponse.json(
      {
        ok: true,
        message: `Parabéns! Suas ${qty} cotas foram registradas com sucesso.`,
        data: {
          participationId: participation.id,
          raffleTitle: raffle.title,
          quantity: qty,
          totalAmount: totalAmount,
          ticketCodes: allocatedCodes,
          drawDate: raffle.drawDate,
          drawMethod: raffle.drawMethod,
          lotteryContestNumber: raffle.lotteryContestNumber,
          instagramLiveUrl: raffle.instagramLiveUrl,
        },
      },
      { headers: { "Cache-Control": "no-store, max-age=0" } }
    );
  } catch (e: any) {
    return NextResponse.json(
      { ok: false, error: e.message || "Erro ao processar compra de cotas" },
      { status: 500, headers: { "Cache-Control": "no-store, max-age=0" } }
    );
  }
}
