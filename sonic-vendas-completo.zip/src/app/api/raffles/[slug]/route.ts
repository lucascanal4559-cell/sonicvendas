import { db } from "@/db";
import { raffles, raffleTickets } from "@/db/schema";
import { eq } from "drizzle-orm";
import { NextResponse } from "next/server";

export async function GET(req: Request, { params }: { params: Promise<{ slug: string }> }) {
  try {
    const { slug } = await params;
    const found = await db.select().from(raffles).where(eq(raffles.slug, slug)).limit(1);

    if (!found.length) {
      return NextResponse.json({ ok: false, error: "Sorteio não encontrado" }, { status: 404 });
    }

    const r = found[0];
    const total = r.totalNumbers || 1000;
    const sold = r.numbersSold || 0;
    const remaining = Math.max(0, total - sold);
    const percentage = Math.min(100, Math.round((sold / total) * 100));

    // Get count of participants or recent ticket count
    const tickets = await db
      .select({
        id: raffleTickets.id,
        ticketNumber: raffleTickets.ticketNumber,
        ticketCode: raffleTickets.ticketCode,
        isWinner: raffleTickets.isWinner,
      })
      .from(raffleTickets)
      .where(eq(raffleTickets.raffleId, r.id))
      .limit(50);

    return NextResponse.json(
      {
        ok: true,
        data: {
          ...r,
          remainingNumbers: remaining,
          percentageSold: percentage,
          recentTickets: tickets,
        },
      },
      { headers: { "Cache-Control": "public, max-age=5, stale-while-revalidate=15" } }
    );
  } catch (e: any) {
    return NextResponse.json({ ok: false, error: e.message || "Failed to fetch raffle" }, { status: 500 });
  }
}
