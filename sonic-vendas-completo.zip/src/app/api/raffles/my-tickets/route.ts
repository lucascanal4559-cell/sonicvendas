import { db } from "@/db";
import { raffleParticipations, raffles } from "@/db/schema";
import { eq, desc, or } from "drizzle-orm";
import { NextResponse } from "next/server";

export async function GET(req: Request) {
  try {
    const { searchParams } = new URL(req.url);
    const email = searchParams.get("email")?.trim().toLowerCase();
    const phone = searchParams.get("phone")?.trim();

    if (!email && !phone) {
      return NextResponse.json(
        { ok: false, error: "Informe e-mail ou WhatsApp para buscar seus bilhetes." },
        { status: 400, headers: { "Cache-Control": "no-store, max-age=0" } }
      );
    }

    const conditions = [];
    if (email) conditions.push(eq(raffleParticipations.customerEmail, email));
    if (phone) conditions.push(eq(raffleParticipations.customerPhone, phone));

    const participations = await db
      .select({
        id: raffleParticipations.id,
        raffleId: raffleParticipations.raffleId,
        customerName: raffleParticipations.customerName,
        customerEmail: raffleParticipations.customerEmail,
        customerPhone: raffleParticipations.customerPhone,
        quantity: raffleParticipations.quantity,
        totalAmount: raffleParticipations.totalAmount,
        ticketCodes: raffleParticipations.ticketCodes,
        status: raffleParticipations.status,
        createdAt: raffleParticipations.createdAt,
        raffleTitle: raffles.title,
        raffleSlug: raffles.slug,
        raffleImage: raffles.imageUrl,
        raffleStatus: raffles.status,
        drawDate: raffles.drawDate,
        drawMethod: raffles.drawMethod,
        lotteryContestNumber: raffles.lotteryContestNumber,
        winnerCode: raffles.winnerCode,
        instagramLiveUrl: raffles.instagramLiveUrl,
      })
      .from(raffleParticipations)
      .leftJoin(raffles, eq(raffleParticipations.raffleId, raffles.id))
      .where(or(...conditions))
      .orderBy(desc(raffleParticipations.createdAt));

    return NextResponse.json(
      { ok: true, data: participations },
      { headers: { "Cache-Control": "no-store, max-age=0" } }
    );
  } catch (e: any) {
    return NextResponse.json(
      { ok: false, error: e.message || "Erro ao buscar cotas" },
      { status: 500, headers: { "Cache-Control": "no-store, max-age=0" } }
    );
  }
}
