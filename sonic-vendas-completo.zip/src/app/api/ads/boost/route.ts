import { db } from "@/db";
import { adBoostOrders, contactAds, businessAds, notifications } from "@/db/schema";
import { eq } from "drizzle-orm";
import { NextResponse } from "next/server";

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { adType, adId, customerName, customerPhone, planName, days, amount, paymentMethod, receiptUrl } = body || {};

    if (!adType || !adId || !customerName || !customerPhone || !planName || !amount) {
      return NextResponse.json(
        { ok: false, error: "Dados incompletos para impulsionamento." },
        { status: 400, headers: { "Cache-Control": "no-store, max-age=0" } }
      );
    }

    const inserted = await db
      .insert(adBoostOrders)
      .values({
        adType,
        adId: parseInt(String(adId), 10),
        customerName: customerName.trim(),
        customerPhone: customerPhone.trim(),
        planName,
        days: parseInt(String(days || 7), 10),
        amount: String(amount),
        paymentMethod: paymentMethod || "pix",
        receiptUrl: receiptUrl || null,
        status: "pending",
      })
      .returning();

    const boostOrder = inserted[0];

    // Notification for admin
    try {
      await db.insert(notifications).values({
        title: `⚡ Nova Solicitação de Impulsionamento (#${boostOrder.id})`,
        message: `${customerName} solicitou plano "${planName}" para ${adType === "contact" ? "Contato" : "Negócio"} #${adId} (R$ ${amount}). Analise no painel ADM.`,
        isActive: true,
      });
    } catch {}

    return NextResponse.json(
      {
        ok: true,
        message: "Solicitação de impulsionamento registrada! O administrador ativará o destaque assim que conferir o pagamento.",
        data: boostOrder,
      },
      { headers: { "Cache-Control": "no-store, max-age=0" } }
    );
  } catch (e: any) {
    return NextResponse.json(
      { ok: false, error: e.message || "Erro ao registrar impulsionamento" },
      { status: 500, headers: { "Cache-Control": "no-store, max-age=0" } }
    );
  }
}
