import { db } from "@/db";
import { publications } from "@/db/schema";
import { desc, eq } from "drizzle-orm";
import { NextResponse } from "next/server";

export async function GET() {
  try {
    const data = await db.select().from(publications).where(eq(publications.isActive, true)).orderBy(desc(publications.createdAt));
    return NextResponse.json({ ok: true, data }, { headers: { "Cache-Control": "public, max-age=5, stale-while-revalidate=30" } });
  } catch (e: any) {
    return NextResponse.json({ ok: false, error: e.message || "Failed" }, { status: 500 });
  }
}
