import { db } from "@/db";
import { publications } from "@/db/schema";
import { eq } from "drizzle-orm";
import { NextResponse } from "next/server";

function requireCustomerAuth(req: Request) {
  const authHeader = req.headers.get("authorization") || "";
  const token = authHeader.replace("Bearer ", "");
  if (!token) throw new Error("Not authenticated");
  try {
    const payload = JSON.parse(Buffer.from(token, "base64url").toString());
    if (payload.exp && Date.now() > payload.exp) throw new Error("Session expired");
    return payload;
  } catch {
    throw new Error("Invalid token");
  }
}

export async function POST(req: Request) {
  try {
    const user = requireCustomerAuth(req);
    const body = await req.json();
    const days = parseInt(String(body.days), 10) || 1;
    const price = days * 1.0;
    const inserted = await db.insert(publications).values({
      name: body.name,
      description: body.description || null,
      imageUrl: body.imageUrl || null,
      videoUrl: body.videoUrl || null,
      linkUrl: body.linkUrl || null,
      days: days,
      price: price.toFixed(2),
      contactPhone: body.contactPhone || null,
      contactEmail: body.contactEmail || null,
      status: "pending",
      customerId: user.userId,
      isActive: false,
      isTop: false,
    }).returning();
    return NextResponse.json({ ok: true, data: inserted[0] }, { headers: { "Cache-Control": "no-store, max-age=0" } });
  } catch (e: any) {
    return NextResponse.json({ ok: false, error: e.message || "Failed" }, { status: 401, headers: { "Cache-Control": "no-store, max-age=0" } });
  }
}
