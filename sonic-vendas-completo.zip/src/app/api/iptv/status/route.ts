import { db } from "@/db";
import { iptvRequests } from "@/db/schema";
import { eq, desc, and, or } from "drizzle-orm";
import { NextResponse } from "next/server";

export async function GET(req: Request) {
  try {
    const { searchParams } = new URL(req.url);
    const email = searchParams.get("email")?.trim().toLowerCase();
    const phone = searchParams.get("phone")?.trim();
    const id = searchParams.get("id");

    if (!email && !phone && !id) {
      return NextResponse.json(
        { ok: false, error: "Informe e-mail ou telefone para consultar seu IPTV." },
        { status: 400, headers: { "Cache-Control": "no-store, max-age=0" } }
      );
    }

    const conditions = [];
    if (id) {
      conditions.push(eq(iptvRequests.id, parseInt(id, 10)));
    } else if (email && phone) {
      conditions.push(or(eq(iptvRequests.customerEmail, email), eq(iptvRequests.customerPhone, phone)));
    } else if (email) {
      conditions.push(eq(iptvRequests.customerEmail, email));
    } else if (phone) {
      conditions.push(eq(iptvRequests.customerPhone, phone));
    }

    const requests = await db
      .select()
      .from(iptvRequests)
      .where(or(...conditions))
      .orderBy(desc(iptvRequests.createdAt))
      .limit(1);

    if (!requests.length) {
      return NextResponse.json(
        { ok: false, error: "Nenhuma solicitação de IPTV encontrada com os dados informados." },
        { status: 404, headers: { "Cache-Control": "no-store, max-age=0" } }
      );
    }

    const item = requests[0];
    const now = new Date();

    // Check if expired
    let currentStatus = item.status;
    let remainingSeconds = 0;

    if (item.status === "approved" && item.expiresAt) {
      const expiresAtTime = new Date(item.expiresAt).getTime();
      const diffMs = expiresAtTime - now.getTime();
      if (diffMs <= 0) {
        currentStatus = "expired";
        // Update in database if needed
        await db
          .update(iptvRequests)
          .set({ status: "expired", updatedAt: new Date() })
          .where(eq(iptvRequests.id, item.id));
      } else {
        remainingSeconds = Math.floor(diffMs / 1000);
      }
    }

    return NextResponse.json(
      {
        ok: true,
        data: {
          id: item.id,
          customerName: item.customerName,
          customerEmail: item.customerEmail,
          status: currentStatus,
          hours: item.hours,
          approvedAt: item.approvedAt,
          expiresAt: item.expiresAt,
          remainingSeconds: currentStatus === "approved" ? remainingSeconds : 0,
          serverUrl: currentStatus === "approved" ? item.serverUrl : null,
          username: currentStatus === "approved" ? item.username : null,
          password: currentStatus === "approved" ? item.password : null,
          m3uUrl: currentStatus === "approved" ? item.m3uUrl : null,
          instructions: currentStatus === "approved" ? item.instructions : null,
          createdAt: item.createdAt,
        },
      },
      { headers: { "Cache-Control": "no-store, max-age=0" } }
    );
  } catch (e: any) {
    return NextResponse.json(
      { ok: false, error: e.message || "Falha ao consultar IPTV" },
      { status: 500, headers: { "Cache-Control": "no-store, max-age=0" } }
    );
  }
}
