import { db } from "@/db";
import { iptvRequests, notifications } from "@/db/schema";
import { NextResponse } from "next/server";

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { customerName, customerEmail, customerPhone } = body || {};

    if (!customerName || !customerEmail || !customerPhone) {
      return NextResponse.json(
        { ok: false, error: "Nome completo, e-mail e telefone são obrigatórios." },
        { status: 400, headers: { "Cache-Control": "no-store, max-age=0" } }
      );
    }

    const inserted = await db
      .insert(iptvRequests)
      .values({
        customerName: customerName.trim(),
        customerEmail: customerEmail.trim().toLowerCase(),
        customerPhone: customerPhone.trim(),
        status: "pending",
        hours: 12,
      })
      .returning();

    // Register notification for admin
    try {
      await db.insert(notifications).values({
        title: "⚡ Nova Solicitação de Teste IPTV (12h)",
        message: `${customerName} (${customerEmail} - ${customerPhone}) solicitou acesso de teste IPTV 12 Horas. Libere no painel ADM.`,
        isActive: true,
      });
    } catch {
      // notification logging shouldn't block request
    }

    return NextResponse.json(
      {
        ok: true,
        message: "Solicitação recebida com sucesso! Em instantes nosso administrador liberará seus dados de acesso por 12 horas.",
        data: {
          id: inserted[0].id,
          customerName: inserted[0].customerName,
          customerEmail: inserted[0].customerEmail,
          status: inserted[0].status,
          createdAt: inserted[0].createdAt,
        },
      },
      { headers: { "Cache-Control": "no-store, max-age=0" } }
    );
  } catch (e: any) {
    return NextResponse.json(
      { ok: false, error: e.message || "Erro ao processar solicitação de IPTV" },
      { status: 500, headers: { "Cache-Control": "no-store, max-age=0" } }
    );
  }
}
