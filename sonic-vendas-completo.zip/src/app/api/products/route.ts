import { db } from "@/db";
import { products, categories } from "@/db/schema";
import { eq, desc } from "drizzle-orm";
import { NextResponse } from "next/server";

export async function GET(req: Request) {
  try {
    const { searchParams } = new URL(req.url);
    const categorySlug = searchParams.get("category");
    const search = searchParams.get("search") || "";

    let result = await db.select({
      id: products.id,
      title: products.title,
      slug: products.slug,
      description: products.description,
      price: products.price,
      originalPrice: products.originalPrice,
      categoryId: products.categoryId,
      imageUrl: products.imageUrl,
      images: products.images,
      isActive: products.isActive,
      isPromotion: products.isPromotion,
      discountPercent: products.discountPercent,
      availability: products.availability,
      categoryName: categories.name,
      categorySlug: categories.slug,
    })
    .from(products)
    .leftJoin(categories, eq(products.categoryId, categories.id))
    .where(eq(products.isActive, true))
    .orderBy(desc(products.createdAt));

    if (categorySlug) {
      result = result.filter((r) => r.categorySlug === categorySlug);
    }
    if (search) {
      const s = search.toLowerCase();
      result = result.filter((r) => r.title.toLowerCase().includes(s) || r.description.toLowerCase().includes(s));
    }

    return NextResponse.json({ ok: true, data: result }, { headers: { "Cache-Control": "public, max-age=10, stale-while-revalidate=60" } });
  } catch (e) {
    return NextResponse.json({ ok: false, error: "Failed to fetch products" }, { status: 500 });
  }
}
