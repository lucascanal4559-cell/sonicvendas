import { db } from "@/db";
import { products, categories } from "@/db/schema";
import { eq } from "drizzle-orm";
import { NextResponse } from "next/server";

export async function GET(req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params;
    const result = await db.select({
      id: products.id,
      title: products.title,
      slug: products.slug,
      description: products.description,
      price: products.price,
      originalPrice: products.originalPrice,
      categoryId: products.categoryId,
      imageUrl: products.imageUrl,
      images: products.images,
      isActive: products.isActive,
      isPromotion: products.isPromotion,
      discountPercent: products.discountPercent,
      availability: products.availability,
      categoryName: categories.name,
      categorySlug: categories.slug,
    })
    .from(products)
    .leftJoin(categories, eq(products.categoryId, categories.id))
    .where(eq(products.id, parseInt(id, 10)));

    if (!result.length) return NextResponse.json({ ok: false, error: "Not found" }, { status: 404 });
    return NextResponse.json({ ok: true, data: result[0] }, { headers: { "Cache-Control": "public, max-age=10, stale-while-revalidate=60" } });
  } catch (e) {
    return NextResponse.json({ ok: false, error: "Failed to fetch product" }, { status: 500 });
  }
}
