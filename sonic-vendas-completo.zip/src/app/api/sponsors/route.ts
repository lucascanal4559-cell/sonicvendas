import { db } from "@/db";
import { sponsors } from "@/db/schema";
import { desc, eq } from "drizzle-orm";
import { NextResponse } from "next/server";

export async function GET() {
  try {
    const data = await db.select().from(sponsors).where(eq(sponsors.isActive, true)).orderBy(desc(sponsors.createdAt));
    return NextResponse.json({ ok: true, data }, { headers: { "Cache-Control": "public, max-age=10, stale-while-revalidate=60" } });
  } catch (e: any) {
    return NextResponse.json({ ok: false, error: e.message || "Failed" }, { status: 500 });
  }
}
