import { db } from "@/db";
import { banners } from "@/db/schema";
import { eq } from "drizzle-orm";
import { NextResponse } from "next/server";

export async function GET() {
  try {
    const data = await db.select().from(banners).where(eq(banners.isActive, true)).orderBy(banners.order, banners.createdAt);
    return NextResponse.json({ ok: true, data }, { headers: { "Cache-Control": "public, max-age=10, stale-while-revalidate=60" } });
  } catch (e) {
    return NextResponse.json({ ok: false, error: "Failed to fetch banners" }, { status: 500 });
  }
}
