import { db } from "@/db";
import { categories } from "@/db/schema";
import { eq } from "drizzle-orm";
import { NextResponse } from "next/server";

export async function GET() {
  try {
    const data = await db.select().from(categories).where(eq(categories.isActive, true)).orderBy(categories.name);
    return NextResponse.json({ ok: true, data }, { headers: { "Cache-Control": "public, max-age=10, stale-while-revalidate=60" } });
  } catch (e) {
    return NextResponse.json({ ok: false, error: "Failed to fetch categories" }, { status: 500 });
  }
}
