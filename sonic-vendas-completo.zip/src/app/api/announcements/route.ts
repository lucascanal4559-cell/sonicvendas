import { db } from "@/db";
import { siteAnnouncements } from "@/db/schema";
import { desc, eq } from "drizzle-orm";
import { NextResponse } from "next/server";

export async function GET() {
  try {
    const data = await db
      .select()
      .from(siteAnnouncements)
      .where(eq(siteAnnouncements.isActive, true))
      .orderBy(desc(siteAnnouncements.priority), desc(siteAnnouncements.createdAt));

    return NextResponse.json(
      { ok: true, data },
      { headers: { "Cache-Control": "public, max-age=5, stale-while-revalidate=15" } }
    );
  } catch (e: any) {
    return NextResponse.json({ ok: false, error: e.message || "Failed" }, { status: 500 });
  }
}
