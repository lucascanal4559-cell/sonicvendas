import { db } from "@/db";
import { notifications } from "@/db/schema";
import { NextResponse } from "next/server";

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const inserted = await db.insert(notifications).values({
      title: body.title,
      message: body.message || null,
      isActive: true,
    }).returning();
    return NextResponse.json({ ok: true, data: inserted[0] }, { headers: { "Cache-Control": "no-store, max-age=0" } });
  } catch (e: any) {
    return NextResponse.json({ ok: false, error: e.message || "Failed" }, { status: 500, headers: { "Cache-Control": "no-store, max-age=0" } });
  }
}
