import { db } from "@/db";
import { notifications } from "@/db/schema";
import { desc, eq } from "drizzle-orm";
import { NextResponse } from "next/server";

export async function GET() {
  try {
    const data = await db.select().from(notifications).where(eq(notifications.isActive, true)).orderBy(desc(notifications.createdAt)).limit(5);
    return NextResponse.json({ ok: true, data }, { headers: { "Cache-Control": "public, max-age=5, stale-while-revalidate=30" } });
  } catch (e: any) {
    return NextResponse.json({ ok: false, error: e.message || "Failed" }, { status: 500 });
  }
}
