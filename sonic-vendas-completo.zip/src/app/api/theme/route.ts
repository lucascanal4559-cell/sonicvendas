import { db } from "@/db";
import { siteConfig } from "@/db/schema";
import { NextResponse } from "next/server";

export async function GET() {
  try {
    const data = await db.select().from(siteConfig);
    const configMap: Record<string, string> = {
      primaryColor: "#f59e0b",
      secondaryColor: "#06b6d4",
      buttonColor: "#f59e0b",
      menuColor: "#0f172a",
      textColor: "#f8fafc",
      backgroundColor: "#020617",
      cardColor: "#0f172a",
      backgroundImageUrl: "",
      backgroundVideoUrl: "",
      backgroundOverlayOpacity: "0.85",
      backgroundScope: "all",
      soundEnabled: "true",
      soundVolume: "80",
      maintenanceMode: "false",
      maintenanceMessage: "Sonic Vendas está em atualização programada.",
      maintenanceEstimate: "Previsão de retorno em instantes.",
      maintenanceImage: "",
    };

    data.forEach((item) => {
      configMap[item.key] = item.value;
    });

    return NextResponse.json(
      { ok: true, data: configMap },
      { headers: { "Cache-Control": "public, max-age=5, stale-while-revalidate=15" } }
    );
  } catch (e: any) {
    return NextResponse.json({ ok: false, error: e.message || "Failed" }, { status: 500 });
  }
}
