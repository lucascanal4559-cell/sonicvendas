import { db } from "@/db";
import { roulettePrizes } from "@/db/schema";
import { eq } from "drizzle-orm";
import { NextResponse } from "next/server";

export async function GET() {
  try {
    const prizes = await db
      .select()
      .from(roulettePrizes)
      .where(eq(roulettePrizes.isActive, true));

    return NextResponse.json(
      { ok: true, data: prizes },
      { headers: { "Cache-Control": "public, max-age=30, stale-while-revalidate=60" } }
    );
  } catch (e: any) {
    return NextResponse.json({ ok: false, error: e.message || "Failed" }, { status: 500 });
  }
}
