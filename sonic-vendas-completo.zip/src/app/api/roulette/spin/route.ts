import { db } from "@/db";
import { roulettePrizes, rouletteSpins } from "@/db/schema";
import { eq } from "drizzle-orm";
import { NextResponse } from "next/server";

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { customerName, customerEmail, customerPhone } = body || {};

    if (!customerName || !customerEmail) {
      return NextResponse.json(
        { ok: false, error: "Informe seu nome e e-mail para girar a roleta da sorte." },
        { status: 400, headers: { "Cache-Control": "no-store, max-age=0" } }
      );
    }

    const prizes = await db
      .select()
      .from(roulettePrizes)
      .where(eq(roulettePrizes.isActive, true));

    if (!prizes.length) {
      return NextResponse.json({ ok: false, error: "Nenhum prêmio disponível no momento." }, { status: 400 });
    }

    // Weighted random selection
    const totalWeight = prizes.reduce((acc, p) => acc + (p.probability || 10), 0);
    let randomNum = Math.random() * totalWeight;
    let selectedPrize = prizes[0];
    let selectedIndex = 0;

    for (let i = 0; i < prizes.length; i++) {
      const p = prizes[i];
      const weight = p.probability || 10;
      if (randomNum <= weight) {
        selectedPrize = p;
        selectedIndex = i;
        break;
      }
      randomNum -= weight;
    }

    // Generate unique coupon / prize code
    const prizeCode = selectedPrize.couponCode || `SONIC-${Math.random().toString(36).substring(2, 8).toUpperCase()}`;

    // Record the spin in database
    await db.insert(rouletteSpins).values({
      customerName: customerName.trim(),
      customerEmail: customerEmail.trim().toLowerCase(),
      customerPhone: customerPhone ? customerPhone.trim() : null,
      prizeWon: `${selectedPrize.title} (${selectedPrize.value})`,
      prizeCode: prizeCode,
    });

    return NextResponse.json(
      {
        ok: true,
        prizeIndex: selectedIndex,
        prize: {
          id: selectedPrize.id,
          title: selectedPrize.title,
          value: selectedPrize.value,
          couponCode: prizeCode,
          color: selectedPrize.color,
          prizeType: selectedPrize.prizeType,
        },
      },
      { headers: { "Cache-Control": "no-store, max-age=0" } }
    );
  } catch (e: any) {
    return NextResponse.json(
      { ok: false, error: e.message || "Erro ao processar giro da roleta" },
      { status: 500, headers: { "Cache-Control": "no-store, max-age=0" } }
    );
  }
}
