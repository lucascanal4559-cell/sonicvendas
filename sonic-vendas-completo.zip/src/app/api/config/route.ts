import { db } from "@/db";
import { siteConfig } from "@/db/schema";
import { eq } from "drizzle-orm";
import { NextResponse } from "next/server";

export async function GET() {
  try {
    const data = await db.select().from(siteConfig);
    const config: Record<string, string> = {};
    for (const item of data) {
      config[item.key] = item.value;
    }
    return NextResponse.json({ ok: true, data: config }, { headers: { "Cache-Control": "public, max-age=30, stale-while-revalidate=120" } });
  } catch (e) {
    return NextResponse.json({ ok: false, error: "Failed to fetch config" }, { status: 500 });
  }
}
