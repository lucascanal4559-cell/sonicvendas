import { db } from "@/db";
import { contactAds } from "@/db/schema";
import { eq, sql } from "drizzle-orm";
import { NextResponse } from "next/server";

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { id, type } = body || {};

    if (!id || !type) {
      return NextResponse.json({ ok: false, error: "ID and type are required" }, { status: 400 });
    }

    const adId = parseInt(String(id), 10);

    if (type === "view") {
      await db
        .update(contactAds)
        .set({ viewsCount: sql`${contactAds.viewsCount} + 1` })
        .where(eq(contactAds.id, adId));
    } else if (type === "whatsapp") {
      await db
        .update(contactAds)
        .set({ clicksWhatsapp: sql`${contactAds.clicksWhatsapp} + 1` })
        .where(eq(contactAds.id, adId));
    } else if (type === "link") {
      await db
        .update(contactAds)
        .set({ clicksLink: sql`${contactAds.clicksLink} + 1` })
        .where(eq(contactAds.id, adId));
    }

    return NextResponse.json({ ok: true });
  } catch (e: any) {
    return NextResponse.json({ ok: false, error: e.message || "Failed" }, { status: 500 });
  }
}
