import { db } from "@/db";
import { contactAds, notifications } from "@/db/schema";
import { desc, eq } from "drizzle-orm";
import { NextResponse } from "next/server";

export async function GET() {
  try {
    const data = await db
      .select()
      .from(contactAds)
      .where(eq(contactAds.isActive, true))
      .orderBy(desc(contactAds.isBoosted), desc(contactAds.createdAt));

    return NextResponse.json(
      { ok: true, data },
      { headers: { "Cache-Control": "public, max-age=5, stale-while-revalidate=15" } }
    );
  } catch (e: any) {
    return NextResponse.json({ ok: false, error: e.message || "Failed" }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { name, age, profilePhoto, videoUrl, description, phone, email, contactLink, city, days, receiptUrl } = body || {};

    if (!name || !description || !phone) {
      return NextResponse.json(
        { ok: false, error: "Nome, WhatsApp e descrição são obrigatórios." },
        { status: 400, headers: { "Cache-Control": "no-store, max-age=0" } }
      );
    }

    const durationDays = Math.max(1, parseInt(String(days || 7), 10));
    const totalPrice = (durationDays * 1.0).toFixed(2); // R$ 1,00 por dia fixo

    const inserted = await db
      .insert(contactAds)
      .values({
        name: name.trim(),
        age: age ? String(age).trim() : null,
        profilePhoto: profilePhoto || "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=500&q=80",
        videoUrl: videoUrl || null,
        description: description.trim(),
        phone: phone.trim(),
        email: email ? email.trim().toLowerCase() : null,
        contactLink: contactLink ? contactLink.trim() : null,
        city: city ? city.trim() : null,
        days: durationDays,
        price: totalPrice,
        status: "pending",
        receiptUrl: receiptUrl || null,
        isActive: true,
        viewsCount: 0,
        clicksWhatsapp: 0,
        clicksLink: 0,
        isBoosted: false,
      })
      .returning();

    const ad = inserted[0];

    // Notification for admin
    try {
      await db.insert(notifications).values({
        title: `👤 Nova Divulgação de Contato (#${ad.id})`,
        message: `${name} cadastrou perfil para divulgação por ${durationDays} dias (R$ ${totalPrice}). Aguardando análise/comprovante.`,
        isActive: true,
      });
    } catch {}

    return NextResponse.json(
      {
        ok: true,
        message: "Divulgação de contato cadastrada com sucesso! Realize o pagamento pelo Pix 75981558007 para ativação.",
        data: ad,
      },
      { headers: { "Cache-Control": "no-store, max-age=0" } }
    );
  } catch (e: any) {
    return NextResponse.json(
      { ok: false, error: e.message || "Erro ao registrar divulgação de contato" },
      { status: 500, headers: { "Cache-Control": "no-store, max-age=0" } }
    );
  }
}
