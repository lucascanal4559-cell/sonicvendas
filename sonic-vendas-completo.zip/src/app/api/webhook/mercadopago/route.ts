import { db } from "@/db";
import { orders } from "@/db/schema";
import { eq } from "drizzle-orm";
import { NextResponse } from "next/server";

export async function POST(req: Request) {
  try {
    const body = await req.json();
    // Simula webhook do Mercado Pago com um payload simples
    const orderId = body.data?.id || body.orderId || body.id;
    const paymentStatus = body.status || body.type || body.action || "approved";

    if (!orderId) {
      return NextResponse.json({ ok: false, error: "Order ID missing" }, { status: 400, headers: { "Cache-Control": "no-store, max-age=0" } });
    }

    const updated = await db.update(orders)
      .set({
        isPaid: paymentStatus === "approved" || paymentStatus === "paid",
        status: paymentStatus === "approved" ? "approved" : paymentStatus === "rejected" ? "rejected" : "pending",
        paymentId: body.payment_id || body.id || String(orderId),
        updatedAt: new Date(),
      })
      .where(eq(orders.id, parseInt(String(orderId), 10)))
      .returning();

    return NextResponse.json({ ok: true, message: "Webhook processed", data: updated[0] }, { headers: { "Cache-Control": "no-store, max-age=0" } });
  } catch (e: any) {
    return NextResponse.json({ ok: false, error: e.message || "Webhook failed" }, { status: 500, headers: { "Cache-Control": "no-store, max-age=0" } });
  }
}
