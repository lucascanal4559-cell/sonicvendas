import { db } from "@/db";
import { pixReceipts, orders, notifications } from "@/db/schema";
import { eq } from "drizzle-orm";
import { NextResponse } from "next/server";

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { orderId, customerName, customerEmail, customerPhone, receiptUrl, amount } = body || {};

    if (!receiptUrl || !customerName) {
      return NextResponse.json(
        { ok: false, error: "Envie a foto ou link do comprovante Pix e informe seu nome." },
        { status: 400, headers: { "Cache-Control": "no-store, max-age=0" } }
      );
    }

    const inserted = await db
      .insert(pixReceipts)
      .values({
        orderId: orderId ? parseInt(String(orderId), 10) : null,
        customerName: customerName.trim(),
        customerEmail: customerEmail ? customerEmail.trim().toLowerCase() : "cliente@pix.com",
        customerPhone: customerPhone ? customerPhone.trim() : null,
        receiptUrl: receiptUrl.trim(),
        amount: amount || "0.00",
        status: "pending",
      })
      .returning();

    // If orderId was given, update receiptUrl on the order too
    if (orderId) {
      try {
        await db
          .update(orders)
          .set({ receiptUrl: receiptUrl.trim(), updatedAt: new Date() })
          .where(eq(orders.id, parseInt(String(orderId), 10)));
      } catch {}
    }

    // Add notification for ADM
    try {
      await db.insert(notifications).values({
        title: "📄 Novo Comprovante Pix Enviado",
        message: `${customerName} enviou um comprovante Pix (R$ ${amount || "0.00"})${orderId ? ` para o Pedido #${orderId}` : ""}. Analise no painel ADM.`,
        isActive: true,
      });
    } catch {}

    return NextResponse.json(
      {
        ok: true,
        message: "Comprovante enviado com sucesso! O administrador irá analisar e aprovar seu pedido em instantes.",
        data: inserted[0],
      },
      { headers: { "Cache-Control": "no-store, max-age=0" } }
    );
  } catch (e: any) {
    return NextResponse.json(
      { ok: false, error: e.message || "Erro ao registrar comprovante Pix" },
      { status: 500, headers: { "Cache-Control": "no-store, max-age=0" } }
    );
  }
}
