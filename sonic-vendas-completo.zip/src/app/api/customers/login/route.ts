import { db } from "@/db";
import { customers } from "@/db/schema";
import { eq, and } from "drizzle-orm";
import { verifyPassword } from "@/lib/auth";
import { NextResponse } from "next/server";

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const users = await db.select().from(customers).where(and(eq(customers.email, body.email), eq(customers.isActive, true)));
    if (!users.length) {
      return NextResponse.json({ ok: false, error: "Invalid credentials" }, { status: 401, headers: { "Cache-Control": "no-store, max-age=0" } });
    }
    const user = users[0];
    const valid = await verifyPassword(body.password, user.passwordHash);
    if (!valid) {
      return NextResponse.json({ ok: false, error: "Invalid credentials" }, { status: 401, headers: { "Cache-Control": "no-store, max-age=0" } });
    }
    const sessionToken = Buffer.from(JSON.stringify({ userId: user.id, email: user.email, exp: Date.now() + 1000 * 60 * 60 * 24 })).toString("base64url");
    return NextResponse.json({ ok: true, user: { id: user.id, name: user.name, email: user.email }, sessionToken }, { headers: { "Cache-Control": "no-store, max-age=0" } });
  } catch (e: any) {
    return NextResponse.json({ ok: false, error: e.message || "Login failed" }, { status: 500, headers: { "Cache-Control": "no-store, max-age=0" } });
  }
}
