import { db } from "@/db";
import { customers } from "@/db/schema";
import { eq } from "drizzle-orm";
import { hashPassword, verifyPassword } from "@/lib/auth";
import { NextResponse } from "next/server";

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const existing = await db.select().from(customers).where(eq(customers.email, body.email)).limit(1);
    if (existing.length > 0) {
      return NextResponse.json({ ok: false, error: "E-mail já cadastrado." }, { status: 400, headers: { "Cache-Control": "no-store, max-age=0" } });
    }
    const hash = await hashPassword(body.password);
    const inserted = await db.insert(customers).values({
      name: body.name,
      email: body.email,
      phone: body.phone || null,
      passwordHash: hash,
      profileImage: null,
    }).returning();
    return NextResponse.json({ ok: true, data: { id: inserted[0].id, name: inserted[0].name, email: inserted[0].email } }, { headers: { "Cache-Control": "no-store, max-age=0" } });
  } catch (e: any) {
    return NextResponse.json({ ok: false, error: e.message || "Failed to register" }, { status: 500, headers: { "Cache-Control": "no-store, max-age=0" } });
  }
}
