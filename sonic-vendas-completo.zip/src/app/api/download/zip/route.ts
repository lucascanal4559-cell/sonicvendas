import { NextResponse } from "next/server";
import fs from "fs";
import path from "path";

export async function GET() {
  try {
    const filePath = path.join(process.cwd(), "sonic-vendas-completo.zip");

    if (!fs.existsSync(filePath)) {
      return NextResponse.json({ ok: false, error: "Arquivo ZIP não encontrado" }, { status: 404 });
    }

    const fileBuffer = fs.readFileSync(filePath);

    return new Response(fileBuffer, {
      status: 200,
      headers: {
        "Content-Type": "application/zip",
        "Content-Disposition": 'attachment; filename="sonic-vendas-completo.zip"',
        "Content-Length": String(fileBuffer.length),
        "Cache-Control": "no-store, max-age=0",
      },
    });
  } catch (e: any) {
    return NextResponse.json({ ok: false, error: e.message || "Erro ao baixar arquivo" }, { status: 500 });
  }
}
