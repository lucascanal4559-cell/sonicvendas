import { db } from "@/db";
import { adminUsers } from "@/db/schema";
import { hashPassword } from "@/lib/auth";
import { eq } from "drizzle-orm";
import { NextResponse } from "next/server";

export async function POST() {
  try {
    const existing = await db.select().from(adminUsers).where(eq(adminUsers.username, "admin"));
    if (!existing.length) {
      const hash = await hashPassword("sonic2026");
      await db.insert(adminUsers).values({
        username: "admin",
        passwordHash: hash,
        role: "admin",
        isActive: true,
      });
    }
    return NextResponse.json({ ok: true, message: "Admin user ensured" }, { headers: { "Cache-Control": "no-store, max-age=0" } });
  } catch (e) {
    return NextResponse.json({ ok: false, error: "Failed to setup admin" }, { status: 500, headers: { "Cache-Control": "no-store, max-age=0" } });
  }
}
