import { db } from "@/db";
import { adBoostOrders, contactAds, businessAds, notifications } from "@/db/schema";
import { eq } from "drizzle-orm";
import { NextResponse } from "next/server";

function requireAuth(req: Request) {
  const authHeader = req.headers.get("authorization") || "";
  const token = authHeader.replace("Bearer ", "");
  if (!token) throw new Error("Not authenticated");
  try {
    const payload = JSON.parse(Buffer.from(token, "base64url").toString());
    if (payload.exp && Date.now() > payload.exp) throw new Error("Session expired");
    return payload;
  } catch {
    throw new Error("Invalid token");
  }
}

export async function PUT(req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    requireAuth(req);
    const { id } = await params;
    const boostId = parseInt(id, 10);
    const body = await req.json();

    const existing = await db.select().from(adBoostOrders).where(eq(adBoostOrders.id, boostId)).limit(1);
    if (!existing.length) {
      return NextResponse.json({ ok: false, error: "Pedido de impulsionamento não encontrado" }, { status: 404 });
    }

    const current = existing[0];
    const action = body.action || (body.status === "approved" ? "approve" : "reject");
    const status = action === "approve" ? "approved" : "rejected";

    const updated = await db
      .update(adBoostOrders)
      .set({
        status,
        updatedAt: new Date(),
      })
      .where(eq(adBoostOrders.id, boostId))
      .returning();

    // If approved, activate boost on target ad
    if (action === "approve") {
      const expiresAt = new Date(Date.now() + (current.days || 7) * 24 * 60 * 60 * 1000);
      if (current.adType === "contact") {
        await db
          .update(contactAds)
          .set({ isBoosted: true, boostExpiresAt: expiresAt, updatedAt: new Date() })
          .where(eq(contactAds.id, current.adId));
      } else {
        await db
          .update(businessAds)
          .set({
            isBoosted: true,
            boostPlan: current.planName,
            boostExpiresAt: expiresAt,
            updatedAt: new Date(),
          })
          .where(eq(businessAds.id, current.adId));
      }

      try {
        await db.insert(notifications).values({
          title: `⚡ Impulsionamento Ativado para ${current.customerName}`,
          message: `O anúncio foi impulsionado com sucesso no plano "${current.planName}" por ${current.days} dias!`,
          isActive: true,
        });
      } catch {}
    }

    return NextResponse.json({ ok: true, data: updated[0] }, { headers: { "Cache-Control": "no-store, max-age=0" } });
  } catch (e: any) {
    return NextResponse.json({ ok: false, error: e.message || "Failed" }, { status: 401 });
  }
}
