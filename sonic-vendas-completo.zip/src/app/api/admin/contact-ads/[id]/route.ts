import { db } from "@/db";
import { contactAds, notifications } from "@/db/schema";
import { eq } from "drizzle-orm";
import { NextResponse } from "next/server";

function requireAuth(req: Request) {
  const authHeader = req.headers.get("authorization") || "";
  const token = authHeader.replace("Bearer ", "");
  if (!token) throw new Error("Not authenticated");
  try {
    const payload = JSON.parse(Buffer.from(token, "base64url").toString());
    if (payload.exp && Date.now() > payload.exp) throw new Error("Session expired");
    return payload;
  } catch {
    throw new Error("Invalid token");
  }
}

export async function PUT(req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    requireAuth(req);
    const { id } = await params;
    const body = await req.json();
    const adId = parseInt(id, 10);

    const existing = await db.select().from(contactAds).where(eq(contactAds.id, adId)).limit(1);
    if (!existing.length) {
      return NextResponse.json({ ok: false, error: "Anúncio não encontrado" }, { status: 404 });
    }

    const current = existing[0];
    const status = body.status || current.status;
    let startDate = current.startDate;
    let endDate = current.endDate;

    if (body.action === "approve" || status === "approved") {
      startDate = new Date();
      endDate = new Date(startDate.getTime() + (current.days || 7) * 24 * 60 * 60 * 1000);
      try {
        await db.insert(notifications).values({
          title: `✅ Divulgação Aprovada: ${current.name}`,
          message: `Sua divulgação de contato foi aprovada e já está no ar por ${current.days} dias!`,
          isActive: true,
        });
      } catch {}
    }

    const updated = await db
      .update(contactAds)
      .set({
        name: body.name !== undefined ? body.name : current.name,
        age: body.age !== undefined ? body.age : current.age,
        description: body.description !== undefined ? body.description : current.description,
        profilePhoto: body.profilePhoto !== undefined ? body.profilePhoto : current.profilePhoto,
        videoUrl: body.videoUrl !== undefined ? body.videoUrl : current.videoUrl,
        phone: body.phone !== undefined ? body.phone : current.phone,
        email: body.email !== undefined ? body.email : current.email,
        contactLink: body.contactLink !== undefined ? body.contactLink : current.contactLink,
        city: body.city !== undefined ? body.city : current.city,
        status,
        isBoosted: body.isBoosted !== undefined ? body.isBoosted : current.isBoosted,
        isActive: body.isActive !== undefined ? body.isActive : current.isActive,
        startDate,
        endDate,
        updatedAt: new Date(),
      })
      .where(eq(contactAds.id, adId))
      .returning();

    return NextResponse.json({ ok: true, data: updated[0] }, { headers: { "Cache-Control": "no-store, max-age=0" } });
  } catch (e: any) {
    return NextResponse.json({ ok: false, error: e.message || "Failed" }, { status: 401 });
  }
}

export async function DELETE(req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    requireAuth(req);
    const { id } = await params;
    await db.delete(contactAds).where(eq(contactAds.id, parseInt(id, 10)));
    return NextResponse.json({ ok: true, message: "Excluído com sucesso" }, { headers: { "Cache-Control": "no-store, max-age=0" } });
  } catch (e: any) {
    return NextResponse.json({ ok: false, error: e.message || "Failed" }, { status: 401 });
  }
}
