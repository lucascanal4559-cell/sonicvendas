import { db } from "@/db";
import { banners } from "@/db/schema";
import { eq } from "drizzle-orm";
import { NextResponse } from "next/server";

function requireAuth(req: Request) {
  const authHeader = req.headers.get("authorization") || "";
  const token = authHeader.replace("Bearer ", "");
  if (!token) throw new Error("Not authenticated");
  try {
    const payload = JSON.parse(Buffer.from(token, "base64url").toString());
    if (payload.exp && Date.now() > payload.exp) throw new Error("Session expired");
    return payload;
  } catch {
    throw new Error("Invalid token");
  }
}

export async function POST(req: Request) {
  try {
    requireAuth(req);
    const body = await req.json();
    const inserted = await db.insert(banners).values({
      title: body.title,
      subtitle: body.subtitle || null,
      imageUrl: body.imageUrl,
      linkUrl: body.linkUrl || null,
      isActive: body.isActive !== undefined ? body.isActive : true,
      order: body.order || 0,
    }).returning();
    return NextResponse.json({ ok: true, data: inserted[0] }, { headers: { "Cache-Control": "no-store, max-age=0" } });
  } catch (e: any) {
    return NextResponse.json({ ok: false, error: e.message || "Failed to create banner" }, { status: 401 });
  }
}

export async function PUT(req: Request) {
  try {
    requireAuth(req);
    const body = await req.json();
    if (!body.id) return NextResponse.json({ ok: false, error: "ID required" }, { status: 400, headers: { "Cache-Control": "no-store, max-age=0" } });
    const updated = await db.update(banners).set({
      title: body.title,
      subtitle: body.subtitle,
      imageUrl: body.imageUrl,
      linkUrl: body.linkUrl,
      isActive: body.isActive,
      order: body.order,
      updatedAt: new Date(),
    }).where(eq(banners.id, body.id)).returning();
    return NextResponse.json({ ok: true, data: updated[0] }, { headers: { "Cache-Control": "no-store, max-age=0" } });
  } catch (e: any) {
    return NextResponse.json({ ok: false, error: e.message || "Failed to update banner" }, { status: 401 });
  }
}

export async function DELETE(req: Request) {
  try {
    requireAuth(req);
    const body = await req.json();
    if (!body.id) return NextResponse.json({ ok: false, error: "ID required" }, { status: 400, headers: { "Cache-Control": "no-store, max-age=0" } });
    await db.delete(banners).where(eq(banners.id, body.id));
    return NextResponse.json({ ok: true, message: "Deleted" }, { headers: { "Cache-Control": "no-store, max-age=0" } });
  } catch (e: any) {
    return NextResponse.json({ ok: false, error: e.message || "Failed to delete banner" }, { status: 401 });
  }
}
