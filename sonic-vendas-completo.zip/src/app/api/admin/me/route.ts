import { NextResponse } from "next/server";

export async function GET(req: Request) {
  try {
    const authHeader = req.headers.get("authorization") || "";
    const token = authHeader.replace("Bearer ", "");
    if (!token) {
      return NextResponse.json({ ok: false, error: "Not authenticated" }, { status: 401, headers: { "Cache-Control": "no-store, max-age=0" } });
    }
    try {
      const payload = JSON.parse(Buffer.from(token, "base64url").toString());
      if (payload.exp && Date.now() > payload.exp) {
        return NextResponse.json({ ok: false, error: "Session expired" }, { status: 401, headers: { "Cache-Control": "no-store, max-age=0" } });
      }
      return NextResponse.json({ ok: true, user: { id: payload.userId, username: payload.username, role: payload.role } }, { headers: { "Cache-Control": "no-store, max-age=0" } });
    } catch {
      return NextResponse.json({ ok: false, error: "Invalid token" }, { status: 401, headers: { "Cache-Control": "no-store, max-age=0" } });
    }
  } catch (e) {
    return NextResponse.json({ ok: false, error: "Failed" }, { status: 500, headers: { "Cache-Control": "no-store, max-age=0" } });
  }
}
