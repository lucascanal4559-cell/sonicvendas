import { db } from "@/db";
import { adminUsers } from "@/db/schema";
import { eq, and } from "drizzle-orm";
import { verifyPassword } from "@/lib/auth";
import { NextResponse } from "next/server";

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { username, password } = body || {};

    if (!username || !password) {
      return NextResponse.json({ ok: false, error: "Username and password required" }, { status: 400 });
    }

    const users = await db.select().from(adminUsers).where(and(eq(adminUsers.username, username), eq(adminUsers.isActive, true)));
    if (!users.length) {
      return NextResponse.json({ ok: false, error: "Invalid credentials" }, { status: 401 });
    }

    const user = users[0];
    const valid = await verifyPassword(password, user.passwordHash);
    if (!valid) {
      return NextResponse.json({ ok: false, error: "Invalid credentials" }, { status: 401 });
    }

    // Return a session token (simple JWT-like token for demo; in production use real JWT library)
    const sessionToken = Buffer.from(JSON.stringify({ userId: user.id, username: user.username, role: user.role, exp: Date.now() + 1000 * 60 * 60 * 24 })).toString("base64url");

    return NextResponse.json({ ok: true, user: { id: user.id, username: user.username, role: user.role }, sessionToken }, { headers: { "Cache-Control": "no-store, max-age=0" } });
  } catch (e) {
    return NextResponse.json({ ok: false, error: "Login failed" }, { status: 500 });
  }
}
