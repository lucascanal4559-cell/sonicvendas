import { db } from "@/db";
import { contactAds, businessAds, orders, socialOrders, raffles, iptvRequests } from "@/db/schema";
import { sql } from "drizzle-orm";
import { NextResponse } from "next/server";

export async function GET() {
  try {
    const [cAds, bAds, allOrders, sOrders, allRaffles, iptvs] = await Promise.all([
      db.select().from(contactAds),
      db.select().from(businessAds),
      db.select().from(orders),
      db.select().from(socialOrders),
      db.select().from(raffles),
      db.select().from(iptvRequests),
    ]);

    const totalContactViews = cAds.reduce((acc, a) => acc + (a.viewsCount || 0), 0);
    const totalContactWhatsapp = cAds.reduce((acc, a) => acc + (a.clicksWhatsapp || 0), 0);
    const totalBusinessViews = bAds.reduce((acc, a) => acc + (a.viewsCount || 0), 0);
    const totalBusinessWhatsapp = bAds.reduce((acc, a) => acc + (a.clicksWhatsapp || 0), 0);
    const totalBusinessBuy = bAds.reduce((acc, a) => acc + (a.clicksBuy || 0), 0);

    const totalOrdersRevenue = allOrders
      .filter((o) => o.isPaid || o.status === "approved")
      .reduce((acc, o) => acc + parseFloat(String(o.totalAmount || 0)), 0);

    const totalSocialRevenue = sOrders
      .filter((o) => o.status === "approved" || o.status === "completed")
      .reduce((acc, o) => acc + parseFloat(String(o.totalAmount || 0)), 0);

    return NextResponse.json(
      {
        ok: true,
        data: {
          contacts: {
            total: cAds.length,
            views: totalContactViews,
            whatsappClicks: totalContactWhatsapp,
          },
          business: {
            total: bAds.length,
            views: totalBusinessViews,
            whatsappClicks: totalBusinessWhatsapp,
            buyClicks: totalBusinessBuy,
          },
          general: {
            totalOrders: allOrders.length,
            ordersRevenue: totalOrdersRevenue.toFixed(2),
            socialOrders: sOrders.length,
            socialRevenue: totalSocialRevenue.toFixed(2),
            activeRaffles: allRaffles.filter((r) => r.status === "open").length,
            iptvRequests: iptvs.length,
          },
        },
      },
      { headers: { "Cache-Control": "no-store, max-age=0" } }
    );
  } catch (e: any) {
    return NextResponse.json({ ok: false, error: e.message || "Failed" }, { status: 500 });
  }
}
