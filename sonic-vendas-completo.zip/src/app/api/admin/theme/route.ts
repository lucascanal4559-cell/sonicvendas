import { db } from "@/db";
import { siteConfig } from "@/db/schema";
import { eq } from "drizzle-orm";
import { NextResponse } from "next/server";

function requireAuth(req: Request) {
  const authHeader = req.headers.get("authorization") || "";
  const token = authHeader.replace("Bearer ", "");
  if (!token) throw new Error("Not authenticated");
  try {
    const payload = JSON.parse(Buffer.from(token, "base64url").toString());
    if (payload.exp && Date.now() > payload.exp) throw new Error("Session expired");
    return payload;
  } catch {
    throw new Error("Invalid token");
  }
}

export async function POST(req: Request) {
  try {
    requireAuth(req);
    const body = await req.json(); // key-value map

    for (const [key, val] of Object.entries(body)) {
      if (val === undefined || val === null) continue;
      const strVal = String(val);

      const existing = await db.select().from(siteConfig).where(eq(siteConfig.key, key));
      if (existing.length > 0) {
        await db
          .update(siteConfig)
          .set({ value: strVal, updatedAt: new Date() })
          .where(eq(siteConfig.key, key));
      } else {
        await db.insert(siteConfig).values({
          key,
          value: strVal,
        });
      }
    }

    return NextResponse.json({ ok: true, message: "Configurações de tema, sons e avisos salvas com sucesso!" }, { headers: { "Cache-Control": "no-store, max-age=0" } });
  } catch (e: any) {
    return NextResponse.json({ ok: false, error: e.message || "Failed" }, { status: 401 });
  }
}
