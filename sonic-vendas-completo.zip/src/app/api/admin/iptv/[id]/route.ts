import { db } from "@/db";
import { iptvRequests, notifications } from "@/db/schema";
import { eq } from "drizzle-orm";
import { NextResponse } from "next/server";

function requireAuth(req: Request) {
  const authHeader = req.headers.get("authorization") || "";
  const token = authHeader.replace("Bearer ", "");
  if (!token) throw new Error("Not authenticated");
  try {
    const payload = JSON.parse(Buffer.from(token, "base64url").toString());
    if (payload.exp && Date.now() > payload.exp) throw new Error("Session expired");
    return payload;
  } catch {
    throw new Error("Invalid token");
  }
}

export async function PUT(req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    requireAuth(req);
    const { id } = await params;
    const body = await req.json();
    const requestId = parseInt(id, 10);

    const existing = await db.select().from(iptvRequests).where(eq(iptvRequests.id, requestId));
    if (!existing.length) {
      return NextResponse.json({ ok: false, error: "Solicitação não encontrada" }, { status: 404 });
    }

    const current = existing[0];
    const now = new Date();
    const hours = body.hours !== undefined ? parseInt(String(body.hours), 10) : (current.hours || 12);

    let approvedAt = current.approvedAt;
    let expiresAt = current.expiresAt;
    let status = body.status || current.status;

    // Action handling
    if (body.action === "approve" || body.status === "approved") {
      status = "approved";
      approvedAt = new Date();
      expiresAt = new Date(approvedAt.getTime() + hours * 60 * 60 * 1000);

      // Notification
      try {
        await db.insert(notifications).values({
          title: `✅ IPTV Liberado para ${current.customerName}`,
          message: `O acesso IPTV de 12 horas foi liberado para ${current.customerEmail}. Expira em ${expiresAt.toLocaleString("pt-BR")}.`,
          isActive: true,
        });
      } catch {}
    } else if (body.action === "revoke" || body.status === "revoked") {
      status = "revoked";
    } else if (body.action === "expire" || body.status === "expired") {
      status = "expired";
    } else if (body.action === "extend") {
      const extraHours = parseInt(String(body.extraHours || 12), 10);
      status = "approved";
      const baseTime = current.expiresAt && new Date(current.expiresAt) > now ? new Date(current.expiresAt) : now;
      expiresAt = new Date(baseTime.getTime() + extraHours * 60 * 60 * 1000);
    }

    const updated = await db
      .update(iptvRequests)
      .set({
        status,
        hours,
        serverUrl: body.serverUrl !== undefined ? body.serverUrl : current.serverUrl,
        username: body.username !== undefined ? body.username : current.username,
        password: body.password !== undefined ? body.password : current.password,
        m3uUrl: body.m3uUrl !== undefined ? body.m3uUrl : current.m3uUrl,
        instructions: body.instructions !== undefined ? body.instructions : current.instructions,
        adminNotes: body.adminNotes !== undefined ? body.adminNotes : current.adminNotes,
        approvedAt,
        expiresAt,
        updatedAt: new Date(),
      })
      .where(eq(iptvRequests.id, requestId))
      .returning();

    return NextResponse.json({ ok: true, data: updated[0] }, { headers: { "Cache-Control": "no-store, max-age=0" } });
  } catch (e: any) {
    return NextResponse.json({ ok: false, error: e.message || "Failed to update IPTV request" }, { status: 401 });
  }
}

export async function DELETE(req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    requireAuth(req);
    const { id } = await params;
    await db.delete(iptvRequests).where(eq(iptvRequests.id, parseInt(id, 10)));
    return NextResponse.json({ ok: true, message: "Excluído com sucesso" }, { headers: { "Cache-Control": "no-store, max-age=0" } });
  } catch (e: any) {
    return NextResponse.json({ ok: false, error: e.message || "Failed to delete" }, { status: 401 });
  }
}
