import { db } from "@/db";
import { categories, banners } from "@/db/schema";
import { eq } from "drizzle-orm";
import { NextResponse } from "next/server";

function requireAuth(req: Request) {
  const authHeader = req.headers.get("authorization") || "";
  const token = authHeader.replace("Bearer ", "");
  if (!token) throw new Error("Not authenticated");
  try {
    const payload = JSON.parse(Buffer.from(token, "base64url").toString());
    if (payload.exp && Date.now() > payload.exp) throw new Error("Session expired");
    return payload;
  } catch {
    throw new Error("Invalid token");
  }
}

export async function POST(req: Request) {
  try {
    requireAuth(req);
    const body = await req.json();
    const inserted = await db.insert(categories).values({
      name: body.name,
      slug: body.slug || body.name.toLowerCase().replace(/\s+/g, "-").replace(/[^a-z0-9-]/g, ""),
      description: body.description || null,
      isActive: body.isActive !== undefined ? body.isActive : true,
    }).returning();
    return NextResponse.json({ ok: true, data: inserted[0] }, { headers: { "Cache-Control": "no-store, max-age=0" } });
  } catch (e: any) {
    return NextResponse.json({ ok: false, error: e.message || "Failed to create category" }, { status: 401 });
  }
}

export async function PUT(req: Request) {
  try {
    requireAuth(req);
    const body = await req.json();
    if (!body.id) return NextResponse.json({ ok: false, error: "ID required" }, { status: 400, headers: { "Cache-Control": "no-store, max-age=0" } });
    const updated = await db.update(categories).set({
      name: body.name,
      slug: body.slug,
      description: body.description,
      isActive: body.isActive,
      updatedAt: new Date(),
    }).where(eq(categories.id, body.id)).returning();
    return NextResponse.json({ ok: true, data: updated[0] }, { headers: { "Cache-Control": "no-store, max-age=0" } });
  } catch (e: any) {
    return NextResponse.json({ ok: false, error: e.message || "Failed to update category" }, { status: 401 });
  }
}

export async function DELETE(req: Request) {
  try {
    requireAuth(req);
    const body = await req.json();
    if (!body.id) return NextResponse.json({ ok: false, error: "ID required" }, { status: 400, headers: { "Cache-Control": "no-store, max-age=0" } });
    await db.delete(categories).where(eq(categories.id, body.id));
    return NextResponse.json({ ok: true, message: "Deleted" }, { headers: { "Cache-Control": "no-store, max-age=0" } });
  } catch (e: any) {
    return NextResponse.json({ ok: false, error: e.message || "Failed to delete category" }, { status: 401 });
  }
}
