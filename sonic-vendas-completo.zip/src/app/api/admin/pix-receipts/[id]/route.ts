import { db } from "@/db";
import { pixReceipts, orders, notifications } from "@/db/schema";
import { eq } from "drizzle-orm";
import { NextResponse } from "next/server";

function requireAuth(req: Request) {
  const authHeader = req.headers.get("authorization") || "";
  const token = authHeader.replace("Bearer ", "");
  if (!token) throw new Error("Not authenticated");
  try {
    const payload = JSON.parse(Buffer.from(token, "base64url").toString());
    if (payload.exp && Date.now() > payload.exp) throw new Error("Session expired");
    return payload;
  } catch {
    throw new Error("Invalid token");
  }
}

export async function PUT(req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const user = requireAuth(req);
    const { id } = await params;
    const receiptId = parseInt(id, 10);
    const body = await req.json();
    const action = body.action || (body.status === "approved" ? "approve" : "reject");

    const found = await db.select().from(pixReceipts).where(eq(pixReceipts.id, receiptId)).limit(1);
    if (!found.length) {
      return NextResponse.json({ ok: false, error: "Comprovante não encontrado" }, { status: 404 });
    }

    const current = found[0];
    const isApproved = action === "approve";
    const status = isApproved ? "approved" : "rejected";
    const rejectionReason = body.rejectionReason || (isApproved ? null : "Comprovante não confere com os valores do pedido.");

    const updated = await db
      .update(pixReceipts)
      .set({
        status,
        rejectionReason,
        reviewedBy: user.username || "admin",
        reviewedAt: new Date(),
        updatedAt: new Date(),
      })
      .where(eq(pixReceipts.id, receiptId))
      .returning();

    // If there is an associated order, update it
    if (current.orderId) {
      try {
        await db
          .update(orders)
          .set({
            isPaid: isApproved,
            status: isApproved ? "approved" : "rejected",
            updatedAt: new Date(),
          })
          .where(eq(orders.id, current.orderId));
      } catch {}
    }

    // Add notification
    try {
      await db.insert(notifications).values({
        title: isApproved ? `✅ Pix Aprovado (R$ ${current.amount})` : `❌ Pix Rejeitado (R$ ${current.amount})`,
        message: isApproved
          ? `O comprovante de ${current.customerName} foi aprovado com sucesso.${current.orderId ? ` Pedido #${current.orderId} liberado.` : ""}`
          : `O comprovante de ${current.customerName} foi recusado. Motivo: ${rejectionReason}`,
        isActive: true,
      });
    } catch {}

    return NextResponse.json(
      {
        ok: true,
        message: isApproved ? "Comprovante Pix Aprovado e Pedido Liberado!" : "Comprovante Rejeitado com sucesso.",
        data: updated[0],
      },
      { headers: { "Cache-Control": "no-store, max-age=0" } }
    );
  } catch (e: any) {
    return NextResponse.json({ ok: false, error: e.message || "Failed" }, { status: 401 });
  }
}

export async function DELETE(req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    requireAuth(req);
    const { id } = await params;
    await db.delete(pixReceipts).where(eq(pixReceipts.id, parseInt(id, 10)));
    return NextResponse.json({ ok: true, message: "Comprovante excluído" }, { headers: { "Cache-Control": "no-store, max-age=0" } });
  } catch (e: any) {
    return NextResponse.json({ ok: false, error: e.message || "Failed" }, { status: 401 });
  }
}
