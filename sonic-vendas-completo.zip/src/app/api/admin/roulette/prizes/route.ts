import { db } from "@/db";
import { roulettePrizes } from "@/db/schema";
import { desc } from "drizzle-orm";
import { NextResponse } from "next/server";

function requireAuth(req: Request) {
  const authHeader = req.headers.get("authorization") || "";
  const token = authHeader.replace("Bearer ", "");
  if (!token) throw new Error("Not authenticated");
  try {
    const payload = JSON.parse(Buffer.from(token, "base64url").toString());
    if (payload.exp && Date.now() > payload.exp) throw new Error("Session expired");
    return payload;
  } catch {
    throw new Error("Invalid token");
  }
}

export async function GET(req: Request) {
  try {
    requireAuth(req);
    const data = await db.select().from(roulettePrizes).orderBy(desc(roulettePrizes.id));
    return NextResponse.json({ ok: true, data }, { headers: { "Cache-Control": "no-store, max-age=0" } });
  } catch (e: any) {
    return NextResponse.json({ ok: false, error: e.message || "Failed" }, { status: 401 });
  }
}

export async function POST(req: Request) {
  try {
    requireAuth(req);
    const body = await req.json();

    if (!body.title || !body.value) {
      return NextResponse.json({ ok: false, error: "Título e valor são obrigatórios." }, { status: 400 });
    }

    const inserted = await db
      .insert(roulettePrizes)
      .values({
        title: body.title,
        prizeType: body.prizeType || "discount_coupon",
        value: body.value,
        couponCode: body.couponCode || null,
        probability: parseInt(String(body.probability || 10), 10),
        color: body.color || "#06b6d4",
        isActive: body.isActive !== undefined ? body.isActive : true,
      })
      .returning();

    return NextResponse.json({ ok: true, data: inserted[0] }, { headers: { "Cache-Control": "no-store, max-age=0" } });
  } catch (e: any) {
    return NextResponse.json({ ok: false, error: e.message || "Failed" }, { status: 401 });
  }
}
