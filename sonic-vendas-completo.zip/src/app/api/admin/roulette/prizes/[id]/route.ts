import { db } from "@/db";
import { roulettePrizes } from "@/db/schema";
import { eq } from "drizzle-orm";
import { NextResponse } from "next/server";

function requireAuth(req: Request) {
  const authHeader = req.headers.get("authorization") || "";
  const token = authHeader.replace("Bearer ", "");
  if (!token) throw new Error("Not authenticated");
  try {
    const payload = JSON.parse(Buffer.from(token, "base64url").toString());
    if (payload.exp && Date.now() > payload.exp) throw new Error("Session expired");
    return payload;
  } catch {
    throw new Error("Invalid token");
  }
}

export async function PUT(req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    requireAuth(req);
    const { id } = await params;
    const body = await req.json();

    const updated = await db
      .update(roulettePrizes)
      .set({
        title: body.title,
        prizeType: body.prizeType,
        value: body.value,
        couponCode: body.couponCode,
        probability: body.probability !== undefined ? parseInt(String(body.probability), 10) : undefined,
        color: body.color,
        isActive: body.isActive,
      })
      .where(eq(roulettePrizes.id, parseInt(id, 10)))
      .returning();

    return NextResponse.json({ ok: true, data: updated[0] }, { headers: { "Cache-Control": "no-store, max-age=0" } });
  } catch (e: any) {
    return NextResponse.json({ ok: false, error: e.message || "Failed" }, { status: 401 });
  }
}

export async function DELETE(req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    requireAuth(req);
    const { id } = await params;
    await db.delete(roulettePrizes).where(eq(roulettePrizes.id, parseInt(id, 10)));
    return NextResponse.json({ ok: true, message: "Prêmio excluído com sucesso" }, { headers: { "Cache-Control": "no-store, max-age=0" } });
  } catch (e: any) {
    return NextResponse.json({ ok: false, error: e.message || "Failed" }, { status: 401 });
  }
}
