import { db } from "@/db";
import { raffles, raffleTickets, notifications } from "@/db/schema";
import { eq, and } from "drizzle-orm";
import { NextResponse } from "next/server";

function requireAuth(req: Request) {
  const authHeader = req.headers.get("authorization") || "";
  const token = authHeader.replace("Bearer ", "");
  if (!token) throw new Error("Not authenticated");
  try {
    const payload = JSON.parse(Buffer.from(token, "base64url").toString());
    if (payload.exp && Date.now() > payload.exp) throw new Error("Session expired");
    return payload;
  } catch {
    throw new Error("Invalid token");
  }
}

export async function PUT(req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const user = requireAuth(req);
    const { id } = await params;
    const raffleId = parseInt(id, 10);
    const body = await req.json();

    const existingList = await db.select().from(raffles).where(eq(raffles.id, raffleId)).limit(1);
    if (!existingList.length) {
      return NextResponse.json({ ok: false, error: "Sorteio não encontrado" }, { status: 404 });
    }

    const current = existingList[0];

    // If revealing a winner
    let winnerCode = body.winnerCode !== undefined ? body.winnerCode : current.winnerCode;
    let winnerName = body.winnerName !== undefined ? body.winnerName : current.winnerName;
    let winnerPhoneMasked = body.winnerPhoneMasked !== undefined ? body.winnerPhoneMasked : current.winnerPhoneMasked;
    let status = body.status !== undefined ? body.status : current.status;
    let revealedBy = current.revealedBy;
    let revealedAt = current.revealedAt;

    if (body.action === "reveal_winner" || (body.winnerCode && body.status === "drawn")) {
      status = "drawn";
      revealedBy = user.username || "admin";
      revealedAt = new Date();

      // Look up ticket owner if code provided
      if (winnerCode) {
        const ticketOwner = await db
          .select()
          .from(raffleTickets)
          .where(and(eq(raffleTickets.raffleId, raffleId), eq(raffleTickets.ticketCode, String(winnerCode).trim())))
          .limit(1);

        if (ticketOwner.length > 0) {
          const t = ticketOwner[0];
          winnerName = t.customerName;
          const phone = t.customerPhone || "";
          winnerPhoneMasked = phone.length > 6 ? `${phone.slice(0, 4)}****${phone.slice(-2)}` : phone;

          // Mark winning ticket
          await db
            .update(raffleTickets)
            .set({ isWinner: true })
            .where(eq(raffleTickets.id, t.id));
        } else {
          winnerName = body.winnerName || "Sem ganhador nesta extração";
        }
      }

      // Add system notification
      try {
        await db.insert(notifications).values({
          title: `🏆 Resultado Revelado: ${current.title}`,
          message: `Código vencedor: ${winnerCode} • Ganhador: ${winnerName} • Concurso Loteria: ${body.lotteryContestNumber || current.lotteryContestNumber || "N/A"}.`,
          isActive: true,
        });
      } catch {}
    }

    const updated = await db
      .update(raffles)
      .set({
        title: body.title !== undefined ? body.title : current.title,
        description: body.description !== undefined ? body.description : current.description,
        imageUrl: body.imageUrl !== undefined ? body.imageUrl : current.imageUrl,
        category: body.category !== undefined ? body.category : current.category,
        totalNumbers: body.totalNumbers !== undefined ? parseInt(String(body.totalNumbers), 10) : current.totalNumbers,
        pricePerNumber: body.pricePerNumber !== undefined ? body.pricePerNumber : current.pricePerNumber,
        drawDate: body.drawDate ? new Date(body.drawDate) : current.drawDate,
        regulation: body.regulation !== undefined ? body.regulation : current.regulation,
        instagramLiveUrl: body.instagramLiveUrl !== undefined ? body.instagramLiveUrl : current.instagramLiveUrl,
        drawMethod: body.drawMethod !== undefined ? body.drawMethod : current.drawMethod,
        lotteryContestNumber: body.lotteryContestNumber !== undefined ? body.lotteryContestNumber : current.lotteryContestNumber,
        lotteryDrawnNumbers: body.lotteryDrawnNumbers !== undefined ? body.lotteryDrawnNumbers : current.lotteryDrawnNumbers,
        status,
        winnerCode,
        winnerName,
        winnerPhoneMasked,
        isFeatured: body.isFeatured !== undefined ? body.isFeatured : current.isFeatured,
        isActive: body.isActive !== undefined ? body.isActive : current.isActive,
        revealedBy,
        revealedAt,
        updatedAt: new Date(),
      })
      .where(eq(raffles.id, raffleId))
      .returning();

    return NextResponse.json({ ok: true, data: updated[0] }, { headers: { "Cache-Control": "no-store, max-age=0" } });
  } catch (e: any) {
    return NextResponse.json({ ok: false, error: e.message || "Failed to update raffle" }, { status: 401 });
  }
}

export async function DELETE(req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    requireAuth(req);
    const { id } = await params;
    await db.delete(raffles).where(eq(raffles.id, parseInt(id, 10)));
    return NextResponse.json({ ok: true, message: "Sorteio excluído com sucesso." }, { headers: { "Cache-Control": "no-store, max-age=0" } });
  } catch (e: any) {
    return NextResponse.json({ ok: false, error: e.message || "Failed to delete" }, { status: 401 });
  }
}
