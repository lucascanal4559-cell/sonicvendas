import { db } from "@/db";
import { raffleTickets, raffleParticipations, raffles } from "@/db/schema";
import { eq, desc } from "drizzle-orm";
import { NextResponse } from "next/server";

function requireAuth(req: Request) {
  const authHeader = req.headers.get("authorization") || "";
  const token = authHeader.replace("Bearer ", "");
  if (!token) throw new Error("Not authenticated");
  try {
    const payload = JSON.parse(Buffer.from(token, "base64url").toString());
    if (payload.exp && Date.now() > payload.exp) throw new Error("Session expired");
    return payload;
  } catch {
    throw new Error("Invalid token");
  }
}

export async function GET(req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    requireAuth(req);
    const { id } = await params;
    const raffleId = parseInt(id, 10);

    const raffleInfo = await db.select().from(raffles).where(eq(raffles.id, raffleId)).limit(1);
    if (!raffleInfo.length) {
      return NextResponse.json({ ok: false, error: "Sorteio não encontrado" }, { status: 404 });
    }

    const tickets = await db
      .select({
        id: raffleTickets.id,
        ticketNumber: raffleTickets.ticketNumber,
        ticketCode: raffleTickets.ticketCode,
        customerName: raffleTickets.customerName,
        customerEmail: raffleTickets.customerEmail,
        customerPhone: raffleTickets.customerPhone,
        isWinner: raffleTickets.isWinner,
        createdAt: raffleTickets.createdAt,
      })
      .from(raffleTickets)
      .where(eq(raffleTickets.raffleId, raffleId))
      .orderBy(raffleTickets.ticketNumber);

    const participations = await db
      .select()
      .from(raffleParticipations)
      .where(eq(raffleParticipations.raffleId, raffleId))
      .orderBy(desc(raffleParticipations.createdAt));

    return NextResponse.json(
      {
        ok: true,
        raffle: raffleInfo[0],
        totalTickets: tickets.length,
        tickets,
        participations,
      },
      { headers: { "Cache-Control": "no-store, max-age=0" } }
    );
  } catch (e: any) {
    return NextResponse.json({ ok: false, error: e.message || "Failed" }, { status: 401 });
  }
}
