import { db } from "@/db";
import { raffles } from "@/db/schema";
import { desc, eq } from "drizzle-orm";
import { NextResponse } from "next/server";

function requireAuth(req: Request) {
  const authHeader = req.headers.get("authorization") || "";
  const token = authHeader.replace("Bearer ", "");
  if (!token) throw new Error("Not authenticated");
  try {
    const payload = JSON.parse(Buffer.from(token, "base64url").toString());
    if (payload.exp && Date.now() > payload.exp) throw new Error("Session expired");
    return payload;
  } catch {
    throw new Error("Invalid token");
  }
}

export async function GET(req: Request) {
  try {
    requireAuth(req);
    const data = await db.select().from(raffles).orderBy(desc(raffles.createdAt));
    return NextResponse.json({ ok: true, data }, { headers: { "Cache-Control": "no-store, max-age=0" } });
  } catch (e: any) {
    return NextResponse.json({ ok: false, error: e.message || "Failed" }, { status: 401 });
  }
}

export async function POST(req: Request) {
  try {
    const user = requireAuth(req);
    const body = await req.json();

    const title = body.title;
    if (!title) {
      return NextResponse.json({ ok: false, error: "Título do sorteio é obrigatório." }, { status: 400 });
    }

    const slug = body.slug || title.toLowerCase().replace(/\s+/g, "-").replace(/[^a-z0-9-]/g, "") + `-${Date.now()}`;
    const totalNumbers = parseInt(String(body.totalNumbers || 1000), 10);
    const pricePerNumber = body.pricePerNumber || "0.10";

    const inserted = await db
      .insert(raffles)
      .values({
        title,
        slug,
        description: body.description || "Participe deste grande sorteio!",
        imageUrl: body.imageUrl || "https://images.unsplash.com/photo-1695048133142-1a20484d2569?w=800&q=80",
        category: body.category || "celular",
        totalNumbers,
        pricePerNumber,
        numbersSold: 0,
        startDate: body.startDate ? new Date(body.startDate) : new Date(),
        endDate: body.endDate ? new Date(body.endDate) : null,
        drawDate: body.drawDate ? new Date(body.drawDate) : null,
        regulation: body.regulation || "Sorteio baseado na apuração oficial da Loteria Federal.",
        instagramLiveUrl: body.instagramLiveUrl || "https://instagram.com/sonicvendas",
        drawMethod: body.drawMethod || "loteria_federal",
        lotteryContestNumber: body.lotteryContestNumber || null,
        status: body.status || "open",
        isFeatured: body.isFeatured !== undefined ? body.isFeatured : true,
        isActive: body.isActive !== undefined ? body.isActive : true,
      })
      .returning();

    return NextResponse.json({ ok: true, data: inserted[0] }, { headers: { "Cache-Control": "no-store, max-age=0" } });
  } catch (e: any) {
    return NextResponse.json({ ok: false, error: e.message || "Failed to create raffle" }, { status: 401 });
  }
}
