import { db } from "@/db";
import { siteAnnouncements } from "@/db/schema";
import { eq } from "drizzle-orm";
import { NextResponse } from "next/server";

function requireAuth(req: Request) {
  const authHeader = req.headers.get("authorization") || "";
  const token = authHeader.replace("Bearer ", "");
  if (!token) throw new Error("Not authenticated");
  try {
    const payload = JSON.parse(Buffer.from(token, "base64url").toString());
    if (payload.exp && Date.now() > payload.exp) throw new Error("Session expired");
    return payload;
  } catch {
    throw new Error("Invalid token");
  }
}

export async function PUT(req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    requireAuth(req);
    const { id } = await params;
    const body = await req.json();

    const updated = await db
      .update(siteAnnouncements)
      .set({
        title: body.title,
        message: body.message,
        imageUrl: body.imageUrl,
        color: body.color,
        icon: body.icon,
        buttonText: body.buttonText,
        buttonUrl: body.buttonUrl,
        location: body.location,
        priority: body.priority !== undefined ? parseInt(String(body.priority), 10) : undefined,
        targetAudience: body.targetAudience,
        isClosable: body.isClosable,
        isActive: body.isActive,
        startDate: body.startDate ? new Date(body.startDate) : undefined,
        endDate: body.endDate ? new Date(body.endDate) : null,
        updatedAt: new Date(),
      })
      .where(eq(siteAnnouncements.id, parseInt(id, 10)))
      .returning();

    return NextResponse.json({ ok: true, data: updated[0] }, { headers: { "Cache-Control": "no-store, max-age=0" } });
  } catch (e: any) {
    return NextResponse.json({ ok: false, error: e.message || "Failed" }, { status: 401 });
  }
}

export async function DELETE(req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    requireAuth(req);
    const { id } = await params;
    await db.delete(siteAnnouncements).where(eq(siteAnnouncements.id, parseInt(id, 10)));
    return NextResponse.json({ ok: true, message: "Aviso excluído com sucesso." }, { headers: { "Cache-Control": "no-store, max-age=0" } });
  } catch (e: any) {
    return NextResponse.json({ ok: false, error: e.message || "Failed" }, { status: 401 });
  }
}
