import { db } from "@/db";
import { siteAnnouncements } from "@/db/schema";
import { desc, eq } from "drizzle-orm";
import { NextResponse } from "next/server";

function requireAuth(req: Request) {
  const authHeader = req.headers.get("authorization") || "";
  const token = authHeader.replace("Bearer ", "");
  if (!token) throw new Error("Not authenticated");
  try {
    const payload = JSON.parse(Buffer.from(token, "base64url").toString());
    if (payload.exp && Date.now() > payload.exp) throw new Error("Session expired");
    return payload;
  } catch {
    throw new Error("Invalid token");
  }
}

export async function GET(req: Request) {
  try {
    requireAuth(req);
    const data = await db.select().from(siteAnnouncements).orderBy(desc(siteAnnouncements.createdAt));
    return NextResponse.json({ ok: true, data }, { headers: { "Cache-Control": "no-store, max-age=0" } });
  } catch (e: any) {
    return NextResponse.json({ ok: false, error: e.message || "Failed" }, { status: 401 });
  }
}

export async function POST(req: Request) {
  try {
    requireAuth(req);
    const body = await req.json();

    if (!body.title || !body.message) {
      return NextResponse.json({ ok: false, error: "Título e mensagem são obrigatórios." }, { status: 400 });
    }

    const inserted = await db
      .insert(siteAnnouncements)
      .values({
        title: body.title,
        message: body.message,
        imageUrl: body.imageUrl || null,
        color: body.color || "#f59e0b",
        icon: body.icon || "bell",
        buttonText: body.buttonText || null,
        buttonUrl: body.buttonUrl || null,
        location: body.location || "top_bar",
        priority: parseInt(String(body.priority || 1), 10),
        targetAudience: body.targetAudience || "all",
        isClosable: body.isClosable !== undefined ? body.isClosable : true,
        isActive: body.isActive !== undefined ? body.isActive : true,
        startDate: body.startDate ? new Date(body.startDate) : new Date(),
        endDate: body.endDate ? new Date(body.endDate) : null,
      })
      .returning();

    return NextResponse.json({ ok: true, data: inserted[0] }, { headers: { "Cache-Control": "no-store, max-age=0" } });
  } catch (e: any) {
    return NextResponse.json({ ok: false, error: e.message || "Failed to create announcement" }, { status: 401 });
  }
}
