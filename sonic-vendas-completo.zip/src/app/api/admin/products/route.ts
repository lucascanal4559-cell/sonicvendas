import { db } from "@/db";
import { products } from "@/db/schema";
import { eq } from "drizzle-orm";
import { NextResponse } from "next/server";

function requireAuth(req: Request) {
  const authHeader = req.headers.get("authorization") || "";
  const token = authHeader.replace("Bearer ", "");
  if (!token) throw new Error("Not authenticated");
  try {
    const payload = JSON.parse(Buffer.from(token, "base64url").toString());
    if (payload.exp && Date.now() > payload.exp) throw new Error("Session expired");
    return payload;
  } catch {
    throw new Error("Invalid token");
  }
}

export async function POST(req: Request) {
  try {
    requireAuth(req);
    const body = await req.json();
    const inserted = await db.insert(products).values({
      title: body.title,
      slug: body.slug || body.title.toLowerCase().replace(/\s+/g, "-").replace(/[^a-z0-9-]/g, ""),
      description: body.description,
      price: body.price,
      originalPrice: body.originalPrice || null,
      categoryId: body.categoryId || null,
      imageUrl: body.imageUrl,
      images: body.images || null,
      isActive: body.isActive !== undefined ? body.isActive : true,
      isPromotion: body.isPromotion || false,
      discountPercent: body.discountPercent || 0,
      availability: body.availability || "available",
      hasWarranty: body.hasWarranty || "sim_loja",
      warrantyDuration: body.warrantyDuration || "90 dias de garantia oficial",
      warrantyConditions: body.warrantyConditions || null,
      returnConditions: body.returnConditions || null,
      specifications: body.specifications || null,
    }).returning();
    return NextResponse.json({ ok: true, data: inserted[0] }, { headers: { "Cache-Control": "no-store, max-age=0" } });
  } catch (e: any) {
    return NextResponse.json({ ok: false, error: e.message || "Failed to create product" }, { status: 401 });
  }
}

export async function PUT(req: Request) {
  try {
    requireAuth(req);
    const body = await req.json();
    if (!body.id) return NextResponse.json({ ok: false, error: "ID required" }, { status: 400, headers: { "Cache-Control": "no-store, max-age=0" } });

    const updated = await db.update(products)
      .set({
        title: body.title,
        slug: body.slug,
        description: body.description,
        price: body.price,
        originalPrice: body.originalPrice,
        categoryId: body.categoryId,
        imageUrl: body.imageUrl,
        images: body.images,
        isActive: body.isActive,
        isPromotion: body.isPromotion,
        discountPercent: body.discountPercent,
        availability: body.availability,
        hasWarranty: body.hasWarranty,
        warrantyDuration: body.warrantyDuration,
        warrantyConditions: body.warrantyConditions,
        returnConditions: body.returnConditions,
        specifications: body.specifications,
        updatedAt: new Date(),
      })
      .where(eq(products.id, body.id))
      .returning();

    return NextResponse.json({ ok: true, data: updated[0] }, { headers: { "Cache-Control": "no-store, max-age=0" } });
  } catch (e: any) {
    return NextResponse.json({ ok: false, error: e.message || "Failed to update product" }, { status: 401 });
  }
}

export async function DELETE(req: Request) {
  try {
    requireAuth(req);
    const body = await req.json();
    if (!body.id) return NextResponse.json({ ok: false, error: "ID required" }, { status: 400, headers: { "Cache-Control": "no-store, max-age=0" } });
    await db.delete(products).where(eq(products.id, body.id));
    return NextResponse.json({ ok: true, message: "Deleted" }, { headers: { "Cache-Control": "no-store, max-age=0" } });
  } catch (e: any) {
    return NextResponse.json({ ok: false, error: e.message || "Failed to delete product" }, { status: 401 });
  }
}
