import { db } from "@/db";
import { futureFeatures } from "@/db/schema";
import { desc } from "drizzle-orm";
import { NextResponse } from "next/server";

function requireAuth(req: Request) {
  const authHeader = req.headers.get("authorization") || "";
  const token = authHeader.replace("Bearer ", "");
  if (!token) throw new Error("Not authenticated");
  try {
    const payload = JSON.parse(Buffer.from(token, "base64url").toString());
    if (payload.exp && Date.now() > payload.exp) throw new Error("Session expired");
    return payload;
  } catch {
    throw new Error("Invalid token");
  }
}

export async function GET(req: Request) {
  try {
    requireAuth(req);
    const data = await db.select().from(futureFeatures).orderBy(desc(futureFeatures.createdAt));
    return NextResponse.json({ ok: true, data }, { headers: { "Cache-Control": "no-store, max-age=0" } });
  } catch (e: any) {
    return NextResponse.json({ ok: false, error: e.message || "Failed" }, { status: 401 });
  }
}

export async function POST(req: Request) {
  try {
    const user = requireAuth(req);
    const body = await req.json();

    if (!body.title) {
      return NextResponse.json({ ok: false, error: "Título da novidade é obrigatório." }, { status: 400 });
    }

    // Built-in intelligent generator if aiGeneratedPlan is not provided or requested
    let plan = body.aiGeneratedPlan;
    if (!plan || body.autoGeneratePlan) {
      const t = body.title.toLowerCase();
      let steps: string[] = [];

      if (t.includes("afiliad") || t.includes("comiss") || t.includes("indic")) {
        steps = [
          "1. [Banco] Criar tabela de afiliados com chave Pix e link único de rastreio (?ref=slug).",
          "2. [Servidor] Atribuir comissão automática em cada venda confirmada de produtos ou cotas.",
          "3. [Painel do Parceiro] Área exclusiva para consultar cliques, cadastros, conversões e saldo.",
          "4. [Pagamento Automático] Disparar transferência de saque para a chave Pix cadastrada.",
          "5. [Segurança] Prevenção de auto-indicações e validação de IP/Device.",
        ];
      } else if (t.includes("pix") || t.includes("pagament") || t.includes("checkout")) {
        steps = [
          "1. [Integração] Gateway Pix automatizado com QR Code dinâmico e chave Copia e Cola.",
          "2. [Webhook] Confirmação em 2 segundos com validação de payload e assinatura HMAC.",
          "3. [Notificação] Disparo de som de caixa registradora e e-mail imediato de confirmação.",
          "4. [Auditoria] Histórico completo de comprovantes enviados e aprovados.",
        ];
      } else if (t.includes("app") || t.includes("apk") || t.includes("pwa") || t.includes("mobile")) {
        steps = [
          "1. [PWA] Configurar manifest.json e Service Worker para instalação com 1 clique no Android/iOS.",
          "2. [Notificações Push] Envio de notificações sonoras mesmo com o aplicativo fechado.",
          "3. [Cache Offline] Carregamento instantâneo do catálogo mesmo sem internet.",
          "4. [Design Nativo] Barra de navegação inferior com transições táteis suaves.",
        ];
      } else if (t.includes("vídeo") || t.includes("video") || t.includes("live") || t.includes("stream")) {
        steps = [
          "1. [Mídia] Player de vídeo leve com compressão WebM e suporte a transmissões ao vivo.",
          "2. [Autoplay Silencioso] Vídeos iniciam sem som com botão de áudio flutuante.",
          "3. [Controle de Tempo] Limitação de duração de 1 a 2 minutos com contador regressivo.",
          "4. [Destaque] Fixação no Topo e na vitrine com borda neon animada.",
        ];
      } else {
        steps = [
          `1. [Especificação] Mapeamento de requisitos para "${body.title}".`,
          "2. [Banco de Dados] Criação das tabelas relacionais com índices otimizados.",
          "3. [APIs REST] Endpoints autenticados com validação de entrada e tratamento de erros.",
          "4. [Interface Responsiva] Componente moderno com suporte a temas e sons customizados.",
          "5. [Sincronização] Atualização em tempo real sincronizada entre todos os dispositivos.",
        ];
      }
      plan = steps.join("\n");
    }

    const inserted = await db
      .insert(futureFeatures)
      .values({
        title: body.title,
        description: body.description || "Nova funcionalidade planejada para a Sonic Vendas.",
        category: body.category || "geral",
        aiGeneratedPlan: plan,
        status: body.status || "planned",
        priority: body.priority || "medium",
        createdBy: user.username || "admin",
      })
      .returning();

    return NextResponse.json({ ok: true, data: inserted[0] }, { headers: { "Cache-Control": "no-store, max-age=0" } });
  } catch (e: any) {
    return NextResponse.json({ ok: false, error: e.message || "Failed" }, { status: 401 });
  }
}
