import { db } from "@/db";
import { socialOrders, notifications } from "@/db/schema";
import { NextResponse } from "next/server";

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const {
      customerName,
      customerEmail,
      customerPhone,
      network,
      serviceName,
      targetHandleOrLink,
      quantity,
      totalAmount,
      paymentMethod,
      notes,
    } = body || {};

    if (!customerName || !customerPhone || !serviceName || !targetHandleOrLink || !totalAmount) {
      return NextResponse.json(
        { ok: false, error: "Nome, WhatsApp, serviço, @/link de destino e valor são obrigatórios." },
        { status: 400, headers: { "Cache-Control": "no-store, max-age=0" } }
      );
    }

    const inserted = await db
      .insert(socialOrders)
      .values({
        customerName: customerName.trim(),
        customerEmail: customerEmail ? customerEmail.trim().toLowerCase() : null,
        customerPhone: customerPhone.trim(),
        network: network || "instagram",
        serviceName: serviceName.trim(),
        targetHandleOrLink: targetHandleOrLink.trim(),
        quantity: String(quantity || "1"),
        totalAmount: String(totalAmount),
        paymentMethod: paymentMethod || "pix",
        status: "pending",
        notes: notes || null,
      })
      .returning();

    const order = inserted[0];

    // Notification for admin
    try {
      await db.insert(notifications).values({
        title: `📱 Novo Pedido de Redes Sociais (#${order.id})`,
        message: `${customerName} solicitou ${serviceName} (${quantity}) para "${targetHandleOrLink}" no valor de R$ ${totalAmount}. Forma: ${paymentMethod?.toUpperCase()}.`,
        isActive: true,
      });
    } catch {}

    return NextResponse.json(
      {
        ok: true,
        message: "Pedido de engajamento registrado com sucesso! Realize o pagamento pelo Pix ou Cartão para envio.",
        data: order,
      },
      { headers: { "Cache-Control": "no-store, max-age=0" } }
    );
  } catch (e: any) {
    return NextResponse.json(
      { ok: false, error: e.message || "Erro ao registrar pedido de rede social" },
      { status: 500, headers: { "Cache-Control": "no-store, max-age=0" } }
    );
  }
}
