import { db } from "@/db";
import { groups } from "@/db/schema";
import { desc, eq } from "drizzle-orm";
import { NextResponse } from "next/server";

export async function GET(req: Request) {
  try {
    const { searchParams } = new URL(req.url);
    const platform = searchParams.get("platform")?.toLowerCase();
    const category = searchParams.get("category")?.toLowerCase();

    let query = db.select().from(groups).where(eq(groups.isActive, true)).orderBy(desc(groups.createdAt));
    let data = await query;

    if (platform && platform !== "all") {
      data = data.filter((g) => g.platform?.toLowerCase() === platform);
    }
    if (category && category !== "all") {
      data = data.filter((g) => g.category?.toLowerCase() === category);
    }

    return NextResponse.json(
      { ok: true, data },
      { headers: { "Cache-Control": "public, max-age=5, stale-while-revalidate=15" } }
    );
  } catch (e: any) {
    return NextResponse.json({ ok: false, error: e.message || "Failed" }, { status: 500 });
  }
}
