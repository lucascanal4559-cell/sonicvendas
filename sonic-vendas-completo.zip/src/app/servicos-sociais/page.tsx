"use client";
import React, { useState } from "react";
import Link from "next/link";
import {
  Sparkles,
  ArrowLeft,
  Flame,
  CheckCircle2,
  Copy,
  Check,
  CreditCard,
  QrCode,
  ShieldCheck,
  Send,
  Zap,
  HelpCircle,
  ExternalLink,
  MessageCircle,
  Video,
  Play,
  Heart,
  Eye,
  Users,
  Award,
  Crown,
  Smartphone,
  Gamepad2,
  Tv,
} from "lucide-react";
import { playSound } from "@/lib/sounds";

interface ServiceOption {
  category: string;
  network: "instagram" | "tiktok" | "kwai" | "youtube" | "facebook" | "freefire" | "outros" | "tv";
  title: string;
  badge?: string;
  description: string;
  packages: { qty: string; price: number; rawPriceStr?: string }[];
}

export const SOCIAL_CATALOG: ServiceOption[] = [
  // INSTAGRAM
  {
    category: "Instagram - Seguidores Mundial (Reposição 30d)",
    network: "instagram",
    title: "Seguidores Mundial com Reposição de 30 Dias 🇻🇬",
    badge: "SEM QUEDAS • POPULAR",
    description: "Serviço atualizado sem quedas, entrega rápida e garantia de reposição de 30 dias.",
    packages: [
      { qty: "100 Seguidores", price: 4.0 },
      { qty: "300 Seguidores", price: 7.0 },
      { qty: "500 Seguidores", price: 15.0 },
      { qty: "600 Seguidores", price: 17.78 },
      { qty: "1.000 (1k) Seguidores", price: 23.0 },
      { qty: "2.000 (2k) Seguidores", price: 55.0 },
      { qty: "3.000 (3k) Seguidores", price: 80.0 },
      { qty: "4.000 (4k) Seguidores", price: 90.0 },
      { qty: "5.000 (5k) Seguidores", price: 105.0 },
    ],
  },
  {
    category: "Instagram - Planos Mensais de Seguidores Brasileiros Reais",
    network: "instagram",
    title: "🏆 Planos Mensais de Seguidores Brasileiros Reais com Interação",
    badge: "MENSAL VIP • NÃO PRECISA DE SENHA",
    description: "Seguidores reais e brasileiros que podem interagir com seu perfil. 30 dias de divulgação e atendimento pelo WhatsApp.",
    packages: [
      { qty: "Plano Teste (100 seguidores em 24h)", price: 50.0 },
      { qty: "1.000 a 1.500 seguidores / mês", price: 199.0 },
      { qty: "2.000 a 4.000 seguidores / mês", price: 299.0 },
      { qty: "4.000 a 6.000 seguidores / mês", price: 399.0 },
      { qty: "8.000 a 12.000 seguidores / mês", price: 599.0 },
      { qty: "14.000 a 16.000 seguidores / mês", price: 799.0 },
      { qty: "18.000 a 22.000 seguidores / mês", price: 999.0 },
    ],
  },
  {
    category: "Instagram - Seguidores Brasileiros (30d Reposição)",
    network: "instagram",
    title: "Seguidores Brasileiros com 30 Dias de Reposição 🇧🇷",
    badge: "100% BRASILEIROS",
    description: "Perfis com fotos, bios e publicações brasileiras ativas.",
    packages: [
      { qty: "500 Seguidores", price: 34.45 },
      { qty: "1.000 (1k) Seguidores", price: 48.9 },
      { qty: "2.000 (2k) Seguidores", price: 87.8 },
      { qty: "3.000 (3k) Seguidores", price: 116.7 },
      { qty: "4.000 (4k) Seguidores", price: 225.6 },
      { qty: "5.000 (5k) Seguidores", price: 454.5 },
      { qty: "10.000 (10k) Seguidores", price: 599.0 },
    ],
  },
  {
    category: "Instagram - Curtidas Mundial & Brasileiras",
    network: "instagram",
    title: "Curtidas Mundial e Brasileiras para Publicações e Reels",
    badge: "ENTREGA IMEDIATA",
    description: "Aumente o engajamento e o alcance das suas fotos e vídeos no feed.",
    packages: [
      { qty: "100 Curtidas Mundial", price: 2.0 },
      { qty: "300 Curtidas Mundial", price: 6.0 },
      { qty: "500 Curtidas Mundial", price: 10.0 },
      { qty: "1.000 (1k) Curtidas Mundial", price: 17.0 },
      { qty: "2.000 (2k) Curtidas Mundial", price: 20.0 },
      { qty: "5.000 (5k) Curtidas Mundial", price: 50.0 },
      { qty: "10.000 (10k) Curtidas Mundial", price: 65.0 },
      { qty: "500 Curtidas Brasileiras 🇧🇷", price: 20.0 },
      { qty: "1.000 (1k) Curtidas Brasileiras 🇧🇷", price: 48.0 },
      { qty: "5.000 (5k) Curtidas Brasileiras 🇧🇷", price: 99.0 },
      { qty: "10.000 (10k) Curtidas Brasileiras 🇧🇷", price: 278.0 },
    ],
  },
  {
    category: "Instagram - Visualizações Reels, IGTV & Stories",
    network: "instagram",
    title: "Visualizações Brasileiras e Mundial para Reels e Stories",
    badge: "ALTO ALCANCE",
    description: "Impulsione seus vídeos para o algoritmo entregar a mais pessoas.",
    packages: [
      { qty: "500 Visualizações Mundial", price: 4.0 },
      { qty: "1.000 (1k) Visualizações Mundial", price: 6.5 },
      { qty: "5.000 (5k) Visualizações Mundial", price: 48.3 },
      { qty: "10.000 (10k) Visualizações Mundial", price: 62.0 },
      { qty: "500 Visualizações Brasileiras 🇧🇷", price: 15.0 },
      { qty: "1.000 (1k) Visualizações Brasileiras 🇧🇷", price: 20.0 },
      { qty: "5.000 (5k) Visualizações Brasileiras 🇧🇷", price: 80.0 },
      { qty: "10.000 (10k) Visualizações Brasileiras 🇧🇷", price: 170.0 },
      { qty: "100 Visualizações nos Stories 👀", price: 3.0 },
      { qty: "500 Visualizações nos Stories 👀", price: 6.0 },
      { qty: "1.000 (1k) Visualizações nos Stories 👀", price: 12.0 },
      { qty: "5.000 (5k) Visualizações nos Stories 👀", price: 30.0 },
      { qty: "10.000 (10k) Visualizações nos Stories 👀", price: 50.0 },
    ],
  },
  {
    category: "Instagram - Comentários e Verificados",
    network: "instagram",
    title: "Comentários Personalizados e Perfil Verificado",
    badge: "PROVA SOCIAL MÁXIMA",
    description: "Comentários reais e opção de comentário com selo azul verificado em 24h.",
    packages: [
      { qty: "100 Comentários Mundial", price: 6.0 },
      { qty: "500 Comentários Mundial", price: 19.0 },
      { qty: "1.000 (1k) Comentários Mundial", price: 35.0 },
      { qty: "3.000 (3k) Comentários Mundial", price: 140.0 },
      { qty: "🏆 Comentário de Perfil Verificado (Entrega em 24h)", price: 50.0 },
    ],
  },

  // TIKTOK
  {
    category: "TikTok - Seguidores, Likes e Visualizações",
    network: "tiktok",
    title: "Seguidores, Curtidas e Visualizações para TikTok 🎵",
    badge: "ENTREGA RÁPIDA",
    description: "Cresça no TikTok e libere lives e monetização.",
    packages: [
      { qty: "100 Seguidores Mundial", price: 8.0 },
      { qty: "300 Seguidores Mundial", price: 18.8 },
      { qty: "500 Seguidores Mundial", price: 28.0 },
      { qty: "1.000 (1k) Seguidores Mundial", price: 61.0 },
      { qty: "5.000 (5k) Seguidores Mundial", price: 427.0 },
      { qty: "500 Seguidores Brasileiros 🇧🇷", price: 29.5 },
      { qty: "1.000 (1k) Seguidores Brasileiros 🇧🇷", price: 69.9 },
      { qty: "3.000 (3k) Seguidores Brasileiros 🇧🇷", price: 220.0 },
      { qty: "500 Curtidas TikTok", price: 15.0 },
      { qty: "1.000 (1k) Curtidas TikTok", price: 19.5 },
      { qty: "5.000 (5k) Curtidas TikTok", price: 60.0 },
      { qty: "1.000 (1k) Visualizações TikTok", price: 14.0 },
      { qty: "5.000 (5k) Visualizações TikTok", price: 55.0 },
      { qty: "10.000 (10k) Visualizações TikTok", price: 100.0 },
    ],
  },

  // KWAI
  {
    category: "Kwai - Seguidores e Curtidas",
    network: "kwai",
    title: "Seguidores e Curtidas Brasileiras para Kwai 👑",
    badge: "BRASILEIROS 🇧🇷",
    description: "Fortaleça seu perfil do Kwai com métricas orgânicas.",
    packages: [
      { qty: "100 Seguidores Mundial", price: 8.0 },
      { qty: "500 Seguidores Mundial", price: 24.95 },
      { qty: "1.000 (1k) Seguidores Mundial", price: 49.9 },
      { qty: "1.000 (1k) Seguidores Brasileiros 🇧🇷", price: 60.0 },
      { qty: "5.000 (5k) Seguidores Brasileiros 🇧🇷", price: 240.0 },
      { qty: "10.000 (10k) Seguidores Brasileiros 🇧🇷", price: 480.0 },
      { qty: "1.000 (1k) Curtidas Brasileiras 🇧🇷", price: 40.0 },
      { qty: "5.000 (5k) Curtidas Brasileiras 🇧🇷", price: 190.0 },
      { qty: "10.000 (10k) Curtidas Brasileiras 🇧🇷", price: 265.0 },
    ],
  },

  // YOUTUBE
  {
    category: "YouTube - Inscritos, Visualizações e Likes",
    network: "youtube",
    title: "Inscritos, Visualizações e Likes para YouTube 📺",
    badge: "MONETIZE SEU CANAL",
    description: "Alcance as 4.000 horas e 1.000 inscritos para monetização.",
    packages: [
      { qty: "100 Inscritos", price: 28.0 },
      { qty: "1.000 (1k) Inscritos", price: 99.0 },
      { qty: "2.000 (2k) Inscritos", price: 280.0 },
      { qty: "3.000 (3k) Inscritos", price: 357.0 },
      { qty: "5.000 (5k) Inscritos", price: 845.0 },
      { qty: "100 Visualizações", price: 6.0 },
      { qty: "500 Visualizações", price: 22.0 },
      { qty: "1.000 (1k) Visualizações", price: 40.0 },
      { qty: "1.000 (1k) Likes", price: 18.0 },
      { qty: "10.000 (10k) Likes", price: 140.0 },
    ],
  },

  // FACEBOOK
  {
    category: "Facebook - Seguidores e Curtidas",
    network: "facebook",
    title: "Seguidores para Perfil e Curtidas em Página 📘",
    badge: "PÁGINAS & PERFIS",
    description: "Fortaleça sua fanpage e perfil comercial no Facebook.",
    packages: [
      { qty: "1.000 (1k) Curtidas Post", price: 17.0 },
      { qty: "5.000 (5k) Curtidas Post", price: 60.0 },
      { qty: "1.000 (1k) Seguidores Perfil", price: 60.0 },
      { qty: "5.000 (5k) Seguidores Perfil", price: 403.0 },
      { qty: "100 Seguidores + Curtidas Página", price: 8.25 },
      { qty: "500 Seguidores + Curtidas Página", price: 40.8 },
      { qty: "1.000 (1k) Seguidores + Curtidas Página", price: 82.0 },
      { qty: "5.000 (5k) Seguidores + Curtidas Página", price: 514.0 },
      { qty: "1.000 Visualizações de Vídeo", price: 6.5 },
      { qty: "5.000 Visualizações de Vídeo", price: 34.8 },
      { qty: "10.000 Visualizações de Vídeo", price: 60.5 },
    ],
  },

  // FREE FIRE
  {
    category: "Free Fire - Diamantes & Passes",
    network: "freefire",
    title: "Diamantes Free Fire (+20% Bônus) & Passes 💎",
    badge: "+20% BÔNUS NO ID",
    description: "Envio rápido direto pelo seu ID de jogador. Ganhe 20% a mais de brinde!",
    packages: [
      { qty: "100 Diamantes (+20% Bônus)", price: 7.49 },
      { qty: "310 Diamantes (+20% Bônus)", price: 20.0 },
      { qty: "520 Diamantes (+20% Bônus)", price: 30.99 },
      { qty: "1.060 Diamantes (+20% Bônus)", price: 55.0 },
      { qty: "2.180 Diamantes (+20% Bônus)", price: 97.0 },
      { qty: "5.600 Diamantes (+20% Bônus)", price: 220.0 },
      { qty: "🔥 Passe de Elite Free Fire (Pelo ID)", price: 15.0 },
      { qty: "👍 100 Likes no Perfil Free Fire", price: 8.0 },
      { qty: "👍 500 Likes no Perfil Free Fire", price: 12.0 },
      { qty: "👍 1.000 Likes no Perfil Free Fire", price: 22.0 },
      { qty: "👾 300 Tokens Armas Evolutivas", price: 49.0 },
      { qty: "👾 500 Tokens Armas Evolutivas", price: 64.0 },
      { qty: "👾 1.000 Tokens Armas Evolutivas", price: 100.0 },
    ],
  },

  // THREADS, TWITTER, TWITCH, SPOTIFY
  {
    category: "Outras Redes (Threads, Twitter, Twitch, Spotify)",
    network: "outros",
    title: "Serviços para Threads, Twitter, Twitch & Spotify 🎶",
    badge: "MULTIRREDES",
    description: "Cresça em todas as plataformas com engajamento de qualidade.",
    packages: [
      { qty: "100 Seguidores Threads Mundial", price: 7.0 },
      { qty: "500 Seguidores Threads Mundial", price: 27.5 },
      { qty: "1.000 (1k) Seguidores Threads Mundial", price: 55.0 },
      { qty: "100 Seguidores Threads Brasileiros 🇧🇷", price: 19.9 },
      { qty: "500 Seguidores Threads Brasileiros 🇧🇷", price: 64.5 },
      { qty: "1.000 (1k) Seguidores Threads Brasileiros 🇧🇷", price: 144.0 },
      { qty: "100 Seguidores Twitch", price: 1.5 },
      { qty: "500 Seguidores Twitch", price: 3.5 },
      { qty: "1.000 Seguidores Twitch", price: 4.4 },
      { qty: "1.000 Seguidores Twitter / X", price: 29.0 },
      { qty: "5.000 Seguidores Twitter / X", price: 140.0 },
      { qty: "1.000 Seguidores Spotify", price: 18.0 },
      { qty: "2.000 Seguidores Spotify", price: 30.0 },
      { qty: "1.000 Seguidores SoundCloud", price: 20.0 },
    ],
  },

  // TV POR ASSINATURA
  {
    category: "TV por Assinatura (Claro, Sky, Oi TV)",
    network: "tv",
    title: "Recargas e Planos de TV por Assinatura 📺",
    badge: "MAIS DE 40 A 190 CANAIS",
    description: "Planos mensais e trimestrais para Claro TV, Sky TV e Oi TV Livre em HD.",
    packages: [
      { qty: "Claro TV Inicial (30 dias - HD)", price: 30.0 },
      { qty: "Claro TV Inicial (60 dias - HD)", price: 45.0 },
      { qty: "Claro TV Inicial (90 dias - HD)", price: 66.0 },
      { qty: "Claro TV Inicial (180 dias - HD)", price: 98.0 },
      { qty: "Sky TV / Oi TV Start (Consultar no WhatsApp)", price: 35.0 },
    ],
  },
];

export default function ServicosSociaisPage() {
  const [selectedNetwork, setSelectedNetwork] = useState<string>("all");
  const [selectedService, setSelectedService] = useState<ServiceOption>(SOCIAL_CATALOG[0]);
  const [selectedPackageIndex, setSelectedPackageIndex] = useState<number>(0);

  // Form states
  const [customerName, setCustomerName] = useState("");
  const [customerPhone, setCustomerPhone] = useState("");
  const [customerEmail, setCustomerEmail] = useState("");
  const [targetHandleOrLink, setTargetHandleOrLink] = useState("");
  const [paymentMethod, setPaymentMethod] = useState<"pix" | "cartao">("pix");
  const [receiptUrl, setReceiptUrl] = useState("");

  const [loading, setLoading] = useState(false);
  const [orderSuccess, setOrderSuccess] = useState<any | null>(null);
  const [copiedPix, setCopiedPix] = useState(false);

  const pixKey = "75981558007";

  const filteredServices = selectedNetwork === "all"
    ? SOCIAL_CATALOG
    : SOCIAL_CATALOG.filter((s) => s.network === selectedNetwork);

  const currentPkg = selectedService.packages[selectedPackageIndex] || selectedService.packages[0];

  async function handleOrderSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);

    try {
      const res = await fetch("/api/social/order", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          customerName,
          customerPhone,
          customerEmail,
          network: selectedService.network,
          serviceName: `${selectedService.title} - ${currentPkg.qty}`,
          targetHandleOrLink,
          quantity: currentPkg.qty,
          totalAmount: currentPkg.price.toFixed(2),
          paymentMethod: paymentMethod === "pix" ? "pix" : "credit_card",
        }),
      });

      const data = await res.json();
      if (data.ok) {
        playSound("new_order");
        setOrderSuccess(data.data);
      } else {
        alert(data.error || "Erro ao registrar pedido.");
      }
    } catch {
      alert("Erro de conexão ao enviar pedido.");
    } finally {
      setLoading(false);
    }
  }

  function handleCopyPix() {
    navigator.clipboard.writeText(pixKey);
    setCopiedPix(true);
    setTimeout(() => setCopiedPix(false), 2000);
  }

  // Pre-generate WhatsApp direct link
  const whatsappMsg = `Olá Sonic Vendas! Gostaria de contratar o serviço:\n\n📌 *${selectedService.title}*\n📦 *Pacote:* ${currentPkg.qty}\n💰 *Valor:* R$ ${currentPkg.price.toFixed(2)}\n🔗 *@ ou Link:* ${targetHandleOrLink || "(informarei aqui)"}\n👤 *Nome:* ${customerName || "(meu nome)"}`;
  const whatsappUrl = `https://wa.me/5575981558007?text=${encodeURIComponent(whatsappMsg)}`;

  return (
    <main className="min-h-screen bg-[#040817] text-slate-100 selection:bg-pink-500 selection:text-black">
      {/* Ambient background light */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden">
        <div className="absolute -top-40 left-1/2 -translate-x-1/2 w-[800px] h-[500px] bg-gradient-to-b from-pink-600/15 via-purple-600/15 to-transparent blur-3xl" />
        <div className="absolute top-[30%] -left-32 w-[500px] h-[500px] bg-pink-700/10 blur-[140px]" />
        <div className="absolute top-[60%] -right-32 w-[500px] h-[500px] bg-cyan-600/10 blur-[140px]" />
      </div>

      <div className="relative z-10 mx-auto max-w-6xl px-4 py-8 md:px-6 md:py-12">
        {/* Navigation Breadcrumb */}
        <div className="flex flex-col md:flex-row items-center justify-between gap-4 border-b border-slate-800 pb-6">
          <Link
            href="/"
            className="inline-flex items-center gap-2 text-sm font-bold text-amber-400 hover:text-amber-300 transition-colors"
          >
            <ArrowLeft size={18} /> Voltar à Página Inicial
          </Link>

          <div className="flex items-center gap-2 rounded-full border border-pink-500/30 bg-pink-950/40 px-4 py-1.5 backdrop-blur-md">
            <span className="h-2 w-2 rounded-full bg-pink-400 animate-ping" />
            <span className="text-xs font-black uppercase tracking-wide text-pink-300">
              TABELA OFICIAL DE ENGAJAMENTO & REDES SOCIAIS
            </span>
          </div>
        </div>

        {/* Header */}
        <div className="mt-8 text-center md:mt-12">
          <div className="inline-flex items-center gap-2 rounded-full bg-gradient-to-r from-pink-600/20 via-purple-600/20 to-pink-600/20 px-5 py-2 border border-pink-400/40 shadow-lg shadow-pink-500/20 mb-3 animate-pulse">
            <Flame className="text-pink-400" size={18} />
            <span className="text-xs font-black uppercase tracking-wider text-pink-300">
              SERVIÇOS ATUALIZADOS • SEM QUEDAS • COM GARANTIA DE REPOSIÇÃO
            </span>
          </div>

          <h1 className="text-4xl font-black tracking-tight text-white md:text-6xl drop-shadow-[0_0_35px_rgba(236,72,153,0.5)]">
            SEGUIDORES, CURTIDAS <br className="hidden md:inline" />
            <span className="bg-gradient-to-r from-pink-400 via-purple-400 to-amber-300 bg-clip-text text-transparent">
              & ENGAJAMENTO REAL!
            </span>
          </h1>

          <p className="mx-auto mt-3 max-w-2xl text-sm md:text-base text-slate-300">
            Instagram, TikTok, Kwai, YouTube, Facebook, Free Fire, Threads e muito mais. <br />
            <strong>Pedimos apenas o seu @ ou link. Não precisamos da sua senha!</strong>
          </p>
        </div>

        {/* Network Filter Pills */}
        <div className="mt-10 flex flex-wrap items-center justify-center gap-2">
          {[
            { id: "all", label: "🌟 Todos os Serviços" },
            { id: "instagram", label: "📸 Instagram" },
            { id: "tiktok", label: "🎵 TikTok" },
            { id: "kwai", label: "👑 Kwai" },
            { id: "youtube", label: "▶️ YouTube" },
            { id: "facebook", label: "📘 Facebook" },
            { id: "freefire", label: "💎 Free Fire" },
            { id: "outros", label: "💬 Threads / Twitch / Spotify" },
            { id: "tv", label: "📺 TV por Assinatura" },
          ].map((net) => (
            <button
              key={net.id}
              onClick={() => {
                setSelectedNetwork(net.id);
                const firstMatch = net.id === "all" ? SOCIAL_CATALOG[0] : SOCIAL_CATALOG.find((s) => s.network === net.id);
                if (firstMatch) {
                  setSelectedService(firstMatch);
                  setSelectedPackageIndex(0);
                }
              }}
              className={`rounded-xl px-4 py-2 text-xs font-bold transition-all ${
                selectedNetwork === net.id
                  ? "bg-gradient-to-r from-pink-500 to-purple-600 text-white font-black shadow-lg shadow-pink-500/20 scale-105"
                  : "bg-slate-900/80 text-slate-300 border border-slate-800 hover:bg-slate-800"
              }`}
            >
              {net.label}
            </button>
          ))}
        </div>

        {/* Main 2-Column Section: Catalog on Left + Order Calculator on Right */}
        <div className="mt-10 grid gap-8 lg:grid-cols-12 items-start">
          {/* Left Column: Service Selection */}
          <div className="space-y-4 lg:col-span-7">
            <h3 className="text-lg font-black text-white flex items-center gap-2">
              <Sparkles className="text-pink-400" size={20} />
              Escolha o Serviço Desejado:
            </h3>

            <div className="space-y-3">
              {filteredServices.map((service, idx) => {
                const isSelected = selectedService.title === service.title;
                return (
                  <div
                    key={idx}
                    onClick={() => {
                      setSelectedService(service);
                      setSelectedPackageIndex(0);
                    }}
                    className={`cursor-pointer rounded-2xl border p-5 transition-all ${
                      isSelected
                        ? "border-pink-500 bg-gradient-to-r from-pink-950/60 via-slate-900 to-purple-950/60 shadow-xl shadow-pink-500/10 scale-[1.01]"
                        : "border-slate-800 bg-slate-900/60 hover:border-slate-700 hover:bg-slate-900"
                    }`}
                  >
                    <div className="flex items-center justify-between gap-2">
                      <div className="flex items-center gap-2">
                        <span className="text-base font-black text-white">{service.title}</span>
                      </div>
                      {service.badge && (
                        <span className="shrink-0 rounded-full bg-pink-500/20 px-2.5 py-0.5 text-[10px] font-black uppercase text-pink-300 border border-pink-500/30">
                          {service.badge}
                        </span>
                      )}
                    </div>
                    <p className="mt-1 text-xs text-slate-400">{service.description}</p>

                    {/* Horizontal package previews */}
                    <div className="mt-3 flex flex-wrap gap-1.5">
                      {service.packages.slice(0, 4).map((p, pIdx) => (
                        <span
                          key={pIdx}
                          className="rounded-lg bg-slate-950 px-2 py-0.5 text-[10px] font-bold text-amber-300 border border-slate-800"
                        >
                          {p.qty.split(" ")[0]} = R$ {p.price.toFixed(2)}
                        </span>
                      ))}
                      {service.packages.length > 4 && (
                        <span className="text-[10px] text-slate-500 self-center">
                          +{service.packages.length - 4} opções...
                        </span>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Right Column: Interactive Order Calculator & Pix Checkout */}
          <div className="lg:col-span-5 sticky top-24">
            <div className="rounded-3xl border-2 border-pink-500/40 bg-gradient-to-b from-slate-950 via-slate-900 to-slate-950 p-6 md:p-8 shadow-2xl backdrop-blur-xl">
              <div className="border-b border-slate-800 pb-4">
                <span className="text-[10px] font-black uppercase tracking-widest text-pink-400">
                  CALCULADORA DE PEDIDO
                </span>
                <h3 className="text-xl font-black text-white mt-1">{selectedService.title}</h3>
                <p className="text-xs text-slate-400 mt-0.5">Selecione a quantidade abaixo para calcular o valor.</p>
              </div>

              {!orderSuccess ? (
                <form onSubmit={handleOrderSubmit} className="mt-5 space-y-4">
                  {/* Select Quantity Option */}
                  <div>
                    <label className="mb-1 block text-xs font-bold text-slate-300">
                      Escolha o Pacote / Quantidade
                    </label>
                    <select
                      value={selectedPackageIndex}
                      onChange={(e) => setSelectedPackageIndex(parseInt(e.target.value, 10))}
                      className="w-full rounded-2xl border border-pink-500/30 bg-slate-950 px-4 py-3 text-xs md:text-sm font-bold text-white focus:border-pink-400 focus:outline-none"
                    >
                      {selectedService.packages.map((pkg, idx) => (
                        <option key={idx} value={idx}>
                          {pkg.qty} — R$ {pkg.price.toFixed(2)}
                        </option>
                      ))}
                    </select>
                  </div>

                  {/* Target Handle or Link Input */}
                  <div>
                    <label className="mb-1 block text-xs font-bold text-slate-300">
                      {selectedService.network === "freefire" ? "Seu ID de Jogador no Free Fire" : "Seu @ do Perfil ou Link da Publicação"}
                    </label>
                    <input
                      type="text"
                      required
                      placeholder={selectedService.network === "freefire" ? "Ex: 123456789" : "Ex: @seu_usuario ou https://..."}
                      value={targetHandleOrLink}
                      onChange={(e) => setTargetHandleOrLink(e.target.value)}
                      className="w-full rounded-2xl border border-slate-700 bg-slate-950 px-4 py-3 text-xs text-white placeholder-slate-500 focus:border-pink-400 focus:outline-none"
                    />
                  </div>

                  <div className="grid gap-3 md:grid-cols-2">
                    <div>
                      <label className="mb-1 block text-xs font-bold text-slate-300">Seu Nome</label>
                      <input
                        type="text"
                        required
                        placeholder="Ex: Lucas"
                        value={customerName}
                        onChange={(e) => setCustomerName(e.target.value)}
                        className="w-full rounded-xl border border-slate-700 bg-slate-950 px-3 py-2 text-xs text-white focus:border-pink-400 focus:outline-none"
                      />
                    </div>
                    <div>
                      <label className="mb-1 block text-xs font-bold text-slate-300">WhatsApp para Contato</label>
                      <input
                        type="text"
                        required
                        placeholder="(75) 98155-8007"
                        value={customerPhone}
                        onChange={(e) => setCustomerPhone(e.target.value)}
                        className="w-full rounded-xl border border-slate-700 bg-slate-950 px-3 py-2 text-xs text-white focus:border-pink-400 focus:outline-none"
                      />
                    </div>
                  </div>

                  {/* Payment Method Selector */}
                  <div>
                    <label className="mb-1.5 block text-xs font-bold text-slate-300">Forma de Pagamento</label>
                    <div className="grid grid-cols-2 gap-2">
                      <button
                        type="button"
                        onClick={() => setPaymentMethod("pix")}
                        className={`rounded-xl p-2.5 text-xs font-bold border flex items-center justify-center gap-1.5 transition-all ${
                          paymentMethod === "pix"
                            ? "bg-emerald-950/60 border-emerald-400 text-emerald-300"
                            : "bg-slate-950 border-slate-800 text-slate-400"
                        }`}
                      >
                        <QrCode size={14} /> Pix (Instantâneo)
                      </button>
                      <button
                        type="button"
                        onClick={() => setPaymentMethod("cartao")}
                        className={`rounded-xl p-2.5 text-xs font-bold border flex items-center justify-center gap-1.5 transition-all ${
                          paymentMethod === "cartao"
                            ? "bg-blue-950/60 border-blue-400 text-cyan-300"
                            : "bg-slate-950 border-slate-800 text-slate-400"
                        }`}
                      >
                        <CreditCard size={14} /> Cartão Crédito/Débito
                      </button>
                    </div>
                  </div>

                  {/* Total Amount Box */}
                  <div className="flex items-center justify-between rounded-2xl border border-pink-400/30 bg-gradient-to-r from-pink-950/40 to-slate-950 p-4">
                    <div>
                      <span className="text-[10px] font-black uppercase text-pink-300 block">VALOR A PAGAR:</span>
                      <span className="text-xs text-slate-400">{currentPkg.qty}</span>
                    </div>
                    <span className="text-3xl font-black text-amber-400">R$ {currentPkg.price.toFixed(2)}</span>
                  </div>

                  {/* Submit Order */}
                  <button
                    type="submit"
                    disabled={loading}
                    className="w-full rounded-2xl bg-gradient-to-r from-pink-500 via-purple-500 to-amber-400 py-3.5 text-sm font-black uppercase text-slate-950 shadow-xl shadow-pink-500/20 hover:brightness-110 transition-all disabled:opacity-60"
                  >
                    {loading ? "Registrando Pedido..." : `Confirmar Pedido (R$ ${currentPkg.price.toFixed(2)})`}
                  </button>

                  {/* WhatsApp Direct Buy Link */}
                  <a
                    href={whatsappUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="flex w-full items-center justify-center gap-2 rounded-2xl border border-emerald-400/40 bg-emerald-950/30 py-3 text-xs font-bold text-emerald-300 hover:bg-emerald-500 hover:text-slate-950 transition-all"
                  >
                    <MessageCircle size={16} /> Comprar Direto no WhatsApp
                  </a>
                </form>
              ) : (
                /* Order Confirmation Box with Pix Key */
                <div className="mt-5 space-y-4">
                  <div className="rounded-2xl border-2 border-emerald-400 bg-emerald-950/40 p-5 text-center">
                    <div className="text-3xl mb-1">🎉</div>
                    <h4 className="text-xl font-black text-white">Pedido #{orderSuccess.id} Registrado!</h4>
                    <p className="text-xs text-slate-300 mt-1">
                      Serviço: <strong>{orderSuccess.serviceName}</strong> para <strong>{orderSuccess.targetHandleOrLink}</strong>
                    </p>
                    <div className="mt-2 text-2xl font-black text-amber-400">
                      R$ {Number(orderSuccess.totalAmount).toFixed(2)}
                    </div>
                  </div>

                  {/* Pix Box */}
                  <div className="rounded-2xl border border-slate-800 bg-slate-950 p-4">
                    <span className="text-xs font-bold text-slate-400 block mb-1">
                      Chave Pix Oficial (Telefone WhatsApp):
                    </span>
                    <div className="flex items-center justify-between gap-2">
                      <code className="text-base font-mono font-black text-emerald-400">{pixKey}</code>
                      <button
                        type="button"
                        onClick={handleCopyPix}
                        className="flex items-center gap-1 rounded-xl bg-emerald-400 px-3 py-1.5 text-xs font-black text-slate-950 hover:bg-emerald-300 transition-colors"
                      >
                        {copiedPix ? <Check size={14} /> : <Copy size={14} />}
                        <span>{copiedPix ? "Copiado!" : "Copiar"}</span>
                      </button>
                    </div>
                  </div>

                  {/* Direct WhatsApp Confirmation Button */}
                  <a
                    href={`https://wa.me/5575981558007?text=Olá!%20Acabei%20de%20fazer%20o%20Pedido%20%23${orderSuccess.id}%20de%20${encodeURIComponent(orderSuccess.serviceName)}%20no%20valor%20de%20R$%20${orderSuccess.totalAmount}.%20Segue%20meu%20comprovante.`}
                    target="_blank"
                    rel="noreferrer"
                    className="flex w-full items-center justify-center gap-2 rounded-2xl bg-emerald-500 py-3 text-xs font-black uppercase text-slate-950 hover:bg-emerald-400 transition-all shadow-lg shadow-emerald-500/20"
                  >
                    <MessageCircle size={16} /> Enviar Comprovante no WhatsApp
                  </a>

                  <button
                    type="button"
                    onClick={() => {
                      setOrderSuccess(null);
                      setTargetHandleOrLink("");
                    }}
                    className="w-full text-center text-xs text-slate-400 hover:text-white"
                  >
                    Fazer Outro Pedido
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* FAQs and Reposição explanation */}
        <div className="mt-16 rounded-3xl border border-slate-800 bg-slate-900/40 p-6 md:p-8">
          <h4 className="text-lg font-black text-white flex items-center gap-2">
            <HelpCircle className="text-amber-400" size={20} />
            Dúvidas Frequentes & Garantia de Reposição
          </h4>

          <div className="mt-4 grid gap-4 md:grid-cols-3 text-xs text-slate-300">
            <div className="rounded-2xl bg-slate-950 p-4 border border-slate-800">
              <span className="font-bold text-amber-400 block mb-1">🤔 O que é Reposição?</span>
              <p className="text-slate-400 leading-relaxed">
                Reposição é a garantia oficial que damos a todos os clientes: caso os seguidores caiam dentro do prazo contratado (30, 60, 90, 120 ou 365 dias), você tem direito de pedir reposição gratuita para restaurar a contagem.
              </p>
            </div>

            <div className="rounded-2xl bg-slate-950 p-4 border border-slate-800">
              <span className="font-bold text-amber-400 block mb-1">🔒 Preciso informar minha senha?</span>
              <p className="text-slate-400 leading-relaxed">
                <strong>NÃO! Nunca pedimos sua senha.</strong> Precisamos apenas do seu @ de usuário ou do link público da postagem / ID do jogo. Sua conta permanece 100% segura.
              </p>
            </div>

            <div className="rounded-2xl bg-slate-950 p-4 border border-slate-800">
              <span className="font-bold text-amber-400 block mb-1">⚡ Qual o prazo de entrega?</span>
              <p className="text-slate-400 leading-relaxed">
                A maioria dos pedidos inicia em até 10 minutos após a confirmação do pagamento via Pix ou Cartão. Planos mensais de seguidores reais são distribuídos ao longo dos 30 dias.
              </p>
            </div>
          </div>
        </div>
      </div>
    </main>
  );
}
