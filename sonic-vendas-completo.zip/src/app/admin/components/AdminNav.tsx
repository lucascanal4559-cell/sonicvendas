"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { Package, Tag, Image, ShoppingCart, Settings, LogOut } from "lucide-react";

export default function AdminNav() {
  const pathname = usePathname();
  const links = [
    { label: "Dashboard", href: "/admin", icon: Settings },
    { label: "Produtos", href: "/admin/produtos", icon: Package },
    { label: "Categorias", href: "/admin/categorias", icon: Tag },
    { label: "Banners", href: "/admin/banners", icon: Image },
    { label: "Pedidos", href: "/admin/pedidos", icon: ShoppingCart },
  ];

  return (
    <aside className="w-64 shrink-0 border-r border-slate-800 bg-slate-900/60 p-6">
      <nav className="flex flex-col gap-1">
        {links.map((l) => {
          const active = pathname === l.href || pathname?.startsWith(l.href + "/");
          return (
            <Link
              key={l.href}
              href={l.href}
              className={`flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition-colors ${
                active ? "bg-amber-400/10 text-amber-400" : "text-slate-300 hover:bg-slate-800 hover:text-slate-100"
              }`}
            >
              <l.icon size={18} />
              {l.label}
            </Link>
          );
        })}
      </nav>
    </aside>
  );
}
