import React from "react";

export default function AdminLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen bg-slate-950 text-slate-100">
      <header className="sticky top-0 z-40 border-b-2 border-red-500/50 bg-gradient-to-r from-red-950/80 via-slate-900/90 to-slate-900/80 backdrop-blur-md">
        <div className="mx-auto max-w-6xl px-6 py-2 text-[10px] font-extrabold uppercase tracking-[0.2em] text-red-400">
          Área Administrativa — Acesso Restrito — Sonic Vendas Premium
        </div>
      </header>
      <header className="sticky top-[36px] z-30 border-b border-slate-800 bg-slate-900/60 backdrop-blur-md">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-6 py-4">
          <a href="/admin" className="text-xl font-extrabold tracking-tight text-amber-400">Sonic Vendas</a>
          <nav className="flex gap-4 text-sm font-medium text-slate-300">
            <a href="/" className="hover:text-amber-400 transition-colors">Vitrine</a>
            <a href="/admin" className="hover:text-amber-400 transition-colors">Painel</a>
          </nav>
        </div>
      </header>
      <main className="mx-auto max-w-6xl px-6 py-8">{children}</main>
      <footer className="border-t border-slate-800 bg-slate-900/60 py-6 text-center text-xs text-slate-500">
        Sonic Vendas — Painel Administrativo • Dados sincronizados via PostgreSQL
      </footer>
    </div>
  );
}
