"use client";
import { useEffect, useState, useCallback } from "react";
import AdminNav from "./components/AdminNav";
import {
  CheckCircle,
  AlertTriangle,
  Trash2,
  Edit3,
  Plus,
  Image as ImageIcon,
  Tag,
  Package,
  ShoppingCart,
  RefreshCw,
  Save,
  Volume2,
  VolumeX,
  Wrench,
  Sparkles,
  FileCheck,
  CheckCircle2,
  XCircle,
  Bell,
  Eye,
  ExternalLink,
  Flame,
} from "lucide-react";
import { playSound, SOUND_DEFINITIONS, SoundEventType } from "@/lib/sounds";

export default function AdminPage() {
  const [token, setToken] = useState("");
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState<
    | "dashboard"
    | "products"
    | "categories"
    | "banners"
    | "orders"
    | "pix_receipts"
    | "social_orders"
    | "contact_ads"
    | "business_ads"
    | "ad_boosts"
    | "raffles"
    | "roulette"
    | "iptv"
    | "groups"
    | "announcements"
    | "appearance"
    | "future_features"
    | "settings"
  >("dashboard");

  useEffect(() => {
    const t = localStorage.getItem("sonic_admin_token") || "";
    setToken(t);
    setLoading(false);
  }, []);

  if (loading) return <div className="p-10 text-center text-slate-500">Carregando...</div>;
  if (!token) {
    if (typeof window !== "undefined") window.location.href = "/admin/login";
    return <div className="p-10 text-center text-slate-500">Redirecionando para login...</div>;
  }

  return (
    <div className="flex min-h-screen bg-slate-950 text-slate-100">
      <AdminNav />
      <div className="flex-1">
        <div className="border-b border-slate-800 bg-slate-900/40 px-8 py-4">
          <h2 className="text-xl font-bold text-amber-400">Painel Administrativo</h2>
          <p className="text-sm text-slate-400">Gerencie produtos, categorias, banners e pedidos.</p>
        </div>
        <div className="px-8 py-6">
          <div className="mb-6 flex gap-2">
            {([
              { key: "dashboard", label: "Dashboard" },
              { key: "pix_receipts", label: "📄 Comprovantes Pix" },
              { key: "social_orders", label: "📱 Pedidos Redes Sociais" },
              { key: "contact_ads", label: "👤 Divulgação Contatos" },
              { key: "business_ads", label: "💼 Divulgação Negócios" },
              { key: "ad_boosts", label: "⚡ Impulsionamentos" },
              { key: "products", label: "Produtos & Garantia" },
              { key: "categories", label: "Categorias" },
              { key: "orders", label: "Pedidos Loja" },
              { key: "raffles", label: "🎯 Sorteios & Cotas" },
              { key: "roulette", label: "🎡 Editar Roleta" },
              { key: "iptv", label: "📺 Gerenciar IPTV" },
              { key: "groups", label: "👥 Grupos" },
              { key: "announcements", label: "📢 Avisos do Site" },
              { key: "appearance", label: "🎨 Fontes, Cores & Fundo" },
              { key: "future_features", label: "🚀 Novidades & IA" },
              { key: "settings", label: "Configurações" },
            ] as const).map(({ key, label }) => (
              <button
                key={key}
                onClick={() => setTab(key)}
                className={`rounded-lg px-4 py-2 text-sm font-medium transition-all ${
                  tab === key ? "bg-amber-400 text-slate-950 shadow-lg shadow-amber-400/20" : "bg-slate-900 text-slate-300 hover:bg-slate-800 hover:text-slate-100"
                }`}
              >
                {label}
              </button>
            ))}
          </div>

          {tab === "dashboard" && <DashboardTab token={token} />}
          {tab === "products" && <ProductsTab token={token} />}
          {tab === "categories" && <CategoriesTab token={token} />}
          {tab === "banners" && <BannersTab token={token} />}
          {tab === "orders" && <OrdersTab token={token} />}
          {tab === "pix_receipts" && <PixReceiptsTab token={token} />}
          {tab === "social_orders" && <SocialOrdersTab token={token} />}
          {tab === "contact_ads" && <ContactAdsTab token={token} />}
          {tab === "business_ads" && <BusinessAdsTab token={token} />}
          {tab === "ad_boosts" && <AdBoostsTab token={token} />}
          {tab === "raffles" && <RafflesTab token={token} />}
          {tab === "roulette" && <RoulettePrizesTab token={token} />}
          {tab === "iptv" && <IptvTab token={token} />}
          {tab === "groups" && <GroupsTab token={token} />}
          {tab === "announcements" && <AnnouncementsTab token={token} />}
          {tab === "appearance" && <AppearanceAndSoundsTab token={token} />}
          {tab === "future_features" && <FutureFeaturesTab token={token} />}
          {tab === "settings" && <SettingsTab token={token} />}
        </div>
      </div>
    </div>
  );
}

function DashboardTab({ token }: { token: string }) {
  const [stats, setStats] = useState({ products: 0, categories: 0, orders: 0, banners: 0 });
  const [refreshKey, setRefreshKey] = useState(0);

  async function load() {
    try {
      const [p, c, o, b] = await Promise.all([
        fetch("/api/products").then((r) => r.json()),
        fetch("/api/categories").then((r) => r.json()),
        fetch("/api/orders").then((r) => r.json()),
        fetch("/api/banners").then((r) => r.json()),
      ]);
      setStats({
        products: p.data?.length || 0,
        categories: c.data?.length || 0,
        orders: o.data?.length || 0,
        banners: b.data?.length || 0,
      });
    } catch {
      // ignore
    }
  }

  useEffect(() => {
    load();
  }, [refreshKey]);

  return (
    <div className="rounded-3xl border border-slate-800 bg-slate-900/60 p-8 shadow-xl">
      <h3 className="mb-6 text-lg font-bold text-amber-400">Visão Geral</h3>
      <div className="grid gap-4 md:grid-cols-4">
        {[
          { label: "Produtos", value: stats.products, icon: Package },
          { label: "Categorias", value: stats.categories, icon: Tag },
          { label: "Pedidos", value: stats.orders, icon: ShoppingCart },
          { label: "Banners", value: stats.banners, icon: ImageIcon },
        ].map((s) => (
          <div key={s.label} className="rounded-2xl border border-slate-800 bg-slate-950 p-6 text-center shadow-lg">
            <s.icon className="mx-auto mb-3 text-amber-400" size={28} />
            <div className="text-3xl font-extrabold text-slate-100">{s.value}</div>
            <div className="mt-1 text-xs font-medium uppercase tracking-wide text-slate-500">{s.label}</div>
          </div>
        ))}
      </div>
      <div className="mt-8 rounded-2xl border border-slate-800 bg-slate-950 p-6">
        <h4 className="mb-3 text-sm font-bold text-slate-300">Instruções Rápidas</h4>
        <ul className="list-inside list-disc text-sm text-slate-400 space-y-1">
          <li>Use as abas acima para gerenciar produtos, categorias, banners e pedidos.</li>
          <li>Todas as alterações são salvas no banco de dados PostgreSQL e sincronizadas imediatamente.</li>
          <li>A vitrine pública atualiza automaticamente quando os dados mudam.</li>
        </ul>
      </div>
    </div>
  );
}

function ProductsTab({ token }: { token: string }) {
  const [items, setItems] = useState<any[]>([]);
  const [form, setForm] = useState({
    title: "",
    description: "",
    price: "",
    imageUrl: "",
    categoryId: "",
    isActive: true,
    isPromotion: false,
    discountPercent: 0,
    availability: "available",
    hasWarranty: "sim_loja",
    warrantyDuration: "90 dias de garantia oficial",
    returnConditions: "Troca garantida em até 7 dias corridos após o recebimento.",
  });
  const [editingId, setEditingId] = useState<number | null>(null);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState("");
  const [categories, setCategories] = useState<any[]>([]);
  const [iaSuggestion, setIaSuggestion] = useState({ description: "", price: "", category: "" });

  async function load() {
    try {
      const [p, c] = await Promise.all([
        fetch("/api/admin/products", { headers: { Authorization: `Bearer ${token}` } }).then((r) => r.json()),
        fetch("/api/categories").then((r) => r.json()),
      ]);
      // For admin products, we can reuse the public API or create a specific endpoint; for simplicity use public
      const prodRes = await fetch("/api/products").then((r) => r.json());
      setItems(prodRes.data || []);
      setCategories(c.data || []);
    } catch {
      // ignore
    }
  }

  useEffect(() => {
    load();
  }, [token]);

  async function handleSave(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    setMessage("");
    try {
      const payload = {
        title: form.title,
        description: form.description,
        price: parseFloat(form.price) || 0,
        imageUrl: form.imageUrl,
        categoryId: form.categoryId ? parseInt(form.categoryId, 10) : null,
        isActive: form.isActive,
        isPromotion: form.isPromotion,
        discountPercent: parseInt(String(form.discountPercent), 10) || 0,
        availability: form.availability,
        hasWarranty: form.hasWarranty,
        warrantyDuration: form.warrantyDuration,
        returnConditions: form.returnConditions,
      };

      if (editingId) {
        await fetch("/api/admin/products", {
          method: "PUT",
          headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
          body: JSON.stringify({ ...payload, id: editingId }),
        });
        setMessage("Produto atualizado com sucesso!");
      } else {
        await fetch("/api/admin/products", {
          method: "POST",
          headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
          body: JSON.stringify(payload),
        });
        setMessage("Produto criado com sucesso!");
      }
      setForm({
        title: "",
        description: "",
        price: "",
        imageUrl: "",
        categoryId: "",
        isActive: true,
        isPromotion: false,
        discountPercent: 0,
        availability: "available",
        hasWarranty: "sim_loja",
        warrantyDuration: "90 dias de garantia oficial",
        returnConditions: "Troca garantida em até 7 dias corridos após o recebimento.",
      });
      setEditingId(null);
      load();
    } catch {
      setMessage("Erro ao salvar produto.");
    } finally {
      setSaving(false);
    }
  }

  async function handleDelete(id: number) {
    if (!confirm("Confirma a exclusão?")) return;
    try {
      await fetch("/api/admin/products", {
        method: "DELETE",
        headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
        body: JSON.stringify({ id }),
      });
      load();
    } catch {
      alert("Erro ao excluir");
    }
  }

  return (
    <div className="space-y-8">
      <div className="rounded-3xl border border-slate-800 bg-slate-900/60 p-6 shadow-xl">
        <h3 className="mb-4 text-lg font-bold text-amber-400">{editingId ? "Editar Produto" : "Novo Produto"}</h3>
        <form onSubmit={handleSave} className="grid gap-4 md:grid-cols-2">
          <input type="text" placeholder="Título" value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} className="rounded-xl bg-slate-950 border border-slate-700 px-4 py-3 text-sm" required />
          <input type="text" placeholder="URL da Imagem (capa)" value={form.imageUrl} onChange={(e) => setForm({ ...form, imageUrl: e.target.value })} className="rounded-xl bg-slate-950 border border-slate-700 px-4 py-3 text-sm" required />
          <textarea placeholder="Descrição" value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} className="md:col-span-2 rounded-xl bg-slate-950 border border-slate-700 px-4 py-3 text-sm" required />
          <input type="number" placeholder="Preço" value={form.price} onChange={(e) => setForm({ ...form, price: e.target.value })} className="rounded-xl bg-slate-950 border border-slate-700 px-4 py-3 text-sm" required />
          <select value={form.categoryId} onChange={(e) => setForm({ ...form, categoryId: e.target.value })} className="rounded-xl bg-slate-950 border border-slate-700 px-4 py-3 text-sm">
            <option value="">Selecione categoria</option>
            {categories.map((c: any) => (
              <option key={c.id} value={c.id}>{c.name}</option>
            ))}
          </select>
          <div className="flex gap-3">
            <label className="flex items-center gap-2 text-sm text-slate-300"><input type="checkbox" checked={form.isActive} onChange={(e) => setForm({ ...form, isActive: e.target.checked })} /> Ativo</label>
            <label className="flex items-center gap-2 text-sm text-slate-300"><input type="checkbox" checked={form.isPromotion} onChange={(e) => setForm({ ...form, isPromotion: e.target.checked })} /> Promoção</label>
          </div>
          <input type="number" placeholder="% Desconto" value={form.discountPercent} onChange={(e) => setForm({ ...form, discountPercent: parseInt(e.target.value || "0", 10) })} className="rounded-xl bg-slate-950 border border-slate-700 px-4 py-3 text-sm" />
          <select value={form.availability} onChange={(e) => setForm({ ...form, availability: e.target.value })} className="rounded-xl bg-slate-950 border border-slate-700 px-4 py-3 text-sm">
            <option value="available">Disponível</option>
            <option value="out_of_stock">Esgotado</option>
            <option value="pre_order">Pré-venda</option>
          </select>

          <div>
            <label className="text-xs font-bold text-slate-300 block mb-1">Possui Garantia?</label>
            <select
              value={form.hasWarranty}
              onChange={(e) => setForm({ ...form, hasWarranty: e.target.value })}
              className="w-full rounded-xl bg-slate-950 border border-slate-700 px-4 py-3 text-sm text-white"
            >
              <option value="sim_loja">🛡️ Sim, Garantia da Loja Sonic Vendas</option>
              <option value="sim_fabricante">🏭 Sim, Garantia do Fabricante</option>
              <option value="sim_vitalicia">👑 Garantia Vitalícia</option>
              <option value="nao">❌ Não possui garantia adicional</option>
            </select>
          </div>

          <div>
            <label className="text-xs font-bold text-slate-300 block mb-1">Duração da Garantia</label>
            <input
              type="text"
              placeholder="Ex: 90 dias ou 1 ano"
              value={form.warrantyDuration}
              onChange={(e) => setForm({ ...form, warrantyDuration: e.target.value })}
              className="w-full rounded-xl bg-slate-950 border border-slate-700 px-4 py-3 text-sm text-white"
            />
          </div>

          <div className="md:col-span-2">
            <label className="text-xs font-bold text-slate-300 block mb-1">Condições de Troca e Devolução</label>
            <input
              type="text"
              placeholder="Ex: Troca garantida em até 7 dias corridos após o recebimento em caso de defeito."
              value={form.returnConditions}
              onChange={(e) => setForm({ ...form, returnConditions: e.target.value })}
              className="w-full rounded-xl bg-slate-950 border border-slate-700 px-4 py-3 text-sm text-white"
            />
          </div>

          <div className="md:col-span-2 flex gap-3">
            <button type="button" onClick={() => {
              const title = form.title.toLowerCase();
              let desc = "Produto premium da Sonic Vendas.";
              let price = "199.90";
              let cat = "";
              if (title.includes("netflix") || title.includes("streaming") || title.includes("filme") || title.includes("série")) {
                desc = "Serviço de streaming premium com acesso a milhares de filmes, séries e conteúdo exclusivo em alta definição. Ideal para entretenimento familiar.";
                price = "29.90";
              } else if (title.includes("fone") || title.includes("audio") || title.includes("música")) {
                desc = "Fone de ouvido de alta fidelidade com som cristalino, cancelamento de ruído e conforto para uso prolongado.";
                price = "399.90";
              } else if (title.includes("camiseta") || title.includes("roupa") || title.includes("moda")) {
                desc = "Camiseta premium 100% algodão com design exclusivo e estampas de alta durabilidade.";
                price = "89.90";
              } else if (title.includes("luminária") || title.includes("luz") || title.includes("led")) {
                desc = "Luminária inteligente com controle de intensidade, economia de energia e design moderno.";
                price = "129.90";
              } else if (title.includes("jogo") || title.includes("game") || title.includes("gamepass")) {
                desc = "Pacote completo de jogos digitais com atualizações automáticas e acesso a novos títulos mensalmente.";
                price = "49.90";
              }
              setIaSuggestion({ description: desc, price: price, category: cat });
              setForm({ ...form, description: desc, price: price });
            }} className="rounded-xl bg-violet-500 px-6 py-3 text-sm font-bold text-white hover:bg-violet-600 transition-all shadow-lg shadow-violet-500/20">Analisar com IA</button>
            <button type="submit" disabled={saving} className="rounded-xl bg-amber-400 px-6 py-3 text-sm font-bold text-slate-950 hover:bg-amber-300 disabled:opacity-60 transition-all shadow-lg shadow-amber-400/20">{saving ? "Salvando..." : editingId ? "Atualizar" : "Criar Produto"}</button>
            {editingId && <button type="button" onClick={() => { setEditingId(null); setForm({ title: "", description: "", price: "", imageUrl: "", categoryId: "", isActive: true, isPromotion: false, discountPercent: 0, availability: "available", hasWarranty: "sim_loja", warrantyDuration: "90 dias de garantia oficial", returnConditions: "Troca garantida em até 7 dias corridos após o recebimento." }); }} className="rounded-xl bg-slate-800 px-6 py-3 text-sm font-bold text-slate-200 hover:bg-slate-700 transition-all">Cancelar</button>}
          </div>
        </form>
        {message && <div className="mt-4 rounded-xl border border-amber-400/30 bg-amber-400/10 px-4 py-3 text-sm text-amber-300">{message}</div>}
        {iaSuggestion.description && (
          <div className="mt-4 rounded-xl border border-violet-400/30 bg-violet-500/10 px-4 py-3 text-sm text-violet-300">
            <p className="font-bold">🔮 Sugestão da IA:</p>
            <p className="mt-1">Categoria sugerida: <span className="font-bold">{form.categoryId ? categories.find((c: any) => c.id === parseInt(form.categoryId, 10))?.name || "Definir" : "Definir"}</span></p>
            <p>Descrição sugerida: <span className="font-bold">{iaSuggestion.description}</span></p>
            <p>Preço sugerido: <span className="font-bold">R$ {iaSuggestion.price}</span></p>
          </div>
        )}
      </div>

      <div className="rounded-3xl border border-slate-800 bg-slate-900/60 p-6 shadow-xl">
        <h3 className="mb-4 text-lg font-bold text-amber-400">Produtos Cadastrados</h3>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {items.map((item: any) => (
            <div key={item.id} className="rounded-2xl border border-slate-800 bg-slate-950 p-4 shadow-lg">
              <img src={item.imageUrl} alt={item.title} className="mb-3 h-40 w-full rounded-xl object-cover bg-slate-900" onError={(e) => { (e.target as HTMLImageElement).src = "https://placehold.co/600x400?text=Sem+Imagem"; }} />
              <h4 className="text-base font-bold text-slate-100">{item.title}</h4>
              <p className="text-xs text-slate-500">{item.categoryName || "Sem categoria"}</p>
              <p className="mt-2 text-sm text-slate-400">{item.description?.slice(0, 80)}...</p>
              <div className="mt-3 flex items-center justify-between">
                <span className="text-lg font-extrabold text-amber-400">R$ {Number(item.price).toFixed(2)}</span>
                <div className="flex gap-2">
                  <button onClick={() => { setEditingId(item.id); setForm({ title: item.title, description: item.description, price: String(item.price), imageUrl: item.imageUrl, categoryId: String(item.categoryId || ""), isActive: item.isActive, isPromotion: item.isPromotion, discountPercent: item.discountPercent || 0, availability: item.availability, hasWarranty: item.hasWarranty || "sim_loja", warrantyDuration: item.warrantyDuration || "90 dias de garantia oficial", returnConditions: item.returnConditions || "Troca garantida em até 7 dias corridos após o recebimento." }); }} className="rounded-lg bg-slate-800 px-3 py-1.5 text-xs font-bold text-slate-300 hover:bg-slate-700 transition-colors"><Edit3 size={14} /></button>
                  <button onClick={() => handleDelete(item.id)} className="rounded-lg bg-red-500/20 px-3 py-1.5 text-xs font-bold text-red-300 hover:bg-red-500/30 transition-colors"><Trash2 size={14} /></button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function CategoriesTab({ token }: { token: string }) {
  const [items, setItems] = useState<any[]>([]);
  const [form, setForm] = useState({ name: "", slug: "", description: "", isActive: true });
  const [editingId, setEditingId] = useState<number | null>(null);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState("");

  async function load() {
    try {
      const res = await fetch("/api/categories").then((r) => r.json());
      setItems(res.data || []);
    } catch {
      // ignore
    }
  }
  useEffect(() => { load(); }, []);

  async function handleSave(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    setMessage("");
    try {
      if (editingId) {
        await fetch("/api/admin/categories", {
          method: "PUT",
          headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
          body: JSON.stringify({ ...form, id: editingId }),
        });
      } else {
        await fetch("/api/admin/categories", {
          method: "POST",
          headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
          body: JSON.stringify(form),
        });
      }
      setMessage(editingId ? "Atualizado!" : "Criado!");
      setForm({ name: "", slug: "", description: "", isActive: true });
      setEditingId(null);
      load();
    } catch {
      setMessage("Erro ao salvar.");
    } finally {
      setSaving(false);
    }
  }

  async function handleDelete(id: number) {
    if (!confirm("Confirma exclusão?")) return;
    await fetch("/api/admin/categories", { method: "DELETE", headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" }, body: JSON.stringify({ id }) });
    load();
  }

  return (
    <div className="space-y-8">
      <form onSubmit={handleSave} className="rounded-3xl border border-slate-800 bg-slate-900/60 p-6 shadow-xl space-y-4">
        <h3 className="text-lg font-bold text-amber-400">{editingId ? "Editar Categoria" : "Nova Categoria"}</h3>
        <div className="grid gap-4 md:grid-cols-3">
          <input placeholder="Nome" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className="rounded-xl bg-slate-950 border border-slate-700 px-4 py-3 text-sm" required />
          <input placeholder="Slug" value={form.slug} onChange={(e) => setForm({ ...form, slug: e.target.value })} className="rounded-xl bg-slate-950 border border-slate-700 px-4 py-3 text-sm" />
          <label className="flex items-center gap-2 text-sm text-slate-300"><input type="checkbox" checked={form.isActive} onChange={(e) => setForm({ ...form, isActive: e.target.checked })} /> Ativa</label>
        </div>
        <textarea placeholder="Descrição" value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} className="w-full rounded-xl bg-slate-950 border border-slate-700 px-4 py-3 text-sm" />
        <div className="flex gap-3">
          <button type="submit" disabled={saving} className="rounded-xl bg-amber-400 px-6 py-3 text-sm font-bold text-slate-950 hover:bg-amber-300 disabled:opacity-60">{saving ? "Salvando..." : editingId ? "Atualizar" : "Criar"}</button>
          {editingId && <button type="button" onClick={() => { setEditingId(null); setForm({ name: "", slug: "", description: "", isActive: true }); }} className="rounded-xl bg-slate-800 px-6 py-3 text-sm font-bold text-slate-200 hover:bg-slate-700">Cancelar</button>}
        </div>
        {message && <div className="rounded-xl border border-amber-400/30 bg-amber-400/10 px-4 py-3 text-sm text-amber-300">{message}</div>}
      </form>
      <div className="rounded-3xl border border-slate-800 bg-slate-900/60 p-6 shadow-xl">
        <h3 className="mb-4 text-lg font-bold text-amber-400">Categorias</h3>
        <div className="grid gap-4 md:grid-cols-3">
          {items.map((item: any) => (
            <div key={item.id} className="rounded-2xl border border-slate-800 bg-slate-950 p-4 shadow-lg">
              <h4 className="text-base font-bold text-slate-100">{item.name}</h4>
              <p className="text-xs text-slate-500">{item.slug}</p>
              <div className="mt-3 flex gap-2">
                <button onClick={() => { setEditingId(item.id); setForm({ name: item.name, slug: item.slug, description: item.description, isActive: item.isActive }); }} className="rounded-lg bg-slate-800 px-3 py-1.5 text-xs font-bold text-slate-300 hover:bg-slate-700"><Edit3 size={14} /></button>
                <button onClick={() => handleDelete(item.id)} className="rounded-lg bg-red-500/20 px-3 py-1.5 text-xs font-bold text-red-300 hover:bg-red-500/30"><Trash2 size={14} /></button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function BannersTab({ token }: { token: string }) {
  const [items, setItems] = useState<any[]>([]);
  const [form, setForm] = useState({ title: "", subtitle: "", imageUrl: "", linkUrl: "", isActive: true, order: 0 });
  const [editingId, setEditingId] = useState<number | null>(null);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState("");

  async function load() {
    try {
      const res = await fetch("/api/banners").then((r) => r.json());
      setItems(res.data || []);
    } catch { /* ignore */ }
  }
  useEffect(() => { load(); }, []);

  async function handleSave(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    setMessage("");
    try {
      if (editingId) {
        await fetch("/api/admin/banners", {
          method: "PUT",
          headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
          body: JSON.stringify({ ...form, id: editingId }),
        });
      } else {
        await fetch("/api/admin/banners", {
          method: "POST",
          headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
          body: JSON.stringify(form),
        });
      }
      setMessage(editingId ? "Atualizado!" : "Criado!");
      setForm({ title: "", subtitle: "", imageUrl: "", linkUrl: "", isActive: true, order: 0 });
      setEditingId(null);
      load();
    } catch {
      setMessage("Erro ao salvar.");
    } finally {
      setSaving(false);
    }
  }

  async function handleDelete(id: number) {
    if (!confirm("Confirma exclusão?")) return;
    await fetch("/api/admin/banners", { method: "DELETE", headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" }, body: JSON.stringify({ id }) });
    load();
  }

  return (
    <div className="space-y-8">
      <form onSubmit={handleSave} className="rounded-3xl border border-slate-800 bg-slate-900/60 p-6 shadow-xl space-y-4">
        <h3 className="text-lg font-bold text-amber-400">{editingId ? "Editar Banner" : "Novo Banner"}</h3>
        <div className="grid gap-4 md:grid-cols-3">
          <input placeholder="Título" value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} className="rounded-xl bg-slate-950 border border-slate-700 px-4 py-3 text-sm" required />
          <input placeholder="Subtítulo" value={form.subtitle} onChange={(e) => setForm({ ...form, subtitle: e.target.value })} className="rounded-xl bg-slate-950 border border-slate-700 px-4 py-3 text-sm" />
          <input placeholder="URL da Imagem" value={form.imageUrl} onChange={(e) => setForm({ ...form, imageUrl: e.target.value })} className="rounded-xl bg-slate-950 border border-slate-700 px-4 py-3 text-sm" required />
          <input placeholder="Link (URL)" value={form.linkUrl} onChange={(e) => setForm({ ...form, linkUrl: e.target.value })} className="md:col-span-2 rounded-xl bg-slate-950 border border-slate-700 px-4 py-3 text-sm" />
          <div className="flex gap-3">
            <label className="flex items-center gap-2 text-sm text-slate-300"><input type="checkbox" checked={form.isActive} onChange={(e) => setForm({ ...form, isActive: e.target.checked })} /> Ativo</label>
          </div>
          <input type="number" placeholder="Ordem" value={form.order} onChange={(e) => setForm({ ...form, order: parseInt(e.target.value || "0", 10) })} className="rounded-xl bg-slate-950 border border-slate-700 px-4 py-3 text-sm" />
        </div>
        <div className="flex gap-3">
          <button type="submit" disabled={saving} className="rounded-xl bg-amber-400 px-6 py-3 text-sm font-bold text-slate-950 hover:bg-amber-300 disabled:opacity-60">{saving ? "Salvando..." : editingId ? "Atualizar" : "Criar"}</button>
          {editingId && <button type="button" onClick={() => { setEditingId(null); setForm({ title: "", subtitle: "", imageUrl: "", linkUrl: "", isActive: true, order: 0 }); }} className="rounded-xl bg-slate-800 px-6 py-3 text-sm font-bold text-slate-200 hover:bg-slate-700">Cancelar</button>}
        </div>
        {message && <div className="rounded-xl border border-amber-400/30 bg-amber-400/10 px-4 py-3 text-sm text-amber-300">{message}</div>}
      </form>
      <div className="rounded-3xl border border-slate-800 bg-slate-900/60 p-6 shadow-xl">
        <h3 className="mb-4 text-lg font-bold text-amber-400">Banners</h3>
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {items.map((item: any) => (
            <div key={item.id} className="rounded-2xl border border-slate-800 bg-slate-950 p-4 shadow-lg">
              <img src={item.imageUrl} alt={item.title} className="mb-3 h-32 w-full rounded-xl object-cover bg-slate-900" onError={(e) => { (e.target as HTMLImageElement).src = "https://placehold.co/600x300?text=Sem+Banner"; }} />
              <h4 className="text-base font-bold text-slate-100">{item.title}</h4>
              <p className="text-xs text-slate-500">{item.subtitle}</p>
              <div className="mt-3 flex gap-2">
                <button onClick={() => { setEditingId(item.id); setForm({ title: item.title, subtitle: item.subtitle, imageUrl: item.imageUrl, linkUrl: item.linkUrl, isActive: item.isActive, order: item.order || 0 }); }} className="rounded-lg bg-slate-800 px-3 py-1.5 text-xs font-bold text-slate-300 hover:bg-slate-700"><Edit3 size={14} /></button>
                <button onClick={() => handleDelete(item.id)} className="rounded-lg bg-red-500/20 px-3 py-1.5 text-xs font-bold text-red-300 hover:bg-red-500/30"><Trash2 size={14} /></button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function OrdersTab({ token }: { token: string }) {
  const [items, setItems] = useState<any[]>([]);

  async function load() {
    try {
      const res = await fetch("/api/admin/orders", { headers: { Authorization: `Bearer ${token}` } }).then((r) => r.json());
      setItems(res.data || []);
    } catch { /* ignore */ }
  }

  useEffect(() => { load(); }, [token]);

  return (
    <div className="rounded-3xl border border-slate-800 bg-slate-900/60 p-6 shadow-xl">
      <h3 className="mb-4 text-lg font-bold text-amber-400">Pedidos</h3>
      <table className="w-full text-sm text-slate-300">
        <thead className="border-b border-slate-800 text-left text-xs uppercase tracking-wider text-slate-500">
          <tr>
            <th className="py-3">ID</th>
            <th>Cliente</th>
            <th>Email</th>
            <th>Total</th>
            <th>Status</th>
            <th>Pago</th>
            <th>Data</th>
          </tr>
        </thead>
        <tbody>
          {items.map((item: any) => (
            <tr key={item.id} className="border-b border-slate-800 hover:bg-slate-800/40 transition-colors">
              <td className="py-3 font-mono text-xs">#{item.id}</td>
              <td>{item.customerName}</td>
              <td>{item.customerEmail}</td>
              <td className="font-bold text-amber-400">R$ {Number(item.totalAmount).toFixed(2)}</td>
              <td><span className={`rounded-full px-2.5 py-0.5 text-xs font-bold ${item.status === "approved" ? "bg-green-500/20 text-green-300" : item.status === "pending" ? "bg-amber-400/20 text-amber-300" : "bg-red-500/20 text-red-300"}`}>{item.status}</span></td>
              <td>{item.isPaid ? <span className="text-green-400 text-xs font-bold">Sim</span> : <span className="text-red-400 text-xs font-bold">Não</span>}</td>
              <td className="text-xs text-slate-500">{new Date(item.createdAt).toLocaleString("pt-BR")}</td>
            </tr>
          ))}
        </tbody>
      </table>
      {items.length === 0 && <div className="mt-6 text-sm text-slate-500">Nenhum pedido registrado ainda.</div>}
    </div>
  );
}

function SettingsTab({ token }: { token: string }) {
  const [mpAccessToken, setMpAccessToken] = useState("");
  const [mpPublicKey, setMpPublicKey] = useState("");
  const [mpWebhookUrl, setMpWebhookUrl] = useState("");
  const [supportPhone, setSupportPhone] = useState("75981558007");
  const [saved, setSaved] = useState(false);

  function handleSave() {
    setSaved(true);
    setTimeout(() => setSaved(false), 3000);
  }

  return (
    <div className="space-y-6">
      {/* Download Full Project ZIP Card */}
      <div className="rounded-3xl border-2 border-amber-400/50 bg-gradient-to-r from-amber-950/40 via-slate-900 to-slate-950 p-6 shadow-xl">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
          <div>
            <span className="text-[10px] font-black uppercase tracking-widest text-amber-400">PACOTE COMPLETO</span>
            <h3 className="text-xl font-black text-white">📦 Baixar Projeto Completo em ZIP</h3>
            <p className="text-xs text-slate-400 mt-1">
              Baixe o código-fonte completo com todas as APIs, banco de dados, painel e loja prontos para hospedar em qualquer servidor.
            </p>
          </div>
          <a
            href="/api/download/zip"
            download="sonic-vendas-completo.zip"
            className="flex shrink-0 items-center gap-2 rounded-2xl bg-amber-400 px-6 py-3.5 text-xs font-black uppercase text-slate-950 hover:bg-amber-300 transition-all shadow-lg shadow-amber-400/20"
          >
            Baixar ZIP Agora (.zip)
          </a>
        </div>
      </div>

      <div className="rounded-3xl border border-slate-800 bg-slate-900/60 p-6 shadow-xl">
        <h3 className="mb-4 text-lg font-bold text-amber-400">Contato e Suporte</h3>
        <div className="space-y-3 text-sm text-slate-300">
          <p><span className="font-bold text-amber-400">Telefone:</span> <span className="font-mono text-base">75981558007</span></p>
          <p>Entre em contato para suporte, dúvidas ou para configurar pagamentos.</p>
        </div>
      </div>

      <div className="rounded-3xl border border-slate-800 bg-slate-900/60 p-6 shadow-xl">
        <h3 className="mb-4 text-lg font-bold text-amber-400">Configuração do Mercado Pago</h3>
        <p className="mb-6 text-sm text-slate-400">Preencha os dados abaixo e configure no arquivo <code className="bg-slate-950 px-1 rounded">.env</code> e no painel do Mercado Pago.</p>

        <div className="space-y-4">
          <div>
            <label htmlFor="mp_token" className="mb-1 block text-sm font-bold text-slate-300">Access Token (Mercado Pago)</label>
            <input id="mp_token" type="password" value={mpAccessToken} onChange={(e) => setMpAccessToken(e.target.value)} className="w-full rounded-xl bg-slate-950 border border-slate-700 px-4 py-3 text-sm text-slate-100 focus:border-amber-400 focus:outline-none" placeholder="APP_USR-..." />
            <p className="mt-1 text-xs text-slate-500">Cole o Access Token gerado no painel de desenvolvedores do Mercado Pago.</p>
          </div>

          <div>
            <label htmlFor="mp_key" className="mb-1 block text-sm font-bold text-slate-300">Public Key (Mercado Pago)</label>
            <input id="mp_key" type="text" value={mpPublicKey} onChange={(e) => setMpPublicKey(e.target.value)} className="w-full rounded-xl bg-slate-950 border border-slate-700 px-4 py-3 text-sm text-slate-100 focus:border-amber-400 focus:outline-none" placeholder="APP_USR-...-PUB" />
            <p className="mt-1 text-xs text-slate-500">Chave pública para integração no frontend.</p>
          </div>

          <div>
            <label htmlFor="mp_webhook" className="mb-1 block text-sm font-bold text-slate-300">URL do Webhook</label>
            <input id="mp_webhook" type="text" value={mpWebhookUrl} onChange={(e) => setMpWebhookUrl(e.target.value)} className="w-full rounded-xl bg-slate-950 border border-slate-700 px-4 py-3 text-sm text-slate-100 focus:border-amber-400 focus:outline-none" placeholder="https://seu-dominio.com/api/webhook/mercadopago" />
            <p className="mt-1 text-xs text-slate-500">Configure esta URL no painel do Mercado Pago para receber notificações de pagamento.</p>
          </div>

          <div>
            <label htmlFor="mp_phone" className="mb-1 block text-sm font-bold text-slate-300">Telefone de Suporte</label>
            <input id="mp_phone" type="text" value={supportPhone} onChange={(e) => setSupportPhone(e.target.value)} className="w-full rounded-xl bg-slate-950 border border-slate-700 px-4 py-3 text-sm text-slate-100 focus:border-amber-400 focus:outline-none" />
          </div>
        </div>

        <button onClick={handleSave} className="mt-6 rounded-xl bg-amber-400 px-6 py-3 text-sm font-extrabold text-slate-950 hover:bg-amber-300 transition-all shadow-lg shadow-amber-400/20">Salvar Configurações</button>

        {saved && (
          <div className="mt-4 rounded-xl border border-green-500/30 bg-green-500/10 px-4 py-3 text-sm text-green-300">
            Configurações salvas! Lembre-se de atualizar o arquivo <code className="bg-slate-950 px-1 rounded">.env</code> e configurar o webhook no Mercado Pago.
          </div>
        )}
      </div>
    </div>
  );
}

function GroupsTab({ token }: { token: string }) {
  const [freeMinutes, setFreeMinutes] = useState(60);
  const [premiumPrices, setPremiumPrices] = useState([
    { days: 7, price: "9.99" },
    { days: 15, price: "27.00" },
    { days: 30, price: "30.00" },
    { days: 45, price: "45.00" },
    { days: 180, price: "360.00" },
  ]);

  return (
    <div className="space-y-6">
      <div className="rounded-3xl border border-slate-800 bg-slate-900/60 p-6 shadow-xl">
        <h3 className="mb-4 text-lg font-bold text-amber-400">Configuração de Cortesia e Premium</h3>
        <div className="grid gap-4 md:grid-cols-2">
          <div>
            <label htmlFor="freeMinutes" className="mb-1 block text-sm font-bold text-slate-300">Tempo de Cortesia Grátis (minutos)</label>
            <input id="freeMinutes" type="number" value={freeMinutes} onChange={(e) => setFreeMinutes(parseInt(e.target.value || "0", 10))} className="w-full rounded-xl bg-slate-950 border border-slate-700 px-4 py-3 text-sm text-slate-100 focus:border-amber-400 focus:outline-none" />
            <p className="mt-1 text-xs text-slate-500">Defina quantos minutos o grupo ficará no topo como cortesia antes do serviço premium.</p>
          </div>
          <div>
            <h4 className="mb-3 text-sm font-bold text-amber-400">Serviços Premium Disponíveis</h4>
            <div className="grid grid-cols-2 gap-2">
              {premiumPrices.map((p) => (
                <div key={p.days} className="rounded-xl bg-slate-950 border border-slate-800 px-3 py-2 text-xs">
                  <span className="font-extrabold text-amber-400">{p.days} dias</span>
                  <span className="block text-slate-400">R$ {p.price}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function IptvTab({ token }: { token: string }) {
  const [requests, setRequests] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedItem, setSelectedItem] = useState<any | null>(null);

  // Form states for releasing IPTV credentials
  const [serverUrl, setServerUrl] = useState("http://sonic.iptvplay.com:8080");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [m3uUrl, setM3uUrl] = useState("");
  const [instructions, setInstructions] = useState("Use o aplicativo IPTV Smarters Pro com os dados acima.");
  const [hours, setHours] = useState(12);
  const [saving, setSaving] = useState(false);
  const [feedback, setFeedback] = useState("");

  async function load() {
    setLoading(true);
    try {
      const res = await fetch("/api/admin/iptv", {
        headers: { Authorization: `Bearer ${token}` },
      });
      const data = await res.json();
      if (data.ok) {
        setRequests(data.data || []);
      }
    } catch {
      // ignore
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
  }, [token]);

  function openReleaseModal(item: any) {
    setSelectedItem(item);
    setServerUrl(item.serverUrl || "http://sonic.iptvplay.com:8080");
    setUsername(item.username || `sonic_${item.id}_${Math.floor(100 + Math.random() * 900)}`);
    setPassword(item.password || `pass${Math.floor(1000 + Math.random() * 9000)}`);
    setM3uUrl(item.m3uUrl || `http://sonic.iptvplay.com:8080/get.php?username=sonic_${item.id}&password=pass&type=m3u_plus`);
    setInstructions(item.instructions || "Use o aplicativo IPTV Smarters Pro ou XCIPTV com os dados acima.");
    setHours(item.hours || 12);
    setFeedback("");
  }

  async function handleRelease(action: "approve" | "extend" | "revoke" | "expire") {
    if (!selectedItem) return;
    setSaving(true);
    setFeedback("");
    try {
      const res = await fetch(`/api/admin/iptv/${selectedItem.id}`, {
        method: "PUT",
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          action,
          serverUrl,
          username,
          password,
          m3uUrl,
          instructions,
          hours,
        }),
      });
      const data = await res.json();
      if (data.ok) {
        setFeedback("✅ Operação realizada com sucesso!");
        load();
        setTimeout(() => setSelectedItem(null), 1500);
      } else {
        setFeedback(data.error || "Erro ao salvar.");
      }
    } catch {
      setFeedback("Erro de conexão ao processar.");
    } finally {
      setSaving(false);
    }
  }

  async function handleDelete(id: number) {
    if (!confirm("Tem certeza que deseja excluir esta solicitação?")) return;
    try {
      await fetch(`/api/admin/iptv/${id}`, {
        method: "DELETE",
        headers: { Authorization: `Bearer ${token}` },
      });
      load();
    } catch {
      alert("Erro ao excluir.");
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between rounded-3xl border border-cyan-500/30 bg-gradient-to-r from-blue-950/80 to-slate-900/90 p-6 shadow-xl">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-2xl">📺</span>
            <h3 className="text-xl font-black text-cyan-400">Gerenciar Solicitações de IPTV (12 Horas)</h3>
          </div>
          <p className="mt-1 text-xs text-slate-300">
            Libere acessos individuais de 12 horas, cadastre credenciais (servidor, usuário, senha) e acompanhe a expiração.
          </p>
        </div>

        <button
          onClick={load}
          className="rounded-xl border border-cyan-400/40 bg-blue-900/60 px-4 py-2 text-xs font-bold text-cyan-300 hover:bg-cyan-500 hover:text-slate-950 transition-colors"
        >
          🔄 Atualizar Lista
        </button>
      </div>

      {/* Requests Table */}
      <div className="overflow-hidden rounded-3xl border border-slate-800 bg-slate-900/60 shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm text-slate-300">
            <thead className="border-b border-slate-800 bg-slate-950 text-xs font-bold uppercase tracking-wider text-cyan-400">
              <tr>
                <th className="px-6 py-4">ID</th>
                <th className="px-6 py-4">Cliente</th>
                <th className="px-6 py-4">Contato (WhatsApp)</th>
                <th className="px-6 py-4">Status</th>
                <th className="px-6 py-4">Expiração (12h)</th>
                <th className="px-6 py-4">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-medium">
              {requests.map((item) => (
                <tr key={item.id} className="hover:bg-slate-800/30 transition-colors">
                  <td className="px-6 py-4 font-mono text-xs text-slate-400">#{item.id}</td>
                  <td className="px-6 py-4">
                    <div className="font-bold text-white">{item.customerName}</div>
                    <div className="text-xs text-slate-400">{item.customerEmail}</div>
                  </td>
                  <td className="px-6 py-4">
                    <a
                      href={`https://wa.me/55${item.customerPhone.replace(/\D/g, "")}`}
                      target="_blank"
                      rel="noreferrer"
                      className="inline-flex items-center gap-1 font-mono text-xs text-emerald-400 hover:underline"
                    >
                      {item.customerPhone}
                    </a>
                  </td>
                  <td className="px-6 py-4">
                    {item.status === "approved" && (
                      <span className="inline-flex items-center gap-1.5 rounded-full bg-emerald-500/20 px-3 py-1 text-xs font-bold text-emerald-300 border border-emerald-500/30">
                        <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 animate-pulse" /> Ativo (12h)
                      </span>
                    )}
                    {item.status === "pending" && (
                      <span className="inline-flex items-center gap-1.5 rounded-full bg-amber-500/20 px-3 py-1 text-xs font-bold text-amber-300 border border-amber-500/30">
                        ⏳ Pendente
                      </span>
                    )}
                    {item.status === "expired" && (
                      <span className="rounded-full bg-slate-800 px-3 py-1 text-xs font-bold text-slate-400 border border-slate-700">
                        🔒 Expirado
                      </span>
                    )}
                    {item.status === "revoked" && (
                      <span className="rounded-full bg-rose-500/20 px-3 py-1 text-xs font-bold text-rose-300 border border-rose-500/30">
                        🚫 Revogado
                      </span>
                    )}
                  </td>
                  <td className="px-6 py-4 text-xs">
                    {item.expiresAt ? (
                      <div>
                        <div className="font-bold text-white">
                          {new Date(item.expiresAt).toLocaleString("pt-BR")}
                        </div>
                        <div className="text-[11px] text-slate-500">
                          {new Date(item.expiresAt) > new Date() ? "Em andamento" : "Finalizado"}
                        </div>
                      </div>
                    ) : (
                      <span className="text-slate-500">— Não liberado</span>
                    )}
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => openReleaseModal(item)}
                        className="rounded-xl bg-gradient-to-r from-blue-600 to-cyan-500 px-3 py-1.5 text-xs font-black text-slate-950 hover:from-blue-500 hover:to-cyan-400 transition-all shadow-md"
                      >
                        {item.status === "approved" ? "Editar Credenciais" : "⚡ Liberar Acesso"}
                      </button>
                      <button
                        onClick={() => handleDelete(item.id)}
                        className="rounded-xl bg-rose-500/10 border border-rose-500/20 px-2.5 py-1.5 text-xs text-rose-400 hover:bg-rose-500 hover:text-white transition-all"
                      >
                        Excluir
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>

          {requests.length === 0 && !loading && (
            <div className="p-12 text-center text-slate-500">
              Nenhuma solicitação de IPTV recebida ainda.
            </div>
          )}
        </div>
      </div>

      {/* Modal for Releasing / Editing IPTV credentials */}
      {selectedItem && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 backdrop-blur-md">
          <div className="relative w-full max-w-2xl rounded-3xl border-2 border-cyan-400/50 bg-slate-950 p-6 md:p-8 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-4">
              <div>
                <span className="text-[10px] font-black uppercase tracking-widest text-cyan-400">
                  LIBERAÇÃO DE ACESSO IPTV 12 HORAS
                </span>
                <h4 className="text-xl font-black text-white">{selectedItem.customerName}</h4>
                <p className="text-xs text-slate-400">
                  {selectedItem.customerEmail} • {selectedItem.customerPhone}
                </p>
              </div>
              <button
                onClick={() => setSelectedItem(null)}
                className="rounded-full bg-slate-800 p-2 text-slate-400 hover:bg-slate-700 hover:text-white"
              >
                ✕
              </button>
            </div>

            <div className="mt-6 space-y-4">
              <div className="grid gap-4 md:grid-cols-2">
                <div>
                  <label className="mb-1 block text-xs font-bold uppercase text-cyan-300">
                    Servidor / DNS (URL)
                  </label>
                  <input
                    type="text"
                    value={serverUrl}
                    onChange={(e) => setServerUrl(e.target.value)}
                    className="w-full rounded-xl border border-slate-700 bg-slate-900 px-3 py-2.5 text-xs text-white focus:border-cyan-400 focus:outline-none"
                    placeholder="http://dns.provedor.com:8080"
                  />
                </div>

                <div>
                  <label className="mb-1 block text-xs font-bold uppercase text-cyan-300">
                    Tempo de Duração (Horas)
                  </label>
                  <input
                    type="number"
                    value={hours}
                    onChange={(e) => setHours(parseInt(e.target.value || "12", 10))}
                    className="w-full rounded-xl border border-slate-700 bg-slate-900 px-3 py-2.5 text-xs text-white focus:border-cyan-400 focus:outline-none"
                  />
                </div>
              </div>

              <div className="grid gap-4 md:grid-cols-2">
                <div>
                  <label className="mb-1 block text-xs font-bold uppercase text-cyan-300">
                    Usuário
                  </label>
                  <input
                    type="text"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    className="w-full rounded-xl border border-slate-700 bg-slate-900 px-3 py-2.5 text-xs text-white focus:border-cyan-400 focus:outline-none"
                    placeholder="usuario123"
                  />
                </div>

                <div>
                  <label className="mb-1 block text-xs font-bold uppercase text-cyan-300">
                    Senha
                  </label>
                  <input
                    type="text"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full rounded-xl border border-slate-700 bg-slate-900 px-3 py-2.5 text-xs text-white focus:border-cyan-400 focus:outline-none"
                    placeholder="senha123"
                  />
                </div>
              </div>

              <div>
                <label className="mb-1 block text-xs font-bold uppercase text-cyan-300">
                  Link da Playlist M3U (Opcional)
                </label>
                <input
                  type="text"
                  value={m3uUrl}
                  onChange={(e) => setM3uUrl(e.target.value)}
                  className="w-full rounded-xl border border-slate-700 bg-slate-900 px-3 py-2.5 text-xs text-white focus:border-cyan-400 focus:outline-none"
                  placeholder="http://dns.provedor.com:8080/get.php?username=..."
                />
              </div>

              <div>
                <label className="mb-1 block text-xs font-bold uppercase text-cyan-300">
                  Instruções para o Cliente
                </label>
                <textarea
                  value={instructions}
                  onChange={(e) => setInstructions(e.target.value)}
                  rows={2}
                  className="w-full rounded-xl border border-slate-700 bg-slate-900 px-3 py-2 text-xs text-white focus:border-cyan-400 focus:outline-none"
                  placeholder="Ex: Baixe o app IPTV Smarters e insira os dados acima..."
                />
              </div>

              {feedback && (
                <div className="rounded-xl border border-cyan-500/40 bg-cyan-950/40 p-3 text-xs font-bold text-cyan-300">
                  {feedback}
                </div>
              )}

              <div className="flex flex-wrap items-center justify-between gap-3 pt-4 border-t border-slate-800">
                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={() => handleRelease("approve")}
                    disabled={saving}
                    className="rounded-xl bg-gradient-to-r from-emerald-500 to-cyan-400 px-5 py-2.5 text-xs font-black uppercase text-slate-950 hover:brightness-110 shadow-lg shadow-emerald-500/20 disabled:opacity-60"
                  >
                    ⚡ Salvar & Liberar 12 Horas
                  </button>

                  <button
                    type="button"
                    onClick={() => handleRelease("extend")}
                    disabled={saving}
                    className="rounded-xl bg-blue-900/60 border border-blue-700 px-4 py-2.5 text-xs font-bold text-cyan-300 hover:bg-blue-800"
                  >
                    +12h Adicionais
                  </button>
                </div>

                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={() => handleRelease("revoke")}
                    disabled={saving}
                    className="rounded-xl bg-rose-500/20 border border-rose-500/30 px-3 py-2.5 text-xs font-bold text-rose-300 hover:bg-rose-500 hover:text-white"
                  >
                    Revogar Acesso
                  </button>
                  <button
                    type="button"
                    onClick={() => setSelectedItem(null)}
                    className="rounded-xl bg-slate-800 px-4 py-2.5 text-xs font-bold text-slate-300 hover:bg-slate-700"
                  >
                    Fechar
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function RafflesTab({ token }: { token: string }) {
  const [raffles, setRaffles] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [editingId, setEditingId] = useState<number | null>(null);

  // Form states
  const [title, setTitle] = useState("");
  const [imageUrl, setImageUrl] = useState("https://images.unsplash.com/photo-1695048133142-1a20484d2569?w=800&q=80");
  const [category, setCategory] = useState("celular");
  const [totalNumbers, setTotalNumbers] = useState(1000);
  const [pricePerNumber, setPricePerNumber] = useState("0.10");
  const [description, setDescription] = useState("Concorra a este incrível prêmio!");
  const [drawDate, setDrawDate] = useState("");
  const [lotteryContest, setLotteryContest] = useState("5982");
  const [instagramLive, setInstagramLive] = useState("https://instagram.com/sonicvendas");
  const [regulation, setRegulation] = useState("Sorteio apurado com base na extração oficial da Loteria Federal.");
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState("");

  // Reveal Modal states
  const [revealModalRaffle, setRevealModalRaffle] = useState<any | null>(null);
  const [winnerCode, setWinnerCode] = useState("");
  const [winnerName, setWinnerName] = useState("");
  const [drawnNumbers, setDrawnNumbers] = useState("");
  const [revealLoading, setRevealLoading] = useState(false);
  const [revealFeedback, setRevealFeedback] = useState("");

  // Audit tickets modal
  const [auditRaffle, setAuditRaffle] = useState<any | null>(null);
  const [auditTickets, setAuditTickets] = useState<any[]>([]);
  const [auditLoading, setAuditLoading] = useState(false);

  async function load() {
    setLoading(true);
    try {
      const res = await fetch("/api/admin/raffles", {
        headers: { Authorization: `Bearer ${token}` },
      });
      const data = await res.json();
      if (data.ok) {
        setRaffles(data.data || []);
      }
    } catch {
      // ignore
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
  }, [token]);

  async function handleSaveRaffle(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    setMessage("");

    try {
      const payload = {
        title,
        imageUrl,
        category,
        totalNumbers: parseInt(String(totalNumbers), 10) || 1000,
        pricePerNumber,
        description,
        drawDate: drawDate || null,
        lotteryContestNumber: lotteryContest,
        instagramLiveUrl: instagramLive,
        regulation,
        status: "open",
        isFeatured: true,
        isActive: true,
      };

      if (editingId) {
        await fetch(`/api/admin/raffles/${editingId}`, {
          method: "PUT",
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "application/json",
          },
          body: JSON.stringify(payload),
        });
        setMessage("Sorteio atualizado com sucesso!");
      } else {
        await fetch("/api/admin/raffles", {
          method: "POST",
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "application/json",
          },
          body: JSON.stringify(payload),
        });
        setMessage("Sorteio cadastrado com sucesso!");
      }

      setEditingId(null);
      setTitle("");
      load();
    } catch {
      setMessage("Erro ao salvar sorteio.");
    } finally {
      setSaving(false);
    }
  }

  async function handleRevealSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!revealModalRaffle || !winnerCode) return;
    setRevealLoading(true);
    setRevealFeedback("");

    try {
      const res = await fetch(`/api/admin/raffles/${revealModalRaffle.id}`, {
        method: "PUT",
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          action: "reveal_winner",
          status: "drawn",
          winnerCode: winnerCode.trim(),
          winnerName: winnerName.trim() || undefined,
          lotteryContestNumber: lotteryContest,
          lotteryDrawnNumbers: drawnNumbers,
        }),
      });

      const data = await res.json();
      if (data.ok) {
        setRevealFeedback("🏆 Resultado revelado e gravado com sucesso! Ganhador publicado.");
        load();
        setTimeout(() => setRevealModalRaffle(null), 2000);
      } else {
        setRevealFeedback(data.error || "Erro ao revelar.");
      }
    } catch {
      setRevealFeedback("Erro de conexão ao processar apuração.");
    } finally {
      setRevealLoading(false);
    }
  }

  async function openAuditModal(raffle: any) {
    setAuditRaffle(raffle);
    setAuditLoading(true);
    try {
      const res = await fetch(`/api/admin/raffles/${raffle.id}/tickets`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      const data = await res.json();
      if (data.ok) {
        setAuditTickets(data.tickets || []);
      }
    } catch {
      // ignore
    } finally {
      setAuditLoading(false);
    }
  }

  async function handleDelete(id: number) {
    if (!confirm("Tem certeza que deseja excluir este sorteio?")) return;
    try {
      await fetch(`/api/admin/raffles/${id}`, {
        method: "DELETE",
        headers: { Authorization: `Bearer ${token}` },
      });
      load();
    } catch {
      alert("Erro ao excluir");
    }
  }

  return (
    <div className="space-y-8">
      {/* Create / Edit Form */}
      <div className="rounded-3xl border border-amber-500/30 bg-slate-900/60 p-6 shadow-xl">
        <h3 className="mb-4 text-lg font-bold text-amber-400">
          {editingId ? "Editar Sorteio" : "🎯 Cadastrar Novo Sorteio / Cotas"}
        </h3>

        <form onSubmit={handleSaveRaffle} className="grid gap-4 md:grid-cols-2">
          <div>
            <label className="mb-1 block text-xs font-bold text-slate-300">Título do Prêmio / Sorteio</label>
            <input
              type="text"
              required
              placeholder="Ex: iPhone 16 Pro Max 256GB"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full rounded-xl bg-slate-950 border border-slate-700 px-4 py-2.5 text-sm text-white focus:border-amber-400 focus:outline-none"
            />
          </div>

          <div>
            <label className="mb-1 block text-xs font-bold text-slate-300">URL da Imagem do Prêmio</label>
            <input
              type="text"
              required
              placeholder="https://images.unsplash.com/..."
              value={imageUrl}
              onChange={(e) => setImageUrl(e.target.value)}
              className="w-full rounded-xl bg-slate-950 border border-slate-700 px-4 py-2.5 text-sm text-white focus:border-amber-400 focus:outline-none"
            />
          </div>

          <div>
            <label className="mb-1 block text-xs font-bold text-slate-300">Categoria</label>
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              className="w-full rounded-xl bg-slate-950 border border-slate-700 px-4 py-2.5 text-sm text-white focus:border-amber-400 focus:outline-none"
            >
              <option value="celular">📱 Celular</option>
              <option value="computador">💻 Computador / PC Gamer</option>
              <option value="notebook">💻 Notebook</option>
              <option value="geladeira">❄️ Geladeira / Eletrodomésticos</option>
              <option value="viagens">✈️ Viagens</option>
              <option value="dinheiro">💵 Dinheiro / Pix</option>
              <option value="outros">🎁 Outros Prêmios</option>
            </select>
          </div>

          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="mb-1 block text-xs font-bold text-slate-300">Total de Cotas</label>
              <input
                type="number"
                required
                placeholder="1000, 2000, 5000..."
                value={totalNumbers}
                onChange={(e) => setTotalNumbers(parseInt(e.target.value || "1000", 10))}
                className="w-full rounded-xl bg-slate-950 border border-slate-700 px-4 py-2.5 text-sm text-white focus:border-amber-400 focus:outline-none"
              />
            </div>
            <div>
              <label className="mb-1 block text-xs font-bold text-slate-300">Preço / Cota (R$)</label>
              <input
                type="text"
                required
                placeholder="0.10, 0.01, 0.50..."
                value={pricePerNumber}
                onChange={(e) => setPricePerNumber(e.target.value)}
                className="w-full rounded-xl bg-slate-950 border border-slate-700 px-4 py-2.5 text-sm text-white focus:border-amber-400 focus:outline-none"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="mb-1 block text-xs font-bold text-slate-300">Concurso Loteria Federal</label>
              <input
                type="text"
                placeholder="Ex: 5982"
                value={lotteryContest}
                onChange={(e) => setLotteryContest(e.target.value)}
                className="w-full rounded-xl bg-slate-950 border border-slate-700 px-4 py-2.5 text-sm text-white focus:border-amber-400 focus:outline-none"
              />
            </div>
            <div>
              <label className="mb-1 block text-xs font-bold text-slate-300">Instagram Live URL</label>
              <input
                type="text"
                placeholder="https://instagram.com/..."
                value={instagramLive}
                onChange={(e) => setInstagramLive(e.target.value)}
                className="w-full rounded-xl bg-slate-950 border border-slate-700 px-4 py-2.5 text-sm text-white focus:border-amber-400 focus:outline-none"
              />
            </div>
          </div>

          <div>
            <label className="mb-1 block text-xs font-bold text-slate-300">Data Prevista de Apuração</label>
            <input
              type="datetime-local"
              value={drawDate}
              onChange={(e) => setDrawDate(e.target.value)}
              className="w-full rounded-xl bg-slate-950 border border-slate-700 px-4 py-2.5 text-sm text-white focus:border-amber-400 focus:outline-none"
            />
          </div>

          <div className="md:col-span-2">
            <label className="mb-1 block text-xs font-bold text-slate-300">Descrição do Prêmio</label>
            <textarea
              rows={2}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full rounded-xl bg-slate-950 border border-slate-700 px-4 py-2.5 text-sm text-white focus:border-amber-400 focus:outline-none"
            />
          </div>

          <div className="md:col-span-2 flex gap-3">
            <button
              type="submit"
              disabled={saving}
              className="rounded-xl bg-amber-400 px-6 py-3 text-sm font-extrabold text-slate-950 hover:bg-amber-300 transition-all shadow-lg shadow-amber-400/20 disabled:opacity-60"
            >
              {saving ? "Salvando..." : editingId ? "Atualizar Sorteio" : "Salvar Sorteio"}
            </button>
            {editingId && (
              <button
                type="button"
                onClick={() => {
                  setEditingId(null);
                  setTitle("");
                }}
                className="rounded-xl bg-slate-800 px-5 py-3 text-sm font-bold text-slate-300 hover:bg-slate-700"
              >
                Cancelar
              </button>
            )}
          </div>
        </form>

        {message && (
          <div className="mt-4 rounded-xl border border-amber-400/30 bg-amber-400/10 px-4 py-2.5 text-sm text-amber-300">
            {message}
          </div>
        )}
      </div>

      {/* Sorteios List with Stats & Actions */}
      <div className="rounded-3xl border border-slate-800 bg-slate-900/60 p-6 shadow-xl">
        <h3 className="mb-4 text-lg font-bold text-amber-400">Sorteios Cadastrados</h3>

        <div className="space-y-4">
          {raffles.map((r) => {
            const sold = r.numbersSold || 0;
            const total = r.totalNumbers || 1000;
            const pct = Math.min(100, Math.round((sold / total) * 100));
            const revenue = (sold * parseFloat(String(r.pricePerNumber || 0.10))).toFixed(2);

            return (
              <div
                key={r.id}
                className="flex flex-col md:flex-row md:items-center justify-between gap-4 rounded-2xl border border-slate-800 bg-slate-950 p-5"
              >
                <div className="flex items-center gap-4">
                  <img
                    src={r.imageUrl}
                    alt={r.title}
                    className="h-16 w-16 rounded-xl object-cover bg-slate-900 shrink-0"
                    onError={(e) => {
                      (e.target as HTMLImageElement).src = "https://images.unsplash.com/photo-1695048133142-1a20484d2569?w=800&q=80";
                    }}
                  />
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold text-amber-400 uppercase">#{r.id} • {r.category}</span>
                      {r.status === "drawn" && (
                        <span className="rounded-full bg-emerald-500/20 px-2 py-0.5 text-[10px] font-bold text-emerald-300 border border-emerald-500/30">
                          🏆 Ganhador Revelado
                        </span>
                      )}
                    </div>
                    <h4 className="text-base font-black text-white">{r.title}</h4>
                    <p className="text-xs text-slate-400">
                      R$ {parseFloat(String(r.pricePerNumber || 0.10)).toFixed(2)} / cota • Concurso Loteria: #{r.lotteryContestNumber || "5982"}
                    </p>
                  </div>
                </div>

                {/* Stats */}
                <div className="flex flex-wrap items-center gap-4 text-xs">
                  <div className="rounded-xl bg-slate-900 p-2.5 border border-slate-800 text-center min-w-[90px]">
                    <span className="text-[10px] text-slate-400 block">VENDAS</span>
                    <span className="font-bold text-amber-400">{sold}/{total} ({pct}%)</span>
                  </div>

                  <div className="rounded-xl bg-slate-900 p-2.5 border border-slate-800 text-center min-w-[90px]">
                    <span className="text-[10px] text-slate-400 block">ARRECADADO</span>
                    <span className="font-bold text-emerald-400">R$ {revenue}</span>
                  </div>

                  {/* Actions */}
                  <div className="flex flex-wrap gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        setRevealModalRaffle(r);
                        setWinnerCode(r.winnerCode || "");
                        setWinnerName(r.winnerName || "");
                        setLotteryContest(r.lotteryContestNumber || "5982");
                      }}
                      className="rounded-xl bg-gradient-to-r from-amber-500 to-orange-400 px-3 py-2 text-xs font-black text-slate-950 hover:brightness-110 shadow-md"
                    >
                      🏆 Apuração / Live
                    </button>

                    <button
                      type="button"
                      onClick={() => openAuditModal(r)}
                      className="rounded-xl bg-blue-900/60 border border-blue-700 px-3 py-2 text-xs font-bold text-cyan-300 hover:bg-blue-800"
                    >
                      📋 Ver Cotas
                    </button>

                    <button
                      type="button"
                      onClick={() => handleDelete(r.id)}
                      className="rounded-xl bg-rose-500/10 border border-rose-500/20 px-3 py-2 text-xs text-rose-400 hover:bg-rose-500 hover:text-white"
                    >
                      Excluir
                    </button>
                  </div>
                </div>
              </div>
            );
          })}

          {raffles.length === 0 && !loading && (
            <div className="p-8 text-center text-slate-500">
              Nenhum sorteio cadastrado no momento.
            </div>
          )}
        </div>
      </div>

      {/* Reveal Modal during Live Stream */}
      {revealModalRaffle && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 backdrop-blur-md">
          <div className="relative w-full max-w-xl rounded-3xl border-2 border-amber-400/50 bg-slate-950 p-6 md:p-8 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-4">
              <div>
                <span className="text-[10px] font-black uppercase tracking-widest text-amber-400">
                  APURAÇÃO OFICIAL & REVELAÇÃO DA LIVE
                </span>
                <h4 className="text-xl font-black text-white">{revealModalRaffle.title}</h4>
              </div>
              <button
                onClick={() => setRevealModalRaffle(null)}
                className="rounded-full bg-slate-800 p-2 text-slate-400 hover:bg-slate-700 hover:text-white"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleRevealSubmit} className="mt-6 space-y-4">
              <div>
                <label className="mb-1 block text-xs font-bold uppercase text-amber-300">
                  Código da Cota Sorteada (Loteria Federal)
                </label>
                <input
                  type="text"
                  required
                  placeholder="Ex: 0482 ou 1205"
                  value={winnerCode}
                  onChange={(e) => setWinnerCode(e.target.value)}
                  className="w-full rounded-xl border border-amber-400/40 bg-slate-900 px-4 py-3 text-lg font-mono font-bold text-amber-400 focus:border-amber-400 focus:outline-none"
                />
                <p className="mt-1 text-[11px] text-slate-400">
                  O sistema localizará automaticamente o participante correspondente a este código no banco de dados.
                </p>
              </div>

              <div>
                <label className="mb-1 block text-xs font-bold uppercase text-slate-300">
                  Nome do Ganhador (Opcional - preenchido automaticamente)
                </label>
                <input
                  type="text"
                  placeholder="Deixe em branco para buscar do bilhete"
                  value={winnerName}
                  onChange={(e) => setWinnerName(e.target.value)}
                  className="w-full rounded-xl border border-slate-700 bg-slate-900 px-4 py-2.5 text-xs text-white focus:border-amber-400 focus:outline-none"
                />
              </div>

              <div className="grid gap-3 md:grid-cols-2">
                <div>
                  <label className="mb-1 block text-xs font-bold uppercase text-slate-300">
                    Nº do Concurso da Loteria Federal
                  </label>
                  <input
                    type="text"
                    value={lotteryContest}
                    onChange={(e) => setLotteryContest(e.target.value)}
                    className="w-full rounded-xl border border-slate-700 bg-slate-900 px-3 py-2 text-xs text-white focus:border-amber-400 focus:outline-none"
                    placeholder="Ex: 5982"
                  />
                </div>
                <div>
                  <label className="mb-1 block text-xs font-bold uppercase text-slate-300">
                    Números Extraídos na Loteria
                  </label>
                  <input
                    type="text"
                    value={drawnNumbers}
                    onChange={(e) => setDrawnNumbers(e.target.value)}
                    className="w-full rounded-xl border border-slate-700 bg-slate-900 px-3 py-2 text-xs text-white focus:border-amber-400 focus:outline-none"
                    placeholder="1º Prêmio: 840482"
                  />
                </div>
              </div>

              {revealFeedback && (
                <div className="rounded-xl border border-amber-400/40 bg-amber-950/40 p-3 text-xs font-bold text-amber-300">
                  {revealFeedback}
                </div>
              )}

              <div className="flex items-center justify-between pt-4 border-t border-slate-800">
                <button
                  type="submit"
                  disabled={revealLoading}
                  className="rounded-2xl bg-gradient-to-r from-amber-400 via-orange-400 to-amber-300 px-6 py-3 text-xs font-black uppercase text-slate-950 hover:brightness-110 shadow-lg shadow-amber-400/20 disabled:opacity-60"
                >
                  {revealLoading ? "Processando Apuração..." : "🏆 Publicar Resultado na Live"}
                </button>

                <button
                  type="button"
                  onClick={() => setRevealModalRaffle(null)}
                  className="rounded-xl bg-slate-800 px-4 py-2.5 text-xs font-bold text-slate-300 hover:bg-slate-700"
                >
                  Fechar
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Audit Tickets Modal */}
      {auditRaffle && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 backdrop-blur-md">
          <div className="relative w-full max-w-3xl rounded-3xl border border-slate-700 bg-slate-950 p-6 shadow-2xl max-h-[85vh] flex flex-col">
            <div className="flex items-center justify-between border-b border-slate-800 pb-4">
              <div>
                <span className="text-[10px] font-black uppercase tracking-widest text-cyan-400">
                  AUDITORIA DE BILHETES / COTAS
                </span>
                <h4 className="text-xl font-black text-white">{auditRaffle.title}</h4>
                <p className="text-xs text-slate-400">Total de bilhetes gerados: {auditTickets.length}</p>
              </div>
              <button
                onClick={() => setAuditRaffle(null)}
                className="rounded-full bg-slate-800 p-2 text-slate-400 hover:bg-slate-700 hover:text-white"
              >
                ✕
              </button>
            </div>

            <div className="mt-4 flex-1 overflow-y-auto">
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2">
                {auditTickets.map((t) => (
                  <div
                    key={t.id}
                    className={`rounded-xl p-2.5 text-xs border ${
                      t.isWinner
                        ? "bg-emerald-500/20 border-emerald-400 text-emerald-200"
                        : "bg-slate-900 border-slate-800 text-slate-300"
                    }`}
                  >
                    <div className="font-mono font-bold text-amber-400 text-sm">#{t.ticketCode}</div>
                    <div className="truncate font-medium text-white">{t.customerName}</div>
                    <div className="text-[10px] text-slate-400 truncate">{t.customerPhone}</div>
                  </div>
                ))}
              </div>

              {auditTickets.length === 0 && !auditLoading && (
                <div className="p-8 text-center text-slate-500">
                  Nenhuma cota vendida para este sorteio ainda.
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function PixReceiptsTab({ token }: { token: string }) {
  const [receipts, setReceipts] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [rejectModalItem, setRejectModalItem] = useState<any | null>(null);
  const [rejectionReason, setRejectionReason] = useState("");
  const [processing, setProcessing] = useState(false);

  async function load() {
    setLoading(true);
    try {
      const res = await fetch("/api/admin/pix-receipts", {
        headers: { Authorization: `Bearer ${token}` },
      });
      const data = await res.json();
      if (data.ok) setReceipts(data.data || []);
    } catch {
      // ignore
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
  }, [token]);

  async function handleApprove(receipt: any) {
    if (!confirm(`Aprovar comprovante Pix de R$ ${receipt.amount} para ${receipt.customerName}?`)) return;
    setProcessing(true);
    try {
      const res = await fetch(`/api/admin/pix-receipts/${receipt.id}`, {
        method: "PUT",
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ action: "approve" }),
      });
      const data = await res.json();
      if (data.ok) {
        playSound("payment_confirmed");
        alert("✅ Comprovante Aprovado com Sucesso!");
        load();
      } else {
        alert(data.error || "Erro ao aprovar.");
      }
    } catch {
      alert("Erro de conexão.");
    } finally {
      setProcessing(false);
    }
  }

  async function handleRejectSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!rejectModalItem) return;
    setProcessing(true);
    try {
      const res = await fetch(`/api/admin/pix-receipts/${rejectModalItem.id}`, {
        method: "PUT",
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          action: "reject",
          rejectionReason,
        }),
      });
      const data = await res.json();
      if (data.ok) {
        playSound("order_cancelled");
        alert("Comprovante Rejeitado.");
        setRejectModalItem(null);
        setRejectionReason("");
        load();
      } else {
        alert(data.error || "Erro ao rejeitar.");
      }
    } catch {
      alert("Erro de conexão.");
    } finally {
      setProcessing(false);
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between rounded-3xl border border-emerald-500/30 bg-gradient-to-r from-emerald-950/60 to-slate-900/90 p-6 shadow-xl">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-2xl">📄</span>
            <h3 className="text-xl font-black text-emerald-400">Comprovantes Pix Recebidos</h3>
          </div>
          <p className="mt-1 text-xs text-slate-300">
            Analise os comprovantes enviados pelos clientes, confira o valor e aprove ou rejeite a compra.
          </p>
        </div>
        <button
          onClick={load}
          className="rounded-xl border border-emerald-400/40 bg-emerald-950/80 px-4 py-2 text-xs font-bold text-emerald-300 hover:bg-emerald-500 hover:text-slate-950 transition-colors"
        >
          🔄 Atualizar Lista
        </button>
      </div>

      <div className="overflow-hidden rounded-3xl border border-slate-800 bg-slate-900/60 shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm text-slate-300">
            <thead className="border-b border-slate-800 bg-slate-950 text-xs font-bold uppercase tracking-wider text-emerald-400">
              <tr>
                <th className="px-6 py-4">ID / Pedido</th>
                <th className="px-6 py-4">Cliente</th>
                <th className="px-6 py-4">Valor</th>
                <th className="px-6 py-4">Comprovante</th>
                <th className="px-6 py-4">Status</th>
                <th className="px-6 py-4">Data</th>
                <th className="px-6 py-4">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-medium">
              {receipts.map((r) => (
                <tr key={r.id} className="hover:bg-slate-800/30 transition-colors">
                  <td className="px-6 py-4">
                    <span className="font-mono text-xs text-slate-400">#{r.id}</span>
                    {r.orderId && (
                      <span className="block font-bold text-amber-400 text-xs">Pedido #{r.orderId}</span>
                    )}
                  </td>
                  <td className="px-6 py-4">
                    <div className="font-bold text-white">{r.customerName}</div>
                    <div className="text-xs text-slate-400">{r.customerEmail}</div>
                    {r.customerPhone && (
                      <div className="text-[11px] text-slate-500">{r.customerPhone}</div>
                    )}
                  </td>
                  <td className="px-6 py-4 font-mono font-bold text-emerald-400 text-base">
                    R$ {Number(r.amount).toFixed(2)}
                  </td>
                  <td className="px-6 py-4">
                    <a
                      href={r.receiptUrl}
                      target="_blank"
                      rel="noreferrer"
                      className="inline-flex items-center gap-1 rounded-lg bg-blue-950/80 border border-blue-700/50 px-2.5 py-1 text-xs font-bold text-cyan-300 hover:bg-cyan-500 hover:text-slate-950 transition-colors"
                    >
                      <Eye size={14} /> Ver Imagem / Link <ExternalLink size={10} />
                    </a>
                  </td>
                  <td className="px-6 py-4">
                    {r.status === "approved" && (
                      <span className="rounded-full bg-emerald-500/20 px-3 py-1 text-xs font-bold text-emerald-300 border border-emerald-500/30">
                        ✅ Aprovado
                      </span>
                    )}
                    {r.status === "pending" && (
                      <span className="rounded-full bg-amber-500/20 px-3 py-1 text-xs font-bold text-amber-300 border border-amber-500/30">
                        ⏳ Aguardando Análise
                      </span>
                    )}
                    {r.status === "rejected" && (
                      <div>
                        <span className="rounded-full bg-rose-500/20 px-3 py-1 text-xs font-bold text-rose-300 border border-rose-500/30">
                          ❌ Rejeitado
                        </span>
                        {r.rejectionReason && (
                          <div className="mt-1 text-[10px] text-slate-400">{r.rejectionReason}</div>
                        )}
                      </div>
                    )}
                  </td>
                  <td className="px-6 py-4 text-xs text-slate-400">
                    {new Date(r.createdAt).toLocaleString("pt-BR")}
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => handleApprove(r)}
                        disabled={processing || r.status === "approved"}
                        className="rounded-xl bg-gradient-to-r from-emerald-500 to-emerald-400 px-3 py-1.5 text-xs font-black text-slate-950 hover:brightness-110 shadow-md disabled:opacity-40"
                      >
                        ✅ Aceitar Compra
                      </button>
                      <button
                        onClick={() => {
                          setRejectModalItem(r);
                          setRejectionReason("Comprovante divergente ou valor não compensado.");
                        }}
                        disabled={processing || r.status === "rejected"}
                        className="rounded-xl bg-rose-500/20 border border-rose-500/30 px-2.5 py-1.5 text-xs font-bold text-rose-300 hover:bg-rose-500 hover:text-white disabled:opacity-40"
                      >
                        ❌ Rejeitar
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>

          {receipts.length === 0 && !loading && (
            <div className="p-12 text-center text-slate-500">
              Nenhum comprovante Pix recebido ainda.
            </div>
          )}
        </div>
      </div>

      {/* Reject Modal */}
      {rejectModalItem && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 backdrop-blur-md">
          <div className="relative w-full max-w-md rounded-3xl border border-rose-500/50 bg-slate-950 p-6 shadow-2xl">
            <h4 className="text-lg font-black text-rose-400">Rejeitar Comprovante #{rejectModalItem.id}</h4>
            <p className="mt-1 text-xs text-slate-400">
              Cliente: {rejectModalItem.customerName} • R$ {rejectModalItem.amount}
            </p>

            <form onSubmit={handleRejectSubmit} className="mt-4 space-y-3">
              <div>
                <label className="mb-1 block text-xs font-bold text-slate-300">Motivo da Rejeição</label>
                <textarea
                  required
                  rows={3}
                  value={rejectionReason}
                  onChange={(e) => setRejectionReason(e.target.value)}
                  className="w-full rounded-xl bg-slate-900 border border-slate-700 px-3 py-2 text-xs text-white focus:border-rose-400 focus:outline-none"
                />
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="submit"
                  disabled={processing}
                  className="flex-1 rounded-xl bg-rose-500 py-2.5 text-xs font-black uppercase text-white hover:bg-rose-600"
                >
                  Confirmar Rejeição
                </button>
                <button
                  type="button"
                  onClick={() => setRejectModalItem(null)}
                  className="rounded-xl bg-slate-800 px-4 py-2.5 text-xs font-bold text-slate-300"
                >
                  Cancelar
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

function AnnouncementsTab({ token }: { token: string }) {
  const [announcements, setAnnouncements] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [title, setTitle] = useState("");
  const [message, setMessage] = useState("");
  const [color, setColor] = useState("#f59e0b");
  const [location, setLocation] = useState("top_bar");
  const [buttonText, setButtonText] = useState("");
  const [buttonUrl, setButtonUrl] = useState("");
  const [priority, setPriority] = useState(5);
  const [isClosable, setIsClosable] = useState(true);
  const [saving, setSaving] = useState(false);
  const [feedback, setFeedback] = useState("");

  async function load() {
    setLoading(true);
    try {
      const res = await fetch("/api/admin/announcements", {
        headers: { Authorization: `Bearer ${token}` },
      });
      const data = await res.json();
      if (data.ok) setAnnouncements(data.data || []);
    } catch {
      // ignore
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
  }, [token]);

  async function handleSave(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    setFeedback("");
    try {
      const res = await fetch("/api/admin/announcements", {
        method: "POST",
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          title,
          message,
          color,
          location,
          buttonText: buttonText || null,
          buttonUrl: buttonUrl || null,
          priority: parseInt(String(priority), 10),
          isClosable,
          isActive: true,
        }),
      });
      const data = await res.json();
      if (data.ok) {
        setFeedback("✅ Aviso publicado com sucesso!");
        setTitle("");
        setMessage("");
        setButtonText("");
        setButtonUrl("");
        load();
      } else {
        setFeedback(data.error || "Erro ao salvar aviso.");
      }
    } catch {
      setFeedback("Erro de conexão.");
    } finally {
      setSaving(false);
    }
  }

  async function handleDelete(id: number) {
    if (!confirm("Excluir este aviso?")) return;
    try {
      await fetch(`/api/admin/announcements/${id}`, {
        method: "DELETE",
        headers: { Authorization: `Bearer ${token}` },
      });
      load();
    } catch {
      alert("Erro ao excluir.");
    }
  }

  return (
    <div className="space-y-8">
      {/* Create Announcement Form */}
      <div className="rounded-3xl border border-amber-500/30 bg-slate-900/60 p-6 shadow-xl">
        <h3 className="mb-4 text-lg font-bold text-amber-400">📢 Cadastrar Novo Aviso / Comunicado</h3>

        <form onSubmit={handleSave} className="grid gap-4 md:grid-cols-2">
          <div>
            <label className="mb-1 block text-xs font-bold text-slate-300">Título do Aviso</label>
            <input
              type="text"
              required
              placeholder="Ex: PROMOÇÃO ESPECIAL ou COMUNICADO"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full rounded-xl bg-slate-950 border border-slate-700 px-4 py-2.5 text-sm text-white focus:border-amber-400 focus:outline-none"
            />
          </div>

          <div>
            <label className="mb-1 block text-xs font-bold text-slate-300">Formato / Local de Exibição</label>
            <select
              value={location}
              onChange={(e) => setLocation(e.target.value)}
              className="w-full rounded-xl bg-slate-950 border border-slate-700 px-4 py-2.5 text-sm text-white focus:border-amber-400 focus:outline-none"
            >
              <option value="top_bar">📌 Faixa no Topo do Site (Top Bar)</option>
              <option value="popup_modal">✨ Janela Pop-up ao Entrar</option>
              <option value="home_banner">🖼️ Banner Destacado na Página Inicial</option>
              <option value="alert_box">⚠️ Alerta Importante</option>
            </select>
          </div>

          <div className="md:col-span-2">
            <label className="mb-1 block text-xs font-bold text-slate-300">Texto Completo da Mensagem</label>
            <textarea
              required
              rows={2}
              placeholder="Ex: Aproveite nossos descontos em eletrônicos e sorteios com cotas por R$ 0,01!"
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              className="w-full rounded-xl bg-slate-950 border border-slate-700 px-4 py-2.5 text-sm text-white focus:border-amber-400 focus:outline-none"
            />
          </div>

          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="mb-1 block text-xs font-bold text-slate-300">Cor do Fundo</label>
              <div className="flex items-center gap-2">
                <input
                  type="color"
                  value={color}
                  onChange={(e) => setColor(e.target.value)}
                  className="h-9 w-12 rounded cursor-pointer bg-transparent"
                />
                <input
                  type="text"
                  value={color}
                  onChange={(e) => setColor(e.target.value)}
                  className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-xs font-mono text-white"
                />
              </div>
            </div>
            <div>
              <label className="mb-1 block text-xs font-bold text-slate-300">Prioridade (1 a 10)</label>
              <input
                type="number"
                min={1}
                max={10}
                value={priority}
                onChange={(e) => setPriority(parseInt(e.target.value || "1", 10))}
                className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-xs text-white"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="mb-1 block text-xs font-bold text-slate-300">Texto do Botão (Opcional)</label>
              <input
                type="text"
                placeholder="Ex: Ver Ofertas"
                value={buttonText}
                onChange={(e) => setButtonText(e.target.value)}
                className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-xs text-white"
              />
            </div>
            <div>
              <label className="mb-1 block text-xs font-bold text-slate-300">Link de Destino</label>
              <input
                type="text"
                placeholder="Ex: /produtos ou /sorteios"
                value={buttonUrl}
                onChange={(e) => setButtonUrl(e.target.value)}
                className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-xs text-white"
              />
            </div>
          </div>

          <div className="flex items-center gap-2">
            <input
              type="checkbox"
              id="closable"
              checked={isClosable}
              onChange={(e) => setIsClosable(e.target.checked)}
              className="accent-amber-400"
            />
            <label htmlFor="closable" className="text-xs text-slate-300">Permitir que o visitante feche este aviso</label>
          </div>

          <div className="md:col-span-2 flex gap-3">
            <button
              type="submit"
              disabled={saving}
              className="rounded-xl bg-amber-400 px-6 py-3 text-sm font-extrabold text-slate-950 hover:bg-amber-300 transition-all shadow-lg shadow-amber-400/20 disabled:opacity-60"
            >
              {saving ? "Salvando..." : "📢 Publicar Aviso"}
            </button>
          </div>
        </form>

        {feedback && (
          <div className="mt-4 rounded-xl border border-amber-400/30 bg-amber-400/10 px-4 py-2.5 text-sm text-amber-300">
            {feedback}
          </div>
        )}
      </div>

      {/* Announcements List */}
      <div className="rounded-3xl border border-slate-800 bg-slate-900/60 p-6 shadow-xl">
        <h3 className="mb-4 text-lg font-bold text-amber-400">Avisos e Comunicados Ativos</h3>
        <div className="space-y-3">
          {announcements.map((a) => (
            <div
              key={a.id}
              className="flex flex-col md:flex-row md:items-center justify-between gap-3 rounded-2xl border border-slate-800 bg-slate-950 p-4"
            >
              <div className="flex items-center gap-3">
                <div
                  className="h-8 w-8 rounded-xl shrink-0 flex items-center justify-center font-bold text-slate-950 text-xs shadow"
                  style={{ backgroundColor: a.color || "#f59e0b" }}
                >
                  {a.location === "top_bar" ? "📌" : a.location === "popup_modal" ? "✨" : "🖼️"}
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-black text-white text-sm">{a.title}</span>
                    <span className="text-[10px] font-bold uppercase rounded-full bg-slate-900 px-2 py-0.5 text-slate-400 border border-slate-800">
                      {a.location}
                    </span>
                  </div>
                  <p className="text-xs text-slate-300 mt-0.5">{a.message}</p>
                </div>
              </div>

              <button
                onClick={() => handleDelete(a.id)}
                className="rounded-xl bg-rose-500/10 border border-rose-500/20 px-3 py-1.5 text-xs text-rose-400 hover:bg-rose-500 hover:text-white"
              >
                Excluir
              </button>
            </div>
          ))}

          {announcements.length === 0 && !loading && (
            <div className="p-8 text-center text-slate-500">
              Nenhum aviso cadastrado no momento.
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function ContactAdsTab({ token }: { token: string }) {
  const [ads, setAds] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [processing, setProcessing] = useState(false);

  async function load() {
    setLoading(true);
    try {
      const res = await fetch("/api/admin/contact-ads", {
        headers: { Authorization: `Bearer ${token}` },
      });
      const data = await res.json();
      if (data.ok) setAds(data.data || []);
    } catch {
      // ignore
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
  }, [token]);

  async function updateStatus(id: number, status: string) {
    setProcessing(true);
    try {
      const res = await fetch(`/api/admin/contact-ads/${id}`, {
        method: "PUT",
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ status, action: status }),
      });
      const data = await res.json();
      if (data.ok) {
        playSound(status === "approved" ? "payment_confirmed" : "order_cancelled");
        load();
      } else {
        alert(data.error || "Erro ao atualizar.");
      }
    } catch {
      alert("Erro de conexão.");
    } finally {
      setProcessing(false);
    }
  }

  async function handleDelete(id: number) {
    if (!confirm("Excluir esta divulgação de contato?")) return;
    try {
      await fetch(`/api/admin/contact-ads/${id}`, {
        method: "DELETE",
        headers: { Authorization: `Bearer ${token}` },
      });
      load();
    } catch {
      alert("Erro ao excluir.");
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between rounded-3xl border border-amber-500/30 bg-gradient-to-r from-amber-950/60 to-slate-900/90 p-6 shadow-xl">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-2xl">👤</span>
            <h3 className="text-xl font-black text-amber-400">Gerenciar Divulgações de Contatos</h3>
          </div>
          <p className="mt-1 text-xs text-slate-300">
            Aprove perfis, confira fotos/vídeos de 2 min, comprovantes Pix e acompanhe visualizações e contatos.
          </p>
        </div>
        <button
          onClick={load}
          className="rounded-xl border border-amber-400/40 bg-amber-950/80 px-4 py-2 text-xs font-bold text-amber-300 hover:bg-amber-500 hover:text-slate-950 transition-colors"
        >
          🔄 Atualizar Lista
        </button>
      </div>

      <div className="overflow-hidden rounded-3xl border border-slate-800 bg-slate-900/60 shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm text-slate-300">
            <thead className="border-b border-slate-800 bg-slate-950 text-xs font-bold uppercase tracking-wider text-amber-400">
              <tr>
                <th className="px-6 py-4">ID</th>
                <th className="px-6 py-4">Perfil</th>
                <th className="px-6 py-4">WhatsApp / Link</th>
                <th className="px-6 py-4">Dias / Valor</th>
                <th className="px-6 py-4">Métricas</th>
                <th className="px-6 py-4">Status</th>
                <th className="px-6 py-4">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-medium">
              {ads.map((ad) => (
                <tr key={ad.id} className="hover:bg-slate-800/30 transition-colors">
                  <td className="px-6 py-4 font-mono text-xs text-slate-400">#{ad.id}</td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-3">
                      <img
                        src={ad.profilePhoto}
                        alt={ad.name}
                        className="h-10 w-10 rounded-xl object-cover bg-slate-950 shrink-0"
                      />
                      <div>
                        <div className="font-bold text-white flex items-center gap-1.5">
                          {ad.name} {ad.isBoosted && <span className="text-[10px] text-amber-400 font-black">⚡ TOP</span>}
                        </div>
                        <div className="text-[11px] text-slate-400">{ad.city || "Sem cidade"} {ad.age ? `• ${ad.age}` : ""}</div>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <a
                      href={`https://wa.me/55${ad.phone.replace(/\D/g, "")}`}
                      target="_blank"
                      rel="noreferrer"
                      className="text-xs text-emerald-400 hover:underline block"
                    >
                      {ad.phone}
                    </a>
                    {ad.contactLink && (
                      <a
                        href={ad.contactLink}
                        target="_blank"
                        rel="noreferrer"
                        className="text-[11px] text-cyan-400 hover:underline truncate max-w-[140px] block"
                      >
                        Link do perfil
                      </a>
                    )}
                  </td>
                  <td className="px-6 py-4">
                    <span className="font-bold text-white text-xs">{ad.days} dias</span>
                    <span className="block font-mono text-amber-400 font-bold text-xs">R$ {Number(ad.price).toFixed(2)}</span>
                  </td>
                  <td className="px-6 py-4 text-xs">
                    <div>👁️ {ad.viewsCount || 0} views</div>
                    <div className="text-emerald-400">💬 {ad.clicksWhatsapp || 0} zap</div>
                  </td>
                  <td className="px-6 py-4">
                    {ad.status === "approved" ? (
                      <span className="rounded-full bg-emerald-500/20 px-2.5 py-0.5 text-xs font-bold text-emerald-300 border border-emerald-500/30">
                        ✅ No Ar
                      </span>
                    ) : ad.status === "pending" ? (
                      <span className="rounded-full bg-amber-500/20 px-2.5 py-0.5 text-xs font-bold text-amber-300 border border-amber-500/30">
                        ⏳ Pendente
                      </span>
                    ) : (
                      <span className="rounded-full bg-rose-500/20 px-2.5 py-0.5 text-xs font-bold text-rose-300">
                        Recusado
                      </span>
                    )}
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex flex-wrap gap-1.5">
                      <button
                        onClick={() => updateStatus(ad.id, "approved")}
                        disabled={processing || ad.status === "approved"}
                        className="rounded-lg bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 px-2 py-1 text-[11px] font-bold hover:bg-emerald-500 hover:text-slate-950 disabled:opacity-40"
                      >
                        Aprovar
                      </button>
                      <button
                        onClick={() => updateStatus(ad.id, "rejected")}
                        disabled={processing || ad.status === "rejected"}
                        className="rounded-lg bg-rose-500/20 text-rose-300 border border-rose-500/40 px-2 py-1 text-[11px] font-bold hover:bg-rose-500 hover:text-white disabled:opacity-40"
                      >
                        Recusar
                      </button>
                      <button
                        onClick={() => handleDelete(ad.id)}
                        className="rounded-lg bg-slate-800 text-slate-400 px-2 py-1 text-[11px] hover:text-white"
                      >
                        Excluir
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>

          {ads.length === 0 && !loading && (
            <div className="p-12 text-center text-slate-500">
              Nenhuma divulgação de contato recebida ainda.
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function BusinessAdsTab({ token }: { token: string }) {
  const [ads, setAds] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [processing, setProcessing] = useState(false);

  async function load() {
    setLoading(true);
    try {
      const res = await fetch("/api/admin/business-ads", {
        headers: { Authorization: `Bearer ${token}` },
      });
      const data = await res.json();
      if (data.ok) setAds(data.data || []);
    } catch {
      // ignore
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
  }, [token]);

  async function updateStatus(id: number, status: string) {
    setProcessing(true);
    try {
      const res = await fetch(`/api/admin/business-ads/${id}`, {
        method: "PUT",
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ status, action: status }),
      });
      const data = await res.json();
      if (data.ok) {
        playSound(status === "approved" ? "payment_confirmed" : "order_cancelled");
        load();
      } else {
        alert(data.error || "Erro ao atualizar.");
      }
    } catch {
      alert("Erro de conexão.");
    } finally {
      setProcessing(false);
    }
  }

  async function handleDelete(id: number) {
    if (!confirm("Excluir este anúncio de negócios?")) return;
    try {
      await fetch(`/api/admin/business-ads/${id}`, {
        method: "DELETE",
        headers: { Authorization: `Bearer ${token}` },
      });
      load();
    } catch {
      alert("Erro ao excluir.");
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between rounded-3xl border border-cyan-500/30 bg-gradient-to-r from-blue-950/60 to-slate-900/90 p-6 shadow-xl">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-2xl">💼</span>
            <h3 className="text-xl font-black text-cyan-400">Gerenciar Divulgações de Vendas & Negócios</h3>
          </div>
          <p className="mt-1 text-xs text-slate-300">
            Aprove anúncios comerciais, confira o orçamento sugerido pela IA e gerencie as veiculações no site.
          </p>
        </div>
        <button
          onClick={load}
          className="rounded-xl border border-cyan-400/40 bg-blue-950/80 px-4 py-2 text-xs font-bold text-cyan-300 hover:bg-cyan-500 hover:text-slate-950 transition-colors"
        >
          🔄 Atualizar Lista
        </button>
      </div>

      <div className="overflow-hidden rounded-3xl border border-slate-800 bg-slate-900/60 shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm text-slate-300">
            <thead className="border-b border-slate-800 bg-slate-950 text-xs font-bold uppercase tracking-wider text-cyan-400">
              <tr>
                <th className="px-6 py-4">ID</th>
                <th className="px-6 py-4">Empresa / Anúncio</th>
                <th className="px-6 py-4">Categoria / Preço Produto</th>
                <th className="px-6 py-4">Período / Orçamento IA</th>
                <th className="px-6 py-4">Métricas</th>
                <th className="px-6 py-4">Status</th>
                <th className="px-6 py-4">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-medium">
              {ads.map((ad) => (
                <tr key={ad.id} className="hover:bg-slate-800/30 transition-colors">
                  <td className="px-6 py-4 font-mono text-xs text-slate-400">#{ad.id}</td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-3">
                      <img
                        src={ad.photoUrl}
                        alt={ad.businessName}
                        className="h-11 w-11 rounded-xl object-cover bg-slate-950 shrink-0"
                      />
                      <div>
                        <div className="font-bold text-white flex items-center gap-1.5">
                          {ad.businessName} {ad.isBoosted && <span className="text-[10px] text-cyan-400 font-black">⚡ TOPO</span>}
                        </div>
                        <div className="text-[11px] text-slate-400 font-semibold">{ad.adTitle}</div>
                        <div className="text-[10px] text-slate-500">{ad.phone}</div>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <span className="rounded-full bg-slate-900 border border-slate-800 px-2 py-0.5 text-[10px] font-bold text-cyan-300 uppercase">
                      {ad.category}
                    </span>
                    {ad.productPrice && (
                      <span className="block font-bold text-amber-400 text-xs mt-1">R$ {Number(ad.productPrice).toFixed(2)}</span>
                    )}
                  </td>
                  <td className="px-6 py-4">
                    <span className="font-bold text-white text-xs">{ad.days} dias</span>
                    <span className="block font-mono text-cyan-400 font-bold text-xs">R$ {Number(ad.calculatedPrice).toFixed(2)}</span>
                  </td>
                  <td className="px-6 py-4 text-xs">
                    <div>👁️ {ad.viewsCount || 0} views</div>
                    <div className="text-emerald-400">💬 {ad.clicksWhatsapp || 0} zap</div>
                  </td>
                  <td className="px-6 py-4">
                    {ad.status === "approved" ? (
                      <span className="rounded-full bg-emerald-500/20 px-2.5 py-0.5 text-xs font-bold text-emerald-300 border border-emerald-500/30">
                        ✅ No Ar
                      </span>
                    ) : ad.status === "pending" ? (
                      <span className="rounded-full bg-amber-500/20 px-2.5 py-0.5 text-xs font-bold text-amber-300 border border-amber-500/30">
                        ⏳ Pendente
                      </span>
                    ) : (
                      <span className="rounded-full bg-rose-500/20 px-2.5 py-0.5 text-xs font-bold text-rose-300">
                        Recusado
                      </span>
                    )}
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex flex-wrap gap-1.5">
                      <button
                        onClick={() => updateStatus(ad.id, "approved")}
                        disabled={processing || ad.status === "approved"}
                        className="rounded-lg bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 px-2 py-1 text-[11px] font-bold hover:bg-emerald-500 hover:text-slate-950 disabled:opacity-40"
                      >
                        Aprovar
                      </button>
                      <button
                        onClick={() => updateStatus(ad.id, "rejected")}
                        disabled={processing || ad.status === "rejected"}
                        className="rounded-lg bg-rose-500/20 text-rose-300 border border-rose-500/40 px-2 py-1 text-[11px] font-bold hover:bg-rose-500 hover:text-white disabled:opacity-40"
                      >
                        Recusar
                      </button>
                      <button
                        onClick={() => handleDelete(ad.id)}
                        className="rounded-lg bg-slate-800 text-slate-400 px-2 py-1 text-[11px] hover:text-white"
                      >
                        Excluir
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>

          {ads.length === 0 && !loading && (
            <div className="p-12 text-center text-slate-500">
              Nenhuma divulgação de negócios recebida ainda.
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function AdBoostsTab({ token }: { token: string }) {
  const [boosts, setBoosts] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [processing, setProcessing] = useState(false);

  async function load() {
    setLoading(true);
    try {
      const res = await fetch("/api/admin/ad-boosts", {
        headers: { Authorization: `Bearer ${token}` },
      });
      const data = await res.json();
      if (data.ok) setBoosts(data.data || []);
    } catch {
      // ignore
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
  }, [token]);

  async function handleApproveBoost(id: number) {
    setProcessing(true);
    try {
      const res = await fetch(`/api/admin/ad-boosts/${id}`, {
        method: "PUT",
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ action: "approve" }),
      });
      const data = await res.json();
      if (data.ok) {
        playSound("payment_confirmed");
        alert("✅ Impulsionamento Aprovado e Destaque no Topo Ativado!");
        load();
      } else {
        alert(data.error || "Erro ao aprovar.");
      }
    } catch {
      alert("Erro de conexão.");
    } finally {
      setProcessing(false);
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between rounded-3xl border border-amber-500/30 bg-gradient-to-r from-amber-950/60 to-slate-900/90 p-6 shadow-xl">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-2xl">⚡</span>
            <h3 className="text-xl font-black text-amber-400">Solicitações de Impulsionamento no Topo</h3>
          </div>
          <p className="mt-1 text-xs text-slate-300">
            Confira os pagamentos de impulsionamento e ative o selo TOP nos anúncios de contatos e lojas.
          </p>
        </div>
        <button
          onClick={load}
          className="rounded-xl border border-amber-400/40 bg-amber-950/80 px-4 py-2 text-xs font-bold text-amber-300 hover:bg-amber-500 hover:text-slate-950 transition-colors"
        >
          🔄 Atualizar Lista
        </button>
      </div>

      <div className="overflow-hidden rounded-3xl border border-slate-800 bg-slate-900/60 shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm text-slate-300">
            <thead className="border-b border-slate-800 bg-slate-950 text-xs font-bold uppercase tracking-wider text-amber-400">
              <tr>
                <th className="px-6 py-4">ID</th>
                <th className="px-6 py-4">Cliente / Contato</th>
                <th className="px-6 py-4">Tipo & ID do Anúncio</th>
                <th className="px-6 py-4">Plano Contratado</th>
                <th className="px-6 py-4">Valor</th>
                <th className="px-6 py-4">Status</th>
                <th className="px-6 py-4">Ação</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-medium">
              {boosts.map((b) => (
                <tr key={b.id} className="hover:bg-slate-800/30 transition-colors">
                  <td className="px-6 py-4 font-mono text-xs text-slate-400">#{b.id}</td>
                  <td className="px-6 py-4">
                    <div className="font-bold text-white">{b.customerName}</div>
                    <div className="text-xs text-emerald-400">{b.customerPhone}</div>
                  </td>
                  <td className="px-6 py-4">
                    <span className="rounded bg-slate-900 px-2 py-0.5 text-xs font-bold uppercase text-amber-300 border border-slate-800">
                      {b.adType === "contact" ? "👤 Contato" : "💼 Negócio"} #{b.adId}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <div className="text-xs font-bold text-white">{b.planName}</div>
                    <span className="text-[10px] text-slate-400">{b.days} dias</span>
                  </td>
                  <td className="px-6 py-4 font-mono font-bold text-amber-400">
                    R$ {Number(b.amount).toFixed(2)}
                  </td>
                  <td className="px-6 py-4">
                    {b.status === "approved" ? (
                      <span className="rounded-full bg-emerald-500/20 px-2.5 py-0.5 text-xs font-bold text-emerald-300 border border-emerald-500/30">
                        ⚡ Ativo no Topo
                      </span>
                    ) : (
                      <span className="rounded-full bg-amber-500/20 px-2.5 py-0.5 text-xs font-bold text-amber-300 border border-amber-500/30">
                        ⏳ Aguardando Aprovação
                      </span>
                    )}
                  </td>
                  <td className="px-6 py-4">
                    <button
                      onClick={() => handleApproveBoost(b.id)}
                      disabled={processing || b.status === "approved"}
                      className="rounded-xl bg-gradient-to-r from-amber-400 to-orange-400 px-3 py-1.5 text-xs font-black uppercase text-slate-950 hover:brightness-110 disabled:opacity-40"
                    >
                      {b.status === "approved" ? "Ativado" : "⚡ Ativar Destaque"}
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>

          {boosts.length === 0 && !loading && (
            <div className="p-12 text-center text-slate-500">
              Nenhuma solicitação de impulsionamento pendente.
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function AppearanceAndSoundsTab({ token }: { token: string }) {
  // Theme state
  const [primaryColor, setPrimaryColor] = useState("#f59e0b");
  const [secondaryColor, setSecondaryColor] = useState("#06b6d4");
  const [buttonColor, setButtonColor] = useState("#f59e0b");
  const [backgroundColor, setBackgroundColor] = useState("#020617");
  const [cardColor, setCardColor] = useState("#0f172a");
  const [textColor, setTextColor] = useState("#f8fafc");

  // Fonts state (Google Fonts)
  const [fontTitle, setFontTitle] = useState("Poppins");
  const [fontBody, setFontBody] = useState("Inter");
  const [fontPrice, setFontPrice] = useState("Montserrat");
  const [fontButton, setFontButton] = useState("Poppins");

  // Background
  const [backgroundImageUrl, setBackgroundImageUrl] = useState("");
  const [backgroundVideoUrl, setBackgroundVideoUrl] = useState("");
  const [backgroundOverlayOpacity, setBackgroundOverlayOpacity] = useState("0.85");

  // Sounds
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [soundVolume, setSoundVolume] = useState(80);

  // Maintenance
  const [maintenanceMode, setMaintenanceMode] = useState(false);
  const [maintenanceMessage, setMaintenanceMessage] = useState("Sonic Vendas está em atualização programada.");
  const [maintenanceEstimate, setMaintenanceEstimate] = useState("Previsão de retorno em instantes.");

  const [saving, setSaving] = useState(false);
  const [feedback, setFeedback] = useState("");

  const fontOptions = [
    "Inter",
    "Poppins",
    "Roboto",
    "Montserrat",
    "Nunito",
    "Open Sans",
    "Lato",
    "Raleway",
    "Oswald",
    "Ubuntu",
    "Merriweather",
    "Playfair Display",
  ];

  useEffect(() => {
    fetch("/api/theme")
      .then((r) => r.json())
      .then((res) => {
        if (res.ok && res.data) {
          const d = res.data;
          if (d.primaryColor) setPrimaryColor(d.primaryColor);
          if (d.secondaryColor) setSecondaryColor(d.secondaryColor);
          if (d.buttonColor) setButtonColor(d.buttonColor);
          if (d.backgroundColor) setBackgroundColor(d.backgroundColor);
          if (d.cardColor) setCardColor(d.cardColor);
          if (d.textColor) setTextColor(d.textColor);
          if (d.backgroundImageUrl) setBackgroundImageUrl(d.backgroundImageUrl);
          if (d.backgroundVideoUrl) setBackgroundVideoUrl(d.backgroundVideoUrl);
          if (d.backgroundOverlayOpacity) setBackgroundOverlayOpacity(d.backgroundOverlayOpacity);
          if (d.soundEnabled !== undefined) setSoundEnabled(d.soundEnabled === "true");
          if (d.soundVolume) setSoundVolume(parseInt(d.soundVolume, 10));
          if (d.maintenanceMode !== undefined) setMaintenanceMode(d.maintenanceMode === "true");
          if (d.maintenanceMessage) setMaintenanceMessage(d.maintenanceMessage);
          if (d.maintenanceEstimate) setMaintenanceEstimate(d.maintenanceEstimate);
        }
      });
  }, []);

  async function handleSaveTheme(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    setFeedback("");

    try {
      const res = await fetch("/api/admin/theme", {
        method: "POST",
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          primaryColor,
          secondaryColor,
          buttonColor,
          backgroundColor,
          cardColor,
          textColor,
          fontTitle,
          fontBody,
          fontPrice,
          fontButton,
          backgroundImageUrl,
          backgroundVideoUrl,
          backgroundOverlayOpacity,
          soundEnabled: String(soundEnabled),
          soundVolume: String(soundVolume),
          maintenanceMode: String(maintenanceMode),
          maintenanceMessage,
          maintenanceEstimate,
        }),
      });

      const data = await res.json();
      if (data.ok) {
        setFeedback("✅ Configurações de Aparência, Sons e Manutenção salvas com sucesso!");
        playSound("payment_confirmed", soundVolume);
      } else {
        setFeedback(data.error || "Erro ao salvar.");
      }
    } catch {
      setFeedback("Erro de conexão ao salvar.");
    } finally {
      setSaving(false);
    }
  }

  function handleTestSound(type: SoundEventType) {
    playSound(type, soundVolume);
  }

  return (
    <div className="space-y-8">
      <form onSubmit={handleSaveTheme} className="space-y-8">
        {/* Fonts Section */}
        <div className="rounded-3xl border border-purple-500/30 bg-slate-900/60 p-6 shadow-xl">
          <div className="flex items-center gap-2 mb-2">
            <span className="text-xl">🔤</span>
            <h3 className="text-lg font-bold text-purple-400">Personalização Avançada de Fontes (Google Fonts)</h3>
          </div>
          <p className="text-xs text-slate-400 mb-6">
            Escolha as famílias tipográficas oficiais do Google Fonts para cada elemento da loja.
          </p>

          <div className="grid gap-4 sm:grid-cols-2 md:grid-cols-4">
            <div>
              <label className="text-xs font-bold text-slate-300 block mb-1.5">Fonte dos Títulos (Headlines)</label>
              <select
                value={fontTitle}
                onChange={(e) => setFontTitle(e.target.value)}
                className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-xs text-white"
              >
                {fontOptions.map((f) => (
                  <option key={f} value={f}>{f}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="text-xs font-bold text-slate-300 block mb-1.5">Fonte dos Textos (Corpo)</label>
              <select
                value={fontBody}
                onChange={(e) => setFontBody(e.target.value)}
                className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-xs text-white"
              >
                {fontOptions.map((f) => (
                  <option key={f} value={f}>{f}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="text-xs font-bold text-slate-300 block mb-1.5">Fonte dos Preços</label>
              <select
                value={fontPrice}
                onChange={(e) => setFontPrice(e.target.value)}
                className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-xs text-white"
              >
                {fontOptions.map((f) => (
                  <option key={f} value={f}>{f}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="text-xs font-bold text-slate-300 block mb-1.5">Fonte dos Botões</label>
              <select
                value={fontButton}
                onChange={(e) => setFontButton(e.target.value)}
                className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-xs text-white"
              >
                {fontOptions.map((f) => (
                  <option key={f} value={f}>{f}</option>
                ))}
              </select>
            </div>
          </div>

          {/* Live Typography Preview */}
          <div className="mt-5 rounded-2xl bg-slate-950 p-4 border border-purple-500/30 flex flex-col md:flex-row items-center justify-between gap-4">
            <div>
              <span className="text-[10px] uppercase font-bold text-purple-400 block mb-0.5">Pré-visualização ao Vivo:</span>
              <h4 className="text-xl font-black text-white" style={{ fontFamily: `${fontTitle}, sans-serif` }}>
                Sonic Vendas — O Melhor em Eletrônicos & Serviços
              </h4>
              <p className="text-xs text-slate-300 mt-1" style={{ fontFamily: `${fontBody}, sans-serif` }}>
                Texto de exemplo utilizando a tipografia configurada para toda a plataforma.
              </p>
            </div>
            <div className="flex items-center gap-3 shrink-0">
              <span className="text-2xl font-black text-amber-400" style={{ fontFamily: `${fontPrice}, sans-serif` }}>
                R$ 399,90
              </span>
              <button
                type="button"
                className="rounded-xl bg-amber-400 px-4 py-2 text-xs font-black uppercase text-slate-950 shadow"
                style={{ fontFamily: `${fontButton}, sans-serif` }}
              >
                Comprar
              </button>
            </div>
          </div>
        </div>

        {/* Colors Section */}
        <div className="rounded-3xl border border-amber-500/30 bg-slate-900/60 p-6 shadow-xl">
          <h3 className="mb-4 text-lg font-bold text-amber-400">🎨 Personalizar Cores do Site</h3>
          <p className="text-xs text-slate-400 mb-6">
            Ajuste as cores principais do site. As alterações são sincronizadas para todos os clientes em tempo real.
          </p>

          <div className="grid gap-4 sm:grid-cols-2 md:grid-cols-3">
            {[
              { label: "Cor Principal (Destaques)", val: primaryColor, set: setPrimaryColor },
              { label: "Cor Secundária (Cyan / Acentos)", val: secondaryColor, set: setSecondaryColor },
              { label: "Cor dos Botões de Ação", val: buttonColor, set: setButtonColor },
              { label: "Cor de Fundo Geral", val: backgroundColor, set: setBackgroundColor },
              { label: "Cor dos Cartões / Painéis", val: cardColor, set: setCardColor },
              { label: "Cor Principal dos Textos", val: textColor, set: setTextColor },
            ].map((c, i) => (
              <div key={i} className="rounded-2xl bg-slate-950 p-4 border border-slate-800">
                <label className="text-xs font-bold text-slate-300 block mb-2">{c.label}</label>
                <div className="flex items-center gap-3">
                  <input
                    type="color"
                    value={c.val}
                    onChange={(e) => c.set(e.target.value)}
                    className="h-10 w-14 rounded-xl cursor-pointer bg-transparent border-0"
                  />
                  <input
                    type="text"
                    value={c.val}
                    onChange={(e) => c.set(e.target.value)}
                    className="w-full rounded-xl bg-slate-900 border border-slate-700 px-3 py-2 text-xs font-mono text-white"
                  />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Background Image / Video Section */}
        <div className="rounded-3xl border border-slate-800 bg-slate-900/60 p-6 shadow-xl">
          <h3 className="mb-4 text-lg font-bold text-cyan-400">🖼️ Foto ou Vídeo de Fundo do Site</h3>
          <p className="text-xs text-slate-400 mb-4">
            Adicione uma imagem ou vídeo panorâmico para o fundo com camada de transparência para manter textos legíveis.
          </p>

          <div className="grid gap-4 md:grid-cols-2">
            <div>
              <label className="mb-1 block text-xs font-bold text-slate-300">URL da Imagem de Fundo</label>
              <input
                type="text"
                placeholder="https://images.unsplash.com/..."
                value={backgroundImageUrl}
                onChange={(e) => setBackgroundImageUrl(e.target.value)}
                className="w-full rounded-xl bg-slate-950 border border-slate-700 px-4 py-2.5 text-xs text-white focus:border-cyan-400 focus:outline-none"
              />
            </div>
            <div>
              <label className="mb-1 block text-xs font-bold text-slate-300">URL do Vídeo de Fundo (MP4/WebM)</label>
              <input
                type="text"
                placeholder="https://.../video.mp4"
                value={backgroundVideoUrl}
                onChange={(e) => setBackgroundVideoUrl(e.target.value)}
                className="w-full rounded-xl bg-slate-950 border border-slate-700 px-4 py-2.5 text-xs text-white focus:border-cyan-400 focus:outline-none"
              />
            </div>
          </div>

          <div className="mt-4">
            <div className="flex justify-between text-xs font-bold text-slate-300 mb-1">
              <span>Opacidade da Camada Escura (Legibilidade):</span>
              <span className="text-cyan-400">{Math.round(parseFloat(backgroundOverlayOpacity) * 100)}%</span>
            </div>
            <input
              type="range"
              min="0.3"
              max="0.95"
              step="0.05"
              value={backgroundOverlayOpacity}
              onChange={(e) => setBackgroundOverlayOpacity(e.target.value)}
              className="w-full accent-cyan-400"
            />
          </div>
        </div>

        {/* Sound System Central Section */}
        <div className="rounded-3xl border border-slate-800 bg-slate-900/60 p-6 shadow-xl">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-lg font-bold text-amber-400 flex items-center gap-2">
                <Volume2 size={20} /> Central de Notificações Sonoras
              </h3>
              <p className="text-xs text-slate-400 mt-1">
                Sons curtos e profissionais para cada evento (novo pedido, entrega, pagamento, cancelamento, chat).
              </p>
            </div>
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={soundEnabled}
                onChange={(e) => setSoundEnabled(e.target.checked)}
                className="h-5 w-5 accent-amber-400 rounded"
              />
              <span className="text-xs font-bold text-white">Sons Ativados</span>
            </label>
          </div>

          <div className="mb-6">
            <div className="flex justify-between text-xs font-bold text-slate-300 mb-1">
              <span>Volume Global:</span>
              <span className="text-amber-400">{soundVolume}%</span>
            </div>
            <input
              type="range"
              min="0"
              max="100"
              value={soundVolume}
              onChange={(e) => setSoundVolume(parseInt(e.target.value, 10))}
              className="w-full accent-amber-400"
            />
          </div>

          <div className="border-t border-slate-800 pt-4">
            <span className="text-xs font-black uppercase text-amber-400 block mb-3">
              Testar Áudios dos Acontecimentos:
            </span>
            <div className="grid gap-3 sm:grid-cols-2 md:grid-cols-3">
              {SOUND_DEFINITIONS.map((s) => (
                <div
                  key={s.type}
                  className="rounded-2xl bg-slate-950 p-3.5 border border-slate-800 flex flex-col justify-between"
                >
                  <div>
                    <span className="font-bold text-white text-xs block">{s.name}</span>
                    <p className="text-[10px] text-slate-400 mt-1 line-clamp-2">{s.description}</p>
                  </div>
                  <button
                    type="button"
                    onClick={() => handleTestSound(s.type)}
                    className="mt-3 rounded-xl bg-amber-400/20 border border-amber-400/30 py-1.5 text-xs font-black text-amber-300 hover:bg-amber-400 hover:text-slate-950 transition-all flex items-center justify-center gap-1.5"
                  >
                    🔊 Testar Som
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Maintenance Mode Section */}
        <div className="rounded-3xl border border-rose-500/30 bg-rose-950/20 p-6 shadow-xl">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <Wrench className="text-rose-400" size={22} />
              <h3 className="text-lg font-bold text-rose-400">Modo de Manutenção</h3>
            </div>
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={maintenanceMode}
                onChange={(e) => setMaintenanceMode(e.target.checked)}
                className="h-5 w-5 accent-rose-500 rounded"
              />
              <span className="text-xs font-black uppercase text-rose-300">
                {maintenanceMode ? "MANUTENÇÃO ATIVADA" : "Modo Normal (Desativado)"}
              </span>
            </label>
          </div>

          <p className="text-xs text-slate-300 mb-4">
            Quando ativado, os visitantes veem uma tela profissional de manutenção. O acesso administrativo continua funcionando normalmente.
          </p>

          <div className="grid gap-4 md:grid-cols-2">
            <div>
              <label className="mb-1 block text-xs font-bold text-slate-300">Mensagem Principal</label>
              <input
                type="text"
                value={maintenanceMessage}
                onChange={(e) => setMaintenanceMessage(e.target.value)}
                className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-xs text-white"
              />
            </div>
            <div>
              <label className="mb-1 block text-xs font-bold text-slate-300">Previsão de Retorno</label>
              <input
                type="text"
                value={maintenanceEstimate}
                onChange={(e) => setMaintenanceEstimate(e.target.value)}
                className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-xs text-white"
              />
            </div>
          </div>
        </div>

        {/* Submit */}
        <div className="flex items-center justify-between">
          <button
            type="submit"
            disabled={saving}
            className="rounded-2xl bg-gradient-to-r from-amber-400 to-orange-400 px-8 py-4 text-base font-black uppercase text-slate-950 hover:brightness-110 shadow-xl shadow-amber-400/20 disabled:opacity-60"
          >
            {saving ? "Salvando Alterações..." : "💾 Salvar Todas as Configurações"}
          </button>
        </div>

        {feedback && (
          <div className="rounded-2xl border border-emerald-400/40 bg-emerald-950/40 p-4 text-sm font-bold text-emerald-300">
            {feedback}
          </div>
        )}
      </form>
    </div>
  );
}

function FutureFeaturesTab({ token }: { token: string }) {
  const [features, setFeatures] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [category, setCategory] = useState("geral");
  const [priority, setPriority] = useState("medium");
  const [status, setStatus] = useState("planned");
  const [aiPlan, setAiPlan] = useState("");
  const [generating, setGenerating] = useState(false);
  const [saving, setSaving] = useState(false);
  const [feedback, setFeedback] = useState("");

  async function load() {
    setLoading(true);
    try {
      const res = await fetch("/api/admin/future-features", {
        headers: { Authorization: `Bearer ${token}` },
      });
      const data = await res.json();
      if (data.ok) setFeatures(data.data || []);
    } catch {
      // ignore
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
  }, [token]);

  function handleGenerateAiPlan() {
    if (!title) {
      alert("Digite o título da novidade para a IA gerar a especificação.");
      return;
    }
    setGenerating(true);
    const t = title.toLowerCase();
    let planText = "";

    if (t.includes("afiliad") || t.includes("comiss") || t.includes("indic")) {
      planText = `🔮 [Plano Gerado por IA para: "${title}"]\n1. [Banco] Tabela de parceiros com chave Pix e URL única de rastreio (?ref=slug).\n2. [Servidor] Cálculo de 10% de comissão automática em cada cota de sorteio vendida.\n3. [Painel do Parceiro] Área exclusiva para consultar cliques, cadastros e saldo acumulado.\n4. [Saque Automático] Transferência instantânea para a chave Pix do parceiro.`;
    } else if (t.includes("pix") || t.includes("pagament") || t.includes("comprovante")) {
      planText = `🔮 [Plano Gerado por IA para: "${title}"]\n1. [Integração] QR Code dinâmico do Pix e Chave Copia e Cola.\n2. [Auditoria] Verificação inteligente de comprovantes com aprovação em 1 clique.\n3. [E-mail & Som] Notificação de som triunfante e disparo de e-mail de confirmação.`;
    } else if (t.includes("bot") || t.includes("chat") || t.includes("ia") || t.includes("atendimento")) {
      planText = `🔮 [Plano Gerado por IA para: "${title}"]\n1. [Assistente Sonic] IA treinada com catálogo de produtos, regras de sorteios e IPTV.\n2. [Respostas Automáticas] Atendimento 24h para dúvidas de pagamento, entrega e cotas.\n3. [Transbordo Humano] Botão direto para WhatsApp quando necessário atendimento manual.`;
    } else {
      planText = `🔮 [Plano Gerado por IA para: "${title}"]\n1. [Arquitetura] Mapeamento dos requisitos técnicos e fluxos de usuário.\n2. [Banco de Dados PostgreSQL] Tabelas normalizadas com índices de alta performance.\n3. [APIs RESTful] Endpoints autenticados com validação de dados.\n4. [Interface Responsiva] Telas modernas em Tailwind CSS com suporte a sons e modo escuro.\n5. [Sincronização] Atualização em tempo real entre celulares, tablets e computadores.`;
    }

    setAiPlan(planText);
    setGenerating(false);
  }

  async function handleSave(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    setFeedback("");

    try {
      const res = await fetch("/api/admin/future-features", {
        method: "POST",
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          title,
          description,
          category,
          priority,
          status,
          aiGeneratedPlan: aiPlan,
        }),
      });

      const data = await res.json();
      if (data.ok) {
        setFeedback("✅ Novidade cadastrada e plano técnico gerado com sucesso!");
        setTitle("");
        setDescription("");
        setAiPlan("");
        load();
      } else {
        setFeedback(data.error || "Erro ao salvar.");
      }
    } catch {
      setFeedback("Erro de conexão.");
    } finally {
      setSaving(false);
    }
  }

  async function handleDelete(id: number) {
    if (!confirm("Excluir esta novidade?")) return;
    try {
      await fetch(`/api/admin/future-features/${id}`, {
        method: "DELETE",
        headers: { Authorization: `Bearer ${token}` },
      });
      load();
    } catch {
      alert("Erro ao excluir.");
    }
  }

  return (
    <div className="space-y-8">
      {/* Create Feature with AI Generator Form */}
      <div className="rounded-3xl border border-purple-500/30 bg-slate-900/60 p-6 shadow-xl">
        <div className="flex items-center gap-2 mb-4">
          <Sparkles className="text-purple-400" size={22} />
          <h3 className="text-lg font-bold text-purple-400">
            🚀 Adicionar Novas Ideias & Gerador Técnico IA
          </h3>
        </div>
        <p className="text-xs text-slate-400 mb-6">
          Cadastre novas ideias ou serviços futuros para a Sonic Vendas. Use o botão <strong>"🔮 Gerar com IA"</strong> para criar automaticamente o plano técnico, tabelas e etapas de implementação.
        </p>

        <form onSubmit={handleSave} className="grid gap-4 md:grid-cols-2">
          <div>
            <label className="mb-1 block text-xs font-bold text-slate-300">Título da Novidade / Serviço</label>
            <input
              type="text"
              required
              placeholder="Ex: Sistema de Afiliados com Comissão Pix Automática"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full rounded-xl bg-slate-950 border border-slate-700 px-4 py-2.5 text-sm text-white focus:border-purple-400 focus:outline-none"
            />
          </div>

          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="mb-1 block text-xs font-bold text-slate-300">Categoria</label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2.5 text-xs text-white"
              >
                <option value="geral">Geral</option>
                <option value="afiliados">Afiliados & Parceiros</option>
                <option value="pagamentos">Pagamentos & Pix</option>
                <option value="sorteios">Sorteios & Prêmios</option>
                <option value="iptv">IPTV & Streaming</option>
                <option value="publicidade">Publicidade & Topo</option>
              </select>
            </div>

            <div>
              <label className="mb-1 block text-xs font-bold text-slate-300">Prioridade</label>
              <select
                value={priority}
                onChange={(e) => setPriority(e.target.value)}
                className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2.5 text-xs text-white"
              >
                <option value="low">Baixa</option>
                <option value="medium">Média</option>
                <option value="high">Alta</option>
                <option value="urgent">Urgente 🔥</option>
              </select>
            </div>
          </div>

          <div className="md:col-span-2">
            <label className="mb-1 block text-xs font-bold text-slate-300">Resumo / O que há de novo</label>
            <textarea
              rows={2}
              placeholder="Descreva o que será adicionado ao site..."
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full rounded-xl bg-slate-950 border border-slate-700 px-4 py-2 text-xs text-white"
            />
          </div>

          <div className="md:col-span-2">
            <div className="flex items-center justify-between mb-1">
              <label className="text-xs font-bold text-purple-300">
                Plano Técnico Gerado pela IA (Passo a Passo)
              </label>
              <button
                type="button"
                onClick={handleGenerateAiPlan}
                disabled={generating}
                className="rounded-lg bg-gradient-to-r from-purple-600 to-pink-500 px-3 py-1 text-xs font-black text-white hover:brightness-110 shadow-md"
              >
                {generating ? "Gerando..." : "🔮 Gerar Especificação com IA"}
              </button>
            </div>
            <textarea
              rows={5}
              placeholder="Clique em 'Gerar com IA' ou digite seu plano de implementação..."
              value={aiPlan}
              onChange={(e) => setAiPlan(e.target.value)}
              className="w-full rounded-xl bg-slate-950 border border-purple-500/40 font-mono text-xs text-purple-200 p-3 focus:border-purple-400 focus:outline-none"
            />
          </div>

          <div className="md:col-span-2 flex gap-3">
            <button
              type="submit"
              disabled={saving}
              className="rounded-xl bg-gradient-to-r from-purple-500 to-pink-500 px-6 py-3 text-sm font-black uppercase text-white hover:brightness-110 shadow-lg shadow-purple-500/20 disabled:opacity-60"
            >
              {saving ? "Salvando..." : "Salvar Novidade no Roadmap"}
            </button>
          </div>
        </form>

        {feedback && (
          <div className="mt-4 rounded-xl border border-purple-400/30 bg-purple-400/10 px-4 py-2.5 text-sm text-purple-300">
            {feedback}
          </div>
        )}
      </div>

      {/* Feature List */}
      <div className="rounded-3xl border border-slate-800 bg-slate-900/60 p-6 shadow-xl">
        <h3 className="mb-4 text-lg font-bold text-purple-400">Roadmap de Novidades & Ideias Cadastradas</h3>
        <div className="space-y-4">
          {features.map((f) => (
            <div
              key={f.id}
              className="rounded-2xl border border-slate-800 bg-slate-950 p-5 space-y-3"
            >
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-2 border-b border-slate-800/80 pb-3">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-purple-400 uppercase">#{f.id} • {f.category}</span>
                    <span className={`rounded-full px-2 py-0.5 text-[10px] font-bold ${
                      f.priority === "urgent"
                        ? "bg-rose-500/20 text-rose-300 border border-rose-500/30"
                        : f.priority === "high"
                        ? "bg-amber-500/20 text-amber-300 border border-amber-500/30"
                        : "bg-slate-800 text-slate-400"
                    }`}>
                      Prioridade {f.priority?.toUpperCase()}
                    </span>
                  </div>
                  <h4 className="text-base font-black text-white mt-1">{f.title}</h4>
                  <p className="text-xs text-slate-300">{f.description}</p>
                </div>

                <button
                  onClick={() => handleDelete(f.id)}
                  className="self-start md:self-auto rounded-xl bg-rose-500/10 border border-rose-500/20 px-3 py-1.5 text-xs text-rose-400 hover:bg-rose-500 hover:text-white"
                >
                  Excluir
                </button>
              </div>

              {f.aiGeneratedPlan && (
                <div className="rounded-xl bg-purple-950/20 border border-purple-500/20 p-3">
                  <span className="text-[10px] font-bold uppercase text-purple-400 block mb-1">
                    🔮 Especificação Técnica IA:
                  </span>
                  <pre className="text-xs font-mono text-slate-300 whitespace-pre-wrap">
                    {f.aiGeneratedPlan}
                  </pre>
                </div>
              )}
            </div>
          ))}

          {features.length === 0 && !loading && (
            <div className="p-8 text-center text-slate-500">
              Nenhuma novidade cadastrada ainda.
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function SocialOrdersTab({ token }: { token: string }) {
  const [orders, setOrders] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [processing, setProcessing] = useState(false);

  async function load() {
    setLoading(true);
    try {
      const res = await fetch("/api/admin/social-orders", {
        headers: { Authorization: `Bearer ${token}` },
      });
      const data = await res.json();
      if (data.ok) setOrders(data.data || []);
    } catch {
      // ignore
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
  }, [token]);

  async function updateStatus(id: number, status: string) {
    setProcessing(true);
    try {
      const res = await fetch(`/api/admin/social-orders/${id}`, {
        method: "PUT",
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ status }),
      });
      const data = await res.json();
      if (data.ok) {
        playSound(status === "approved" || status === "completed" ? "payment_confirmed" : "order_cancelled");
        load();
      } else {
        alert(data.error || "Erro ao atualizar.");
      }
    } catch {
      alert("Erro de conexão.");
    } finally {
      setProcessing(false);
    }
  }

  async function handleDelete(id: number) {
    if (!confirm("Excluir este pedido de redes sociais?")) return;
    try {
      await fetch(`/api/admin/social-orders/${id}`, {
        method: "DELETE",
        headers: { Authorization: `Bearer ${token}` },
      });
      load();
    } catch {
      alert("Erro ao excluir.");
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between rounded-3xl border border-pink-500/30 bg-gradient-to-r from-pink-950/60 to-slate-900/90 p-6 shadow-xl">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-2xl">📱</span>
            <h3 className="text-xl font-black text-pink-400">Pedidos de Redes Sociais & Engajamento</h3>
          </div>
          <p className="mt-1 text-xs text-slate-300">
            Acompanhe pedidos de seguidores, curtidas, visualizações, diamantes Free Fire e planos mensais.
          </p>
        </div>
        <button
          onClick={load}
          className="rounded-xl border border-pink-400/40 bg-pink-950/80 px-4 py-2 text-xs font-bold text-pink-300 hover:bg-pink-500 hover:text-slate-950 transition-colors"
        >
          🔄 Atualizar Lista
        </button>
      </div>

      <div className="overflow-hidden rounded-3xl border border-slate-800 bg-slate-900/60 shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm text-slate-300">
            <thead className="border-b border-slate-800 bg-slate-950 text-xs font-bold uppercase tracking-wider text-pink-400">
              <tr>
                <th className="px-6 py-4">ID</th>
                <th className="px-6 py-4">Cliente</th>
                <th className="px-6 py-4">Serviço / Qtd</th>
                <th className="px-6 py-4">@ ou Link / ID</th>
                <th className="px-6 py-4">Valor</th>
                <th className="px-6 py-4">Status</th>
                <th className="px-6 py-4">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-medium">
              {orders.map((o) => (
                <tr key={o.id} className="hover:bg-slate-800/30 transition-colors">
                  <td className="px-6 py-4 font-mono text-xs text-slate-400">#{o.id}</td>
                  <td className="px-6 py-4">
                    <div className="font-bold text-white">{o.customerName}</div>
                    <a
                      href={`https://wa.me/55${o.customerPhone.replace(/\D/g, "")}`}
                      target="_blank"
                      rel="noreferrer"
                      className="text-xs text-emerald-400 hover:underline"
                    >
                      {o.customerPhone}
                    </a>
                  </td>
                  <td className="px-6 py-4">
                    <div className="text-xs font-bold text-white">{o.serviceName}</div>
                    <span className="text-[10px] uppercase font-bold text-slate-400 rounded bg-slate-900 px-1.5 py-0.5 border border-slate-800">
                      {o.network}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <span className="font-mono text-xs font-bold text-amber-300 bg-slate-950 px-2.5 py-1 rounded-lg border border-slate-800">
                      {o.targetHandleOrLink}
                    </span>
                  </td>
                  <td className="px-6 py-4 font-mono font-bold text-emerald-400">
                    R$ {Number(o.totalAmount).toFixed(2)}
                  </td>
                  <td className="px-6 py-4">
                    {o.status === "approved" && (
                      <span className="rounded-full bg-emerald-500/20 px-3 py-1 text-xs font-bold text-emerald-300 border border-emerald-500/30">
                        ✅ Aprovado
                      </span>
                    )}
                    {o.status === "processing" && (
                      <span className="rounded-full bg-cyan-500/20 px-3 py-1 text-xs font-bold text-cyan-300 border border-cyan-500/30">
                        ⚡ Em Envio
                      </span>
                    )}
                    {o.status === "completed" && (
                      <span className="rounded-full bg-purple-500/20 px-3 py-1 text-xs font-bold text-purple-300 border border-purple-500/30">
                        🎉 Concluído
                      </span>
                    )}
                    {o.status === "pending" && (
                      <span className="rounded-full bg-amber-500/20 px-3 py-1 text-xs font-bold text-amber-300 border border-amber-500/30">
                        ⏳ Pendente
                      </span>
                    )}
                    {o.status === "cancelled" && (
                      <span className="rounded-full bg-rose-500/20 px-3 py-1 text-xs font-bold text-rose-300 border border-rose-500/30">
                        ❌ Cancelado
                      </span>
                    )}
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex flex-wrap gap-1.5">
                      <button
                        onClick={() => updateStatus(o.id, "approved")}
                        disabled={processing || o.status === "approved"}
                        className="rounded-lg bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 px-2 py-1 text-[11px] font-bold hover:bg-emerald-500 hover:text-slate-950"
                      >
                        Aprovar
                      </button>
                      <button
                        onClick={() => updateStatus(o.id, "completed")}
                        disabled={processing || o.status === "completed"}
                        className="rounded-lg bg-purple-500/20 text-purple-300 border border-purple-500/40 px-2 py-1 text-[11px] font-bold hover:bg-purple-500 hover:text-white"
                      >
                        Concluir
                      </button>
                      <button
                        onClick={() => handleDelete(o.id)}
                        className="rounded-lg bg-rose-500/10 text-rose-400 border border-rose-500/20 px-2 py-1 text-[11px] hover:bg-rose-500 hover:text-white"
                      >
                        Excluir
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>

          {orders.length === 0 && !loading && (
            <div className="p-12 text-center text-slate-500">
              Nenhum pedido de rede social recebido ainda.
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function RoulettePrizesTab({ token }: { token: string }) {
  const [prizes, setPrizes] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [editingId, setEditingId] = useState<number | null>(null);

  // Form states
  const [title, setTitle] = useState("");
  const [value, setValue] = useState("");
  const [prizeType, setPrizeType] = useState("discount_coupon");
  const [couponCode, setCouponCode] = useState("");
  const [probability, setProbability] = useState(15);
  const [color, setColor] = useState("#06b6d4");
  const [isActive, setIsActive] = useState(true);
  const [saving, setSaving] = useState(false);
  const [feedback, setFeedback] = useState("");

  async function load() {
    setLoading(true);
    try {
      const res = await fetch("/api/admin/roulette/prizes", {
        headers: { Authorization: `Bearer ${token}` },
      });
      const data = await res.json();
      if (data.ok) setPrizes(data.data || []);
    } catch {
      // ignore
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
  }, [token]);

  async function handleSave(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    setFeedback("");

    try {
      const payload = {
        title,
        value,
        prizeType,
        couponCode: couponCode || null,
        probability: parseInt(String(probability), 10) || 10,
        color,
        isActive,
      };

      if (editingId) {
        await fetch(`/api/admin/roulette/prizes/${editingId}`, {
          method: "PUT",
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "application/json",
          },
          body: JSON.stringify(payload),
        });
        setFeedback("✅ Prêmio da Roleta atualizado com sucesso!");
      } else {
        await fetch("/api/admin/roulette/prizes", {
          method: "POST",
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "application/json",
          },
          body: JSON.stringify(payload),
        });
        setFeedback("✅ Novo prêmio adicionado à Roleta!");
      }

      setEditingId(null);
      setTitle("");
      setValue("");
      setCouponCode("");
      load();
    } catch {
      setFeedback("Erro ao salvar prêmio.");
    } finally {
      setSaving(false);
    }
  }

  async function handleDelete(id: number) {
    if (!confirm("Excluir este prêmio da Roleta?")) return;
    try {
      await fetch(`/api/admin/roulette/prizes/${id}`, {
        method: "DELETE",
        headers: { Authorization: `Bearer ${token}` },
      });
      load();
    } catch {
      alert("Erro ao excluir.");
    }
  }

  return (
    <div className="space-y-8">
      {/* Create / Edit Prize Form */}
      <div className="rounded-3xl border border-pink-500/30 bg-slate-900/60 p-6 shadow-xl">
        <h3 className="mb-4 text-lg font-bold text-pink-400">
          {editingId ? "Editar Prêmio da Roleta" : "🎡 Cadastrar Novo Prêmio da Roleta"}
        </h3>

        <form onSubmit={handleSave} className="grid gap-4 md:grid-cols-2">
          <div>
            <label className="mb-1 block text-xs font-bold text-slate-300">Título do Prêmio</label>
            <input
              type="text"
              required
              placeholder="Ex: 10% de Desconto na Loja"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full rounded-xl bg-slate-950 border border-slate-700 px-4 py-2.5 text-sm text-white focus:border-pink-400 focus:outline-none"
            />
          </div>

          <div>
            <label className="mb-1 block text-xs font-bold text-slate-300">Texto / Valor Exibido na Fatia</label>
            <input
              type="text"
              required
              placeholder="Ex: 10% OFF ou 5 COTAS FREE"
              value={value}
              onChange={(e) => setValue(e.target.value)}
              className="w-full rounded-xl bg-slate-950 border border-slate-700 px-4 py-2.5 text-sm text-white focus:border-pink-400 focus:outline-none"
            />
          </div>

          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="mb-1 block text-xs font-bold text-slate-300">Tipo de Prêmio</label>
              <select
                value={prizeType}
                onChange={(e) => setPrizeType(e.target.value)}
                className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2.5 text-xs text-white"
              >
                <option value="discount_coupon">🎟️ Cupom de Desconto</option>
                <option value="bonus_cota">🎁 Cotas Bônus de Sorteio</option>
                <option value="extra_points">⚡ Sonic Pontos</option>
                <option value="perk">🎯 Benefício / Giro Extra</option>
              </select>
            </div>

            <div>
              <label className="mb-1 block text-xs font-bold text-slate-300">Código do Cupom</label>
              <input
                type="text"
                placeholder="Ex: SONIC10"
                value={couponCode}
                onChange={(e) => setCouponCode(e.target.value)}
                className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-xs font-mono text-white"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="mb-1 block text-xs font-bold text-slate-300">Cor da Fatia</label>
              <div className="flex items-center gap-2">
                <input
                  type="color"
                  value={color}
                  onChange={(e) => setColor(e.target.value)}
                  className="h-9 w-12 rounded cursor-pointer bg-transparent"
                />
                <input
                  type="text"
                  value={color}
                  onChange={(e) => setColor(e.target.value)}
                  className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-xs font-mono text-white"
                />
              </div>
            </div>

            <div>
              <label className="mb-1 block text-xs font-bold text-slate-300">Probabilidade de Saída (Peso)</label>
              <input
                type="number"
                min={1}
                max={100}
                value={probability}
                onChange={(e) => setProbability(parseInt(e.target.value || "10", 10))}
                className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-xs text-white"
              />
            </div>
          </div>

          <div className="md:col-span-2 flex gap-3">
            <button
              type="submit"
              disabled={saving}
              className="rounded-xl bg-gradient-to-r from-pink-500 to-purple-500 px-6 py-3 text-sm font-black uppercase text-white hover:brightness-110 shadow-lg shadow-pink-500/20 disabled:opacity-60"
            >
              {saving ? "Salvando..." : editingId ? "Atualizar Fatia da Roleta" : "Salvar Prêmio na Roleta"}
            </button>
            {editingId && (
              <button
                type="button"
                onClick={() => {
                  setEditingId(null);
                  setTitle("");
                  setValue("");
                }}
                className="rounded-xl bg-slate-800 px-4 py-3 text-xs font-bold text-slate-300"
              >
                Cancelar
              </button>
            )}
          </div>
        </form>

        {feedback && (
          <div className="mt-4 rounded-xl border border-pink-400/30 bg-pink-400/10 px-4 py-2.5 text-sm text-pink-300">
            {feedback}
          </div>
        )}
      </div>

      {/* Prizes List */}
      <div className="rounded-3xl border border-slate-800 bg-slate-900/60 p-6 shadow-xl">
        <h3 className="mb-4 text-lg font-bold text-pink-400">Prêmios Atuais da Roleta da Sorte</h3>

        <div className="grid gap-4 sm:grid-cols-2 md:grid-cols-3">
          {prizes.map((p) => (
            <div
              key={p.id}
              className="rounded-2xl border border-slate-800 bg-slate-950 p-4 flex flex-col justify-between"
              style={{ borderLeftColor: p.color || "#06b6d4", borderLeftWidth: 4 }}
            >
              <div>
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-mono text-slate-400">#{p.id}</span>
                  <span className="text-[10px] font-bold text-slate-400">Peso: {p.probability}%</span>
                </div>
                <h4 className="font-black text-white text-base mt-1">{p.title}</h4>
                <div className="text-lg font-mono font-black text-amber-400 mt-1">{p.value}</div>
                {p.couponCode && (
                  <span className="inline-block mt-1 font-mono text-[10px] text-pink-300 bg-pink-950/40 px-2 py-0.5 rounded border border-pink-500/30">
                    Cupom: {p.couponCode}
                  </span>
                )}
              </div>

              <div className="mt-4 flex gap-2 border-t border-slate-800 pt-3">
                <button
                  onClick={() => {
                    setEditingId(p.id);
                    setTitle(p.title);
                    setValue(p.value);
                    setPrizeType(p.prizeType);
                    setCouponCode(p.couponCode || "");
                    setProbability(p.probability || 10);
                    setColor(p.color || "#06b6d4");
                  }}
                  className="flex-1 rounded-lg bg-slate-800 py-1.5 text-xs font-bold text-slate-300 hover:bg-slate-700"
                >
                  Editar
                </button>
                <button
                  onClick={() => handleDelete(p.id)}
                  className="rounded-lg bg-rose-500/10 border border-rose-500/20 px-2.5 py-1.5 text-xs text-rose-400 hover:bg-rose-500 hover:text-white"
                >
                  Excluir
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

