"use client";
import React, { useState, useEffect } from "react";
import Link from "next/link";
import {
  Tv,
  Film,
  Clapperboard,
  Trophy,
  Smartphone,
  Monitor,
  Tablet,
  CheckCircle2,
  Clock,
  Sparkles,
  Send,
  Copy,
  Check,
  Search,
  ExternalLink,
  ShieldCheck,
  Zap,
  PlayCircle,
  HelpCircle,
  ArrowRight,
  Flame,
} from "lucide-react";

export default function IptvPage() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [device, setDevice] = useState("Smart TV");
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState<{ type: "success" | "error"; text: string } | null>(null);

  // Status check tab state
  const [lookupEmail, setLookupEmail] = useState("");
  const [lookupLoading, setLookupLoading] = useState(false);
  const [iptvData, setIptvData] = useState<any>(null);
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  // Remaining time in seconds
  const [timeLeft, setTimeLeft] = useState<number>(0);

  // Countdown timer effect
  useEffect(() => {
    if (timeLeft <= 0) return;
    const interval = setInterval(() => {
      setTimeLeft((prev) => (prev > 0 ? prev - 1 : 0));
    }, 1000);
    return () => clearInterval(interval);
  }, [timeLeft]);

  async function handleRequest(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setMessage(null);
    try {
      const res = await fetch("/api/iptv/request", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          customerName: name,
          customerEmail: email,
          customerPhone: phone,
        }),
      });
      const data = await res.json();
      if (!data.ok) {
        setMessage({ type: "error", text: data.error || "Erro ao solicitar acesso." });
        return;
      }
      setMessage({
        type: "success",
        text: "🎉 Solicitação enviada com sucesso! O administrador foi notificado e irá liberar seus dados de acesso de 12 horas.",
      });
      setLookupEmail(email);
      // Auto check status
      fetchStatus(email);
      setName("");
      setEmail("");
      setPhone("");
    } catch {
      setMessage({ type: "error", text: "Erro de conexão ao enviar solicitação." });
    } finally {
      setLoading(false);
    }
  }

  async function fetchStatus(emailOrPhone?: string) {
    const query = emailOrPhone || lookupEmail;
    if (!query) return;
    setLookupLoading(true);
    try {
      const isEmail = query.includes("@");
      const url = isEmail
        ? `/api/iptv/status?email=${encodeURIComponent(query)}`
        : `/api/iptv/status?phone=${encodeURIComponent(query)}`;
      const res = await fetch(url);
      const data = await res.json();
      if (data.ok && data.data) {
        setIptvData(data.data);
        if (data.data.remainingSeconds) {
          setTimeLeft(data.data.remainingSeconds);
        }
      } else {
        setIptvData(null);
        alert(data.error || "Nenhum acesso encontrado com este e-mail/WhatsApp.");
      }
    } catch {
      alert("Erro ao consultar status.");
    } finally {
      setLookupLoading(false);
    }
  }

  function handleCopy(text: string, key: string) {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2000);
  }

  const formatCountdown = (totalSeconds: number) => {
    const hours = Math.floor(totalSeconds / 3600);
    const minutes = Math.floor((totalSeconds % 3600) / 60);
    const seconds = totalSeconds % 60;
    return `${hours.toString().padStart(2, "0")}h ${minutes.toString().padStart(2, "0")}m ${seconds.toString().padStart(2, "0")}s`;
  };

  return (
    <main className="min-h-screen bg-[#03091e] text-slate-100 selection:bg-cyan-500 selection:text-black">
      {/* Background ambient lighting */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden">
        <div className="absolute -top-40 left-1/2 -translate-x-1/2 w-[800px] h-[600px] bg-gradient-to-b from-blue-600/20 via-cyan-500/10 to-transparent blur-3xl" />
        <div className="absolute top-[40%] -left-32 w-[500px] h-[500px] bg-blue-700/15 blur-[140px]" />
        <div className="absolute top-[60%] -right-32 w-[500px] h-[500px] bg-cyan-600/15 blur-[140px]" />
      </div>

      <div className="relative z-10 mx-auto max-w-6xl px-4 py-8 md:px-6 md:py-12">
        {/* Top Header Banner */}
        <div className="flex flex-col md:flex-row items-center justify-between gap-4 border-b border-cyan-500/20 pb-6">
          <div className="flex items-center gap-3">
            <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-gradient-to-tr from-blue-600 to-cyan-400 p-2 shadow-lg shadow-cyan-500/30">
              <span className="text-2xl font-black text-white">⚡</span>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-2xl font-black italic tracking-wider text-white">SONIC</span>
                <span className="rounded bg-cyan-400 px-1.5 py-0.5 text-xs font-black uppercase text-slate-950">VENDAS</span>
              </div>
              <p className="text-[11px] font-bold uppercase tracking-widest text-cyan-400">IPTV Premium Oficial</p>
            </div>
          </div>

          <div className="flex items-center gap-2 rounded-full border border-cyan-400/30 bg-blue-950/60 px-4 py-1.5 backdrop-blur-md">
            <span className="h-2 w-2 rounded-full bg-cyan-400 animate-ping" />
            <span className="text-xs font-extrabold uppercase tracking-wide text-cyan-200">
              ENTRETENIMENTO SEM LIMITES • TUDO EM UM SÓ LUGAR!
            </span>
          </div>

          <div className="flex items-center gap-2">
            <a
              href="#consultar"
              className="rounded-xl border border-cyan-400/40 bg-blue-900/40 px-4 py-2 text-xs font-bold text-cyan-300 hover:bg-cyan-500 hover:text-slate-950 transition-all shadow-md"
            >
              🔍 Consultar Meu Acesso
            </a>
          </div>
        </div>

        {/* Hero Section */}
        <div className="mt-8 text-center md:mt-12">
          <div className="inline-flex items-center gap-2 rounded-full bg-gradient-to-r from-blue-600/30 via-cyan-500/30 to-blue-600/30 px-5 py-2 border border-cyan-400/40 shadow-lg shadow-cyan-500/20 mb-4 animate-pulse">
            <Flame className="text-amber-400" size={18} />
            <span className="text-sm font-extrabold text-cyan-300 uppercase tracking-wide">
              TESTE GRATUITO DE 12 HORAS LIBERADO
            </span>
          </div>

          <h1 className="text-4xl font-black tracking-tight text-white md:text-7xl drop-shadow-[0_0_35px_rgba(6,182,212,0.6)]">
            IPTV <span className="bg-gradient-to-r from-cyan-400 via-blue-400 to-indigo-300 bg-clip-text text-transparent">ASSISTA O QUE QUISER!</span>
          </h1>

          <p className="mx-auto mt-4 max-w-2xl text-base md:text-xl font-medium text-slate-300">
            Filmes, Séries, Canais Ao Vivo, Esportes e muito mais! <br />
            <span className="font-bold text-cyan-300">Tudo o que você ama, em um só lugar!</span>
          </p>

          {/* Sonic Mascot thumbs up + TV preview simulation */}
          <div className="mx-auto mt-8 flex max-w-4xl flex-col items-center justify-center gap-6 rounded-3xl border border-cyan-500/30 bg-gradient-to-br from-blue-950/70 via-slate-950/90 to-blue-900/60 p-6 shadow-2xl backdrop-blur-xl md:flex-row md:p-8">
            <div className="flex items-center gap-4 text-left">
              <div className="relative flex h-24 w-24 shrink-0 items-center justify-center rounded-2xl bg-gradient-to-tr from-blue-600 to-cyan-400 text-5xl shadow-xl shadow-cyan-500/40">
                <span>🦔👍</span>
                <span className="absolute -bottom-2 -right-2 rounded-full bg-amber-400 px-2 py-0.5 text-[10px] font-black text-slate-950">
                  TOP
                </span>
              </div>
              <div>
                <h3 className="text-xl font-black text-white md:text-2xl">Mascote Sonic Aprova!</h3>
                <p className="text-sm text-cyan-200">
                  Acesso rápido, sem travar, qualidade HD/4K e suporte 24h via WhatsApp.
                </p>
                <div className="mt-2 flex items-center gap-2 text-xs font-bold text-emerald-400">
                  <CheckCircle2 size={15} /> Servidor 100% Estável no Brasil
                </div>
              </div>
            </div>

            <div className="flex shrink-0 items-center gap-3 rounded-2xl border border-cyan-400/30 bg-slate-950/80 px-6 py-4">
              <Tv size={36} className="text-cyan-400" />
              <div>
                <div className="text-2xl font-black text-amber-400">12 HORAS</div>
                <div className="text-xs font-bold text-slate-400">Acesso Cortesia Total</div>
              </div>
            </div>
          </div>

          {/* 5 Feature Badges (Matching flyer) */}
          <div className="mt-8 grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-5">
            {[
              { icon: Tv, label: "CANAIS AO VIVO", sub: "Mais de 2.000 canais" },
              { icon: Film, label: "FILMES LANÇAMENTOS", sub: "Cinema na sua tela" },
              { icon: Clapperboard, label: "SÉRIES COMPLETAS", sub: "Atualizadas diariamente" },
              { icon: Trophy, label: "ESPORTES AO VIVO", sub: "Futebol, F1, Combate" },
              { icon: Smartphone, label: "EM TODOS DISPOSITIVOS", sub: "TV, Celular, PC, Box" },
            ].map((f, idx) => (
              <div
                key={idx}
                className="group relative flex flex-col items-center justify-center rounded-2xl border border-cyan-500/20 bg-blue-950/40 p-4 text-center transition-all hover:-translate-y-1 hover:border-cyan-400 hover:bg-blue-900/50 hover:shadow-lg hover:shadow-cyan-500/20"
              >
                <div className="mb-2 flex h-12 w-12 items-center justify-center rounded-xl bg-blue-600/30 text-cyan-400 group-hover:bg-cyan-400 group-hover:text-slate-950 transition-colors">
                  <f.icon size={24} />
                </div>
                <span className="text-xs font-black uppercase tracking-wide text-white">{f.label}</span>
                <span className="mt-1 text-[11px] text-slate-400">{f.sub}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Main interactive grid: Form on Left + Benefits on Right */}
        <div className="mt-12 grid gap-8 lg:grid-cols-12">
          {/* Left Form: SOLICITE SEU ACESSO IPTV AGORA */}
          <div className="lg:col-span-7">
            <div className="relative overflow-hidden rounded-3xl border-2 border-cyan-400/50 bg-gradient-to-b from-blue-950/90 via-slate-950/95 to-blue-950/80 p-6 md:p-8 shadow-[0_0_50px_rgba(6,182,212,0.25)] backdrop-blur-2xl">
              <div className="absolute top-0 right-0 -mr-16 -mt-16 h-40 w-40 rounded-full bg-cyan-500/20 blur-3xl pointer-events-none" />

              <div className="flex items-center gap-3">
                <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-cyan-500 text-slate-950 shadow-lg shadow-cyan-500/40">
                  <PlayCircle size={28} />
                </div>
                <div>
                  <h2 className="text-2xl font-black uppercase tracking-tight text-white md:text-3xl">
                    SOLICITE SEU ACESSO <span className="text-cyan-400">IPTV AGORA!</span>
                  </h2>
                  <p className="text-xs font-medium text-slate-300 md:text-sm">
                    Preencha os seus dados e receba as informações de acesso para assistir por{" "}
                    <span className="font-bold text-cyan-300">12 horas</span>.
                  </p>
                </div>
              </div>

              <form onSubmit={handleRequest} className="mt-6 space-y-4">
                <div>
                  <label htmlFor="customerName" className="mb-1.5 block text-xs font-bold uppercase tracking-wider text-cyan-300">
                    👤 Nome completo
                  </label>
                  <input
                    id="customerName"
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Ex: Lucas Gabriel"
                    className="w-full rounded-2xl border border-cyan-500/30 bg-slate-950/80 px-4 py-3.5 text-sm text-white placeholder-slate-500 transition-all focus:border-cyan-400 focus:bg-slate-900 focus:outline-none focus:ring-2 focus:ring-cyan-400/30"
                  />
                </div>

                <div className="grid gap-4 md:grid-cols-2">
                  <div>
                    <label htmlFor="customerEmail" className="mb-1.5 block text-xs font-bold uppercase tracking-wider text-cyan-300">
                      ✉️ E-mail
                    </label>
                    <input
                      id="customerEmail"
                      type="email"
                      required
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="seu@email.com"
                      className="w-full rounded-2xl border border-cyan-500/30 bg-slate-950/80 px-4 py-3.5 text-sm text-white placeholder-slate-500 transition-all focus:border-cyan-400 focus:bg-slate-900 focus:outline-none focus:ring-2 focus:ring-cyan-400/30"
                    />
                  </div>

                  <div>
                    <label htmlFor="customerPhone" className="mb-1.5 block text-xs font-bold uppercase tracking-wider text-cyan-300">
                      💬 Contato (WhatsApp)
                    </label>
                    <input
                      id="customerPhone"
                      type="text"
                      required
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      placeholder="(75) 98155-8007"
                      className="w-full rounded-2xl border border-cyan-500/30 bg-slate-950/80 px-4 py-3.5 text-sm text-white placeholder-slate-500 transition-all focus:border-cyan-400 focus:bg-slate-900 focus:outline-none focus:ring-2 focus:ring-cyan-400/30"
                    />
                  </div>
                </div>

                <div>
                  <label htmlFor="deviceType" className="mb-1.5 block text-xs font-bold uppercase tracking-wider text-cyan-300">
                    📺 Dispositivo Principal
                  </label>
                  <select
                    id="deviceType"
                    value={device}
                    onChange={(e) => setDevice(e.target.value)}
                    className="w-full rounded-2xl border border-cyan-500/30 bg-slate-950 px-4 py-3.5 text-sm text-white focus:border-cyan-400 focus:outline-none"
                  >
                    <option value="Smart TV">Smart TV (Samsung / LG / Android TV)</option>
                    <option value="TV Box / Fire Stick">TV Box / TV Stick / Chromecast</option>
                    <option value="Celular Android">Celular Android</option>
                    <option value="iPhone / iPad">iPhone / iPad (iOS)</option>
                    <option value="Computador / Notebook">Computador / Notebook (Windows/Mac)</option>
                  </select>
                </div>

                {message && (
                  <div
                    className={`rounded-2xl border p-4 text-sm ${
                      message.type === "success"
                        ? "border-emerald-500/50 bg-emerald-950/60 text-emerald-200"
                        : "border-rose-500/50 bg-rose-950/60 text-rose-200"
                    }`}
                  >
                    {message.text}
                  </div>
                )}

                <button
                  type="submit"
                  disabled={loading}
                  className="group relative flex w-full items-center justify-center gap-3 overflow-hidden rounded-2xl bg-gradient-to-r from-blue-600 via-cyan-400 to-blue-500 py-4 text-base font-black uppercase tracking-wider text-slate-950 shadow-xl shadow-cyan-500/30 transition-all hover:scale-[1.02] hover:shadow-cyan-400/50 disabled:opacity-60"
                >
                  <Send size={20} className="transition-transform group-hover:translate-x-1" />
                  {loading ? "Processando Solicitação..." : "SOLICITAR ACESSO IPTV"}
                </button>

                <p className="text-center text-[11px] text-slate-400">
                  🔒 Seus dados estão protegidos. O acesso de 12 horas é liberado pelo administrador sem cobrança antecipada.
                </p>
              </form>
            </div>
          </div>

          {/* Right Box: ACESSO POR 12 HORAS APROVEITE AGORA! */}
          <div className="flex flex-col justify-between gap-6 lg:col-span-5">
            {/* Clock Badge */}
            <div className="relative overflow-hidden rounded-3xl border border-cyan-400/30 bg-gradient-to-br from-blue-900/60 to-slate-950/80 p-6 shadow-xl backdrop-blur-xl">
              <div className="flex items-center gap-4">
                <div className="flex h-16 w-16 shrink-0 items-center justify-center rounded-2xl bg-amber-400 text-slate-950 shadow-lg shadow-amber-400/40">
                  <Clock size={36} className="animate-spin-slow" />
                </div>
                <div>
                  <span className="text-xs font-black uppercase tracking-widest text-cyan-300">ACESSO POR</span>
                  <h3 className="text-3xl font-black text-amber-400 drop-shadow-md">12 HORAS</h3>
                  <span className="text-xs font-bold uppercase text-white">APROVEITE AGORA!</span>
                </div>
              </div>

              {/* Checklist from flyer */}
              <div className="mt-6 space-y-3">
                {[
                  "Canais de TV ao vivo",
                  "Filmes e Séries atualizados",
                  "Esportes (Futebol, F1, Lutas)",
                  "Canais internacionais",
                  "Conteúdo adulto (opcional)",
                  "Qualidade HD e Full HD / 4K",
                ].map((item, i) => (
                  <div key={i} className="flex items-center gap-3">
                    <div className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-cyan-400/20 text-cyan-400">
                      <CheckCircle2 size={16} />
                    </div>
                    <span className="text-sm font-semibold text-slate-200">{item}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Quick WhatsApp Support Contact */}
            <div className="rounded-3xl border border-blue-600/30 bg-gradient-to-r from-blue-950 to-slate-950 p-6 shadow-lg">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="text-base font-black text-white">Dúvidas ou Ativação Imediata?</h4>
                  <p className="mt-1 text-xs text-slate-400">Fale direto com nosso suporte oficial no WhatsApp</p>
                </div>
                <a
                  href="https://wa.me/5575981558007?text=Olá,%20gostaria%20de%20liberar%20meu%20teste%20de%20IPTV%2012%20Horas"
                  target="_blank"
                  rel="noreferrer"
                  className="flex items-center gap-2 rounded-xl bg-emerald-500 px-4 py-2.5 text-xs font-black uppercase text-slate-950 hover:bg-emerald-400 transition-all shadow-lg shadow-emerald-500/30"
                >
                  WhatsApp <ExternalLink size={14} />
                </a>
              </div>
            </div>
          </div>
        </div>

        {/* Section: CONSULTAR STATUS E CREDENCIAIS DO MEU IPTV (12 HORAS) */}
        <section id="consultar" className="mt-16 scroll-mt-24">
          <div className="rounded-3xl border-2 border-cyan-400/40 bg-gradient-to-b from-slate-950 via-blue-950/70 to-slate-950 p-6 md:p-10 shadow-2xl backdrop-blur-xl">
            <div className="flex flex-col md:flex-row items-center justify-between gap-4 border-b border-cyan-500/20 pb-6">
              <div>
                <span className="text-xs font-black uppercase tracking-widest text-cyan-400">ÁREA DO CLIENTE</span>
                <h3 className="text-2xl font-black text-white md:text-3xl">
                  Consultar Meu <span className="text-cyan-400">Acesso IPTV</span>
                </h3>
                <p className="text-xs text-slate-400 md:text-sm">
                  Digite seu e-mail ou WhatsApp para visualizar suas credenciais e o tempo restante das 12 horas.
                </p>
              </div>

              <div className="flex w-full md:w-auto items-center gap-2">
                <input
                  type="text"
                  placeholder="Seu e-mail ou WhatsApp..."
                  value={lookupEmail}
                  onChange={(e) => setLookupEmail(e.target.value)}
                  className="w-full md:w-72 rounded-2xl border border-cyan-500/30 bg-slate-950 px-4 py-3 text-sm text-white placeholder-slate-500 focus:border-cyan-400 focus:outline-none"
                />
                <button
                  type="button"
                  onClick={() => fetchStatus()}
                  disabled={lookupLoading}
                  className="flex shrink-0 items-center gap-2 rounded-2xl bg-cyan-400 px-5 py-3 text-sm font-black text-slate-950 hover:bg-cyan-300 transition-all shadow-lg shadow-cyan-400/20 disabled:opacity-60"
                >
                  <Search size={16} />
                  {lookupLoading ? "Buscando..." : "Consultar"}
                </button>
              </div>
            </div>

            {/* If IPTV Data is loaded */}
            {iptvData && (
              <div className="mt-8">
                {/* Status: PENDING */}
                {iptvData.status === "pending" && (
                  <div className="rounded-2xl border border-amber-500/40 bg-amber-950/30 p-6 text-center">
                    <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-full bg-amber-400/20 text-3xl">
                      ⏳
                    </div>
                    <h4 className="mt-3 text-xl font-black text-amber-300">Solicitação em Análise pelo Administrador</h4>
                    <p className="mt-2 text-sm text-slate-300 max-w-xl mx-auto">
                      Olá <span className="font-bold text-white">{iptvData.customerName}</span>! Sua solicitação foi registrada em{" "}
                      {new Date(iptvData.createdAt).toLocaleString("pt-BR")}. O administrador está gerando seu login e senha exclusivos para 12 horas.
                    </p>
                    <div className="mt-4 inline-flex items-center gap-2 rounded-full bg-amber-400/10 px-4 py-1.5 text-xs font-bold text-amber-300">
                      ⚡ Status: Aguardando Liberação ADM
                    </div>
                  </div>
                )}

                {/* Status: APPROVED (Active Access with Countdown) */}
                {iptvData.status === "approved" && (
                  <div className="space-y-6">
                    {/* Countdown Banner */}
                    <div className="flex flex-col md:flex-row items-center justify-between gap-4 rounded-2xl border-2 border-emerald-400 bg-emerald-950/50 p-6 shadow-xl">
                      <div className="flex items-center gap-3">
                        <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-emerald-400 text-slate-950 font-black text-2xl shadow-lg shadow-emerald-400/30">
                          ✓
                        </div>
                        <div>
                          <div className="text-xs font-black uppercase tracking-wider text-emerald-300">ACESSO ATIVO</div>
                          <h4 className="text-2xl font-black text-white">Seu Teste de 12 Horas está Liberado!</h4>
                          <p className="text-xs text-slate-300">
                            Expira em: <span className="font-bold text-emerald-300">{new Date(iptvData.expiresAt).toLocaleString("pt-BR")}</span>
                          </p>
                        </div>
                      </div>

                      <div className="flex flex-col items-center justify-center rounded-2xl border border-emerald-400/40 bg-slate-950 px-6 py-3 text-center">
                        <span className="text-[10px] font-bold uppercase tracking-widest text-slate-400">TEMPO RESTANTE</span>
                        <span className="text-2xl md:text-3xl font-black text-amber-400 font-mono tracking-wider">
                          {formatCountdown(timeLeft)}
                        </span>
                      </div>
                    </div>

                    {/* Credentials Grid */}
                    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
                      {/* Server / DNS */}
                      <div className="rounded-2xl border border-cyan-500/30 bg-slate-950 p-4">
                        <span className="text-[10px] font-bold uppercase text-cyan-400">SERVIDOR / DNS (URL)</span>
                        <div className="mt-1 flex items-center justify-between gap-2">
                          <code className="text-xs font-mono font-bold text-white truncate">
                            {iptvData.serverUrl || "http://sonic.iptvplay.com:8080"}
                          </code>
                          <button
                            type="button"
                            onClick={() => handleCopy(iptvData.serverUrl || "http://sonic.iptvplay.com:8080", "server")}
                            className="rounded-lg bg-blue-900/60 p-1.5 text-cyan-300 hover:bg-cyan-400 hover:text-slate-950 transition-colors"
                          >
                            {copiedKey === "server" ? <Check size={14} /> : <Copy size={14} />}
                          </button>
                        </div>
                      </div>

                      {/* Username */}
                      <div className="rounded-2xl border border-cyan-500/30 bg-slate-950 p-4">
                        <span className="text-[10px] font-bold uppercase text-cyan-400">USUÁRIO</span>
                        <div className="mt-1 flex items-center justify-between gap-2">
                          <code className="text-sm font-mono font-bold text-white">{iptvData.username || "sonic_user12"}</code>
                          <button
                            type="button"
                            onClick={() => handleCopy(iptvData.username || "sonic_user12", "user")}
                            className="rounded-lg bg-blue-900/60 p-1.5 text-cyan-300 hover:bg-cyan-400 hover:text-slate-950 transition-colors"
                          >
                            {copiedKey === "user" ? <Check size={14} /> : <Copy size={14} />}
                          </button>
                        </div>
                      </div>

                      {/* Password */}
                      <div className="rounded-2xl border border-cyan-500/30 bg-slate-950 p-4">
                        <span className="text-[10px] font-bold uppercase text-cyan-400">SENHA</span>
                        <div className="mt-1 flex items-center justify-between gap-2">
                          <code className="text-sm font-mono font-bold text-amber-300">{iptvData.password || "sonic123"}</code>
                          <button
                            type="button"
                            onClick={() => handleCopy(iptvData.password || "sonic123", "pass")}
                            className="rounded-lg bg-blue-900/60 p-1.5 text-cyan-300 hover:bg-cyan-400 hover:text-slate-950 transition-colors"
                          >
                            {copiedKey === "pass" ? <Check size={14} /> : <Copy size={14} />}
                          </button>
                        </div>
                      </div>

                      {/* M3U Link */}
                      <div className="rounded-2xl border border-cyan-500/30 bg-slate-950 p-4">
                        <span className="text-[10px] font-bold uppercase text-cyan-400">PLAYLIST M3U</span>
                        <div className="mt-1 flex items-center justify-between gap-2">
                          <code className="text-xs font-mono font-bold text-slate-300 truncate">
                            {iptvData.m3uUrl || "http://sonic.iptvplay.com/get.php?..."}
                          </code>
                          <button
                            type="button"
                            onClick={() => handleCopy(iptvData.m3uUrl || "http://sonic.iptvplay.com/get.php?...", "m3u")}
                            className="rounded-lg bg-blue-900/60 p-1.5 text-cyan-300 hover:bg-cyan-400 hover:text-slate-950 transition-colors"
                          >
                            {copiedKey === "m3u" ? <Check size={14} /> : <Copy size={14} />}
                          </button>
                        </div>
                      </div>
                    </div>

                    {/* Step-by-Step Instructions */}
                    <div className="rounded-2xl border border-slate-800 bg-slate-950/70 p-6">
                      <h5 className="flex items-center gap-2 text-sm font-black uppercase text-cyan-300">
                        <HelpCircle size={18} /> Como Assistir no seu Aplicativo
                      </h5>
                      <div className="mt-3 grid gap-4 text-xs text-slate-300 md:grid-cols-3">
                        <div className="rounded-xl bg-blue-950/40 p-3 border border-blue-900/40">
                          <span className="font-bold text-cyan-300">1. Smart TV / TV Box</span>
                          <p className="mt-1 text-slate-400">
                            Baixe o app <strong>IPTV Smarters Pro</strong> ou <strong>XCIPTV</strong>. Escolha login com API Xtream Codes e insira URL, Usuário e Senha acima.
                          </p>
                        </div>
                        <div className="rounded-xl bg-blue-950/40 p-3 border border-blue-900/40">
                          <span className="font-bold text-cyan-300">2. Celular (Android / iOS)</span>
                          <p className="mt-1 text-slate-400">
                            Instale <strong>IPTV Smarters Player</strong> pela Play Store ou App Store e entre com os mesmos dados.
                          </p>
                        </div>
                        <div className="rounded-xl bg-blue-950/40 p-3 border border-blue-900/40">
                          <span className="font-bold text-cyan-300">3. Computador (PC / Mac)</span>
                          <p className="mt-1 text-slate-400">
                            Abra o VLC Media Player ou Smarters Web e cole o link M3U fornecido.
                          </p>
                        </div>
                      </div>
                      {iptvData.instructions && (
                        <div className="mt-3 rounded-xl border border-cyan-500/20 bg-blue-950/30 p-3 text-xs text-cyan-200">
                          <strong>Instruções do Administrador:</strong> {iptvData.instructions}
                        </div>
                      )}
                    </div>
                  </div>
                )}

                {/* Status: EXPIRED or REVOKED */}
                {(iptvData.status === "expired" || iptvData.status === "revoked") && (
                  <div className="rounded-2xl border border-rose-500/40 bg-rose-950/30 p-6 text-center">
                    <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-full bg-rose-500/20 text-3xl">
                      🔒
                    </div>
                    <h4 className="mt-3 text-xl font-black text-rose-300">Acesso de 12 Horas Finalizado</h4>
                    <p className="mt-2 text-sm text-slate-300 max-w-xl mx-auto">
                      Seu período cortesia de 12 horas foi concluído. Gostou da experiência? Fale com a Sonic Vendas para assinar um plano mensal ou anual completo!
                    </p>
                    <a
                      href="https://wa.me/5575981558007?text=Olá,%20gostei%20do%20teste%20de%20IPTV%2012h%20e%20quero%20assinar%20um%20plano!"
                      target="_blank"
                      rel="noreferrer"
                      className="mt-4 inline-flex items-center gap-2 rounded-2xl bg-gradient-to-r from-amber-400 to-amber-500 px-6 py-3 text-sm font-black text-slate-950 hover:bg-amber-300 transition-all shadow-lg shadow-amber-400/20"
                    >
                      Assinar Plano Mensal com Desconto <ArrowRight size={16} />
                    </a>
                  </div>
                )}
              </div>
            )}
          </div>
        </section>

        {/* Bottom Devices Bar (Matching flyer) */}
        <div className="mt-16 rounded-3xl border border-cyan-500/20 bg-blue-950/30 p-6 text-center">
          <span className="text-xs font-black uppercase tracking-widest text-cyan-400">
            ASSISTA EM QUALQUER DISPOSITIVO
          </span>
          <div className="mt-6 flex flex-wrap items-center justify-center gap-8 md:gap-16">
            <div className="flex flex-col items-center gap-2">
              <Tv size={36} className="text-cyan-400" />
              <span className="text-xs font-bold text-slate-300">Smart TV</span>
            </div>
            <div className="flex flex-col items-center gap-2">
              <Smartphone size={36} className="text-cyan-400" />
              <span className="text-xs font-bold text-slate-300">Celular</span>
            </div>
            <div className="flex flex-col items-center gap-2">
              <Tablet size={36} className="text-cyan-400" />
              <span className="text-xs font-bold text-slate-300">Tablet</span>
            </div>
            <div className="flex flex-col items-center gap-2">
              <Monitor size={36} className="text-cyan-400" />
              <span className="text-xs font-bold text-slate-300">Computador</span>
            </div>
          </div>

          <div className="mt-8 border-t border-cyan-500/20 pt-6">
            <h4 className="text-2xl font-black italic tracking-wider text-cyan-300">
              IPTV É NA <span className="text-white">SONIC VENDAS!</span>
            </h4>
          </div>
        </div>
      </div>
    </main>
  );
}
