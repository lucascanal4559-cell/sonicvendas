import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";
import SoundAndThemeManager from "./components/SoundAndThemeManager";
import InstagramDrawerMenu from "./components/InstagramDrawerMenu";

export const metadata: Metadata = {
  title: "Sonic Vendas Premium — Sistema Completo",
  description: "Vitrine sincronizada com banco de dados PostgreSQL, painel administrativo e integração de pagamento.",
  viewport: "width=device-width, initial-scale=1",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="pt-BR">
      <body className="min-h-screen bg-gradient-to-b from-slate-950 via-slate-900 to-amber-950/20 text-slate-100 antialiased">
        <header className="sticky top-0 z-50 border-b border-slate-800 bg-slate-950/80 backdrop-blur-md">
          <div className="mx-auto flex max-w-6xl items-center justify-between px-4 sm:px-6 py-3">
            <div className="flex items-center gap-3">
              <InstagramDrawerMenu />
              <a href="/" className="text-xl font-extrabold tracking-tight text-amber-400">Sonic Vendas</a>
            </div>
            <nav className="hidden lg:flex gap-3 text-sm font-medium items-center">
              <a href="/" className="hover:text-amber-400 transition-colors">Loja</a>
              <a href="/produtos" className="hover:text-amber-400 transition-colors">Produtos</a>
              <a href="/servicos-sociais" className="inline-flex items-center gap-1 rounded-lg bg-pink-500/10 border border-pink-400/40 px-2.5 py-0.5 text-xs font-black uppercase text-pink-300 hover:bg-pink-500 hover:text-slate-950 transition-all shadow-md">
                📱 Redes Sociais
              </a>
              <a href="/sorteios" className="inline-flex items-center gap-1 rounded-lg bg-amber-400/20 border border-amber-400/40 px-2.5 py-0.5 text-xs font-black uppercase text-amber-300 hover:bg-amber-400 hover:text-slate-950 transition-all shadow-md">
                🎯 Sorteios
              </a>
              <a href="/roleta" className="inline-flex items-center gap-1 rounded-lg bg-pink-500/10 border border-pink-400/30 px-2 py-0.5 text-xs font-black uppercase text-pink-300 hover:bg-pink-400 hover:text-slate-950 transition-all">
                🎡 Roleta
              </a>
              <a href="/iptv" className="inline-flex items-center gap-1 rounded-lg bg-cyan-500/10 border border-cyan-400/30 px-2.5 py-0.5 text-xs font-black uppercase text-cyan-300 hover:bg-cyan-400 hover:text-slate-950 transition-all shadow-md">
                📺 IPTV 12H
              </a>
              <a href="/grupos" className="hover:text-amber-400 transition-colors">Grupos</a>
              <a href="/patrocinadores" className="hover:text-amber-400 transition-colors">Patrocinadores</a>
              <a href="/contato" className="hover:text-amber-400 transition-colors">Contato</a>
              <a href="/notificacoes" className="inline-flex items-center gap-1 rounded-full bg-amber-400/10 px-3 py-1 text-xs font-extrabold text-amber-400 hover:bg-amber-400/20 transition-all shadow-lg shadow-amber-400/10 relative">
                🔔 <span>Notificações</span>
                <span className="absolute -top-1 -right-1 h-4 w-4 rounded-full bg-red-500 text-[9px] font-black text-white flex items-center justify-center shadow-md">3</span>
              </a>
            </nav>
          </div>
        </header>
        <SoundAndThemeManager />
        {children}
      </body>
    </html>
  );
}
