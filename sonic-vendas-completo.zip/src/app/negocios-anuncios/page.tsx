"use client";
import React, { useState, useEffect } from "react";
import Link from "next/link";
import {
  Store,
  ArrowLeft,
  Sparkles,
  MapPin,
  ExternalLink,
  MessageCircle,
  PlusCircle,
  Zap,
  Eye,
  Video,
  Copy,
  Check,
  ShieldCheck,
  Flame,
  ShoppingBag,
  Tag,
  DollarSign,
} from "lucide-react";
import { playSound } from "@/lib/sounds";

export default function NegociosAnunciosPage() {
  const [ads, setAds] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedCategory, setSelectedCategory] = useState("all");

  // Boost modal
  const [boostAd, setBoostAd] = useState<any | null>(null);
  const [boostPlan, setBoostPlan] = useState("topo_7d");
  const [boostName, setBoostName] = useState("");
  const [boostPhone, setBoostPhone] = useState("");
  const [boostReceiptUrl, setBoostReceiptUrl] = useState("");
  const [boostSending, setBoostSending] = useState(false);
  const [boostSuccess, setBoostSuccess] = useState(false);
  const [copiedPix, setCopiedPix] = useState(false);

  const pixKey = "75981558007";

  const boostPlans = [
    { id: "topo_3d", name: "Destaque Topo 3 Dias", days: 3, price: 5.0 },
    { id: "topo_7d", name: "Destaque Topo 7 Dias (Mais Popular)", days: 7, price: 10.0 },
    { id: "ouro_15d", name: "Destaque Ouro Super Topo 15 Dias", days: 15, price: 20.0 },
    { id: "maximo_30d", name: "Destaque Máximo 30 Dias + Borda Ouro", days: 30, price: 35.0 },
  ];

  const currentBoostPlanObj = boostPlans.find((p) => p.id === boostPlan) || boostPlans[1];

  async function load() {
    setLoading(true);
    try {
      const res = await fetch("/api/business-ads");
      const data = await res.json();
      if (data.ok) setAds(data.data || []);
    } catch {
      // ignore
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
  }, []);

  async function trackEvent(id: number, type: "view" | "whatsapp" | "link" | "buy") {
    try {
      fetch("/api/business-ads/click", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id, type }),
      }).catch(() => {});
    } catch {}
  }

  async function handleBoostSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!boostAd) return;
    setBoostSending(true);

    try {
      const res = await fetch("/api/ads/boost", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          adType: "business",
          adId: boostAd.id,
          customerName: boostName,
          customerPhone: boostPhone,
          planName: currentBoostPlanObj.name,
          days: currentBoostPlanObj.days,
          amount: currentBoostPlanObj.price.toFixed(2),
          receiptUrl: boostReceiptUrl || null,
        }),
      });

      const data = await res.json();
      if (data.ok) {
        playSound("payment_confirmed");
        setBoostSuccess(true);
        load();
      } else {
        alert(data.error || "Erro ao solicitar impulsionamento.");
      }
    } catch {
      alert("Erro de conexão.");
    } finally {
      setBoostSending(false);
    }
  }

  function handleCopyPix() {
    navigator.clipboard.writeText(pixKey);
    setCopiedPix(true);
    setTimeout(() => setCopiedPix(false), 2000);
  }

  const categories = [
    { id: "all", label: "🌟 Todos os Negócios" },
    { id: "loja", label: "🛒 Lojas Virtuais" },
    { id: "produto", label: "📦 Produtos" },
    { id: "servico", label: "🛠️ Serviços" },
    { id: "promocao", label: "🔥 Promoções" },
    { id: "empresa", label: "🏢 Empresas" },
    { id: "site", label: "🌐 Sites & Apps" },
  ];

  const filteredAds = selectedCategory === "all"
    ? ads
    : ads.filter((a) => a.category?.toLowerCase() === selectedCategory.toLowerCase());

  return (
    <main className="min-h-screen bg-[#040817] text-slate-100 selection:bg-cyan-500 selection:text-black px-4 py-8 md:px-6 md:py-12">
      <div className="mx-auto max-w-6xl">
        {/* Navigation Breadcrumb */}
        <div className="flex flex-col md:flex-row items-center justify-between gap-4 border-b border-slate-800 pb-6">
          <Link
            href="/"
            className="inline-flex items-center gap-2 text-sm font-bold text-cyan-400 hover:text-cyan-300 transition-colors"
          >
            <ArrowLeft size={18} /> Voltar à Loja
          </Link>

          <div className="flex items-center gap-3">
            <Link
              href="/contatos-anuncios"
              className="rounded-2xl border border-amber-400/30 bg-amber-950/40 px-4 py-2 text-xs font-bold text-amber-300 hover:bg-amber-400 hover:text-slate-950 transition-all"
            >
              👤 Ver Contatos & Perfis
            </Link>
            <Link
              href="/divulgar-negocios"
              className="inline-flex items-center gap-2 rounded-2xl bg-gradient-to-r from-blue-600 via-cyan-400 to-blue-500 px-5 py-2.5 text-xs font-black uppercase text-slate-950 shadow-lg shadow-cyan-400/20 hover:scale-105 transition-all"
            >
              <PlusCircle size={16} /> Divulgar Minha Loja / Negócio
            </Link>
          </div>
        </div>

        {/* Header */}
        <div className="mt-8 text-center md:mt-10">
          <div className="inline-flex items-center gap-2 rounded-full bg-cyan-400/10 px-5 py-2 border border-cyan-400/30 shadow-md mb-3">
            <Store className="text-cyan-400" size={18} />
            <span className="text-xs font-black uppercase tracking-wider text-cyan-300">
              VITRINE DE LOJAS, SERVIÇOS & EMPREENDIMENTOS
            </span>
          </div>

          <h1 className="text-4xl font-black tracking-tight text-white md:text-6xl">
            DIVULGAÇÃO DE <span className="text-cyan-400">VENDAS & NEGÓCIOS</span>
          </h1>

          <p className="mx-auto mt-2 max-w-2xl text-sm md:text-base text-slate-300">
            Descubra produtos, lojas recomendadas, promoções exclusivas e serviços de qualidade anunciados na Sonic Vendas.
          </p>
        </div>

        {/* Category Pills */}
        <div className="mt-8 flex flex-wrap items-center justify-center gap-2">
          {categories.map((c) => (
            <button
              key={c.id}
              onClick={() => setSelectedCategory(c.id)}
              className={`rounded-xl px-4 py-2 text-xs font-bold transition-all ${
                selectedCategory === c.id
                  ? "bg-cyan-400 text-slate-950 font-black shadow-lg shadow-cyan-400/20 scale-105"
                  : "bg-slate-900 border border-slate-800 text-slate-300 hover:bg-slate-800"
              }`}
            >
              {c.label}
            </button>
          ))}
        </div>

        {/* Business Ads Grid */}
        <div className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {filteredAds.map((ad) => {
            const isBoosted = ad.isBoosted;
            const waUrl = `https://wa.me/55${ad.phone.replace(/\D/g, "")}?text=Olá,%20vi%20o%20anúncio%20de%20${encodeURIComponent(ad.businessName)}%20na%20Sonic%20Vendas!`;

            return (
              <div
                key={ad.id}
                onMouseEnter={() => trackEvent(ad.id, "view")}
                className={`group relative flex flex-col justify-between overflow-hidden rounded-3xl p-6 shadow-xl backdrop-blur-md transition-all hover:-translate-y-1 ${
                  isBoosted
                    ? "border-2 border-cyan-400 bg-gradient-to-b from-blue-950/60 via-slate-900 to-slate-950 shadow-cyan-400/20"
                    : "border border-slate-800 bg-slate-900/60 hover:border-slate-700"
                }`}
              >
                <div>
                  {/* Top Image + Badges */}
                  <div className="relative mb-4 h-56 w-full overflow-hidden rounded-2xl bg-slate-950">
                    <img
                      src={ad.photoUrl || "https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=600&q=80"}
                      alt={ad.businessName}
                      className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
                      onError={(e) => {
                        (e.target as HTMLImageElement).src = "https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=600&q=80";
                      }}
                    />
                    <div className="absolute top-3 left-3 flex flex-wrap gap-1">
                      {isBoosted && (
                        <span className="rounded-full bg-cyan-400 px-3 py-0.5 text-[10px] font-black uppercase text-slate-950 shadow-md flex items-center gap-1">
                          <Zap size={12} /> NEGÓCIO EM DESTAQUE
                        </span>
                      )}
                      <span className="rounded-full bg-slate-950/80 px-2.5 py-0.5 text-[10px] font-bold uppercase text-amber-400 backdrop-blur-md border border-amber-400/30">
                        {ad.category}
                      </span>
                    </div>

                    {ad.productPrice && (
                      <div className="absolute bottom-3 right-3 rounded-xl bg-amber-400 px-3 py-1 text-xs font-black text-slate-950 shadow-lg">
                        R$ {Number(ad.productPrice).toFixed(2)}
                      </div>
                    )}
                  </div>

                  <span className="text-xs font-bold text-cyan-400 uppercase tracking-wider block">
                    {ad.businessName}
                  </span>

                  <h3 className="text-lg font-black text-white group-hover:text-cyan-300 transition-colors mt-0.5">
                    {ad.adTitle}
                  </h3>

                  <p className="mt-2 line-clamp-3 text-xs text-slate-300 leading-relaxed">
                    {ad.description}
                  </p>

                  {/* Video link */}
                  {ad.videoUrl && (
                    <a
                      href={ad.videoUrl}
                      target="_blank"
                      rel="noreferrer"
                      className="mt-3 inline-flex items-center gap-1.5 rounded-lg bg-blue-950/40 border border-blue-500/30 px-2.5 py-1 text-[11px] font-bold text-cyan-300 hover:bg-cyan-500 hover:text-slate-950 transition-colors"
                    >
                      <Video size={13} /> Assistir Vídeo do Negócio
                    </a>
                  )}

                  {/* Metrics preview */}
                  <div className="mt-4 flex flex-wrap items-center gap-3 text-[11px] text-slate-400 border-t border-slate-800/80 pt-3">
                    <span className="flex items-center gap-1">
                      <Eye size={13} /> {ad.viewsCount || 0} views
                    </span>
                    <span className="flex items-center gap-1">
                      <MessageCircle size={13} /> {ad.clicksWhatsapp || 0} contatos
                    </span>
                    {ad.clicksBuy > 0 && (
                      <span className="flex items-center gap-1 text-amber-400">
                        <ShoppingBag size={13} /> {ad.clicksBuy} compras
                      </span>
                    )}
                  </div>
                </div>

                {/* Actions & WhatsApp button */}
                <div className="mt-5 space-y-2">
                  <a
                    href={waUrl}
                    target="_blank"
                    rel="noreferrer"
                    onClick={() => trackEvent(ad.id, "whatsapp")}
                    className="flex w-full items-center justify-center gap-2 rounded-2xl bg-emerald-500 py-3 text-xs font-black uppercase tracking-wider text-slate-950 shadow-lg shadow-emerald-500/20 hover:bg-emerald-400 transition-all"
                  >
                    <MessageCircle size={16} /> Falar no WhatsApp Comercial
                  </a>

                  <div className="flex gap-2">
                    {ad.buyLink && (
                      <a
                        href={ad.buyLink}
                        target="_blank"
                        rel="noreferrer"
                        onClick={() => trackEvent(ad.id, "buy")}
                        className="flex-1 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-500 py-2 text-center text-xs font-black uppercase text-slate-950 hover:brightness-110 shadow-md"
                      >
                        Comprar / Ver Site <ExternalLink size={12} className="inline ml-1" />
                      </a>
                    )}
                    <button
                      type="button"
                      onClick={() => {
                        setBoostAd(ad);
                        setBoostName(ad.businessName);
                        setBoostPhone(ad.phone);
                        setBoostSuccess(false);
                      }}
                      className="rounded-xl border border-cyan-400/40 bg-blue-950/40 px-3 py-2 text-xs font-black text-cyan-300 hover:bg-cyan-400 hover:text-slate-950 transition-all flex items-center gap-1"
                    >
                      <Zap size={14} /> Impulsionar
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {filteredAds.length === 0 && !loading && (
          <div className="mt-12 rounded-3xl border border-slate-800 bg-slate-900/40 p-12 text-center text-slate-500 shadow-xl">
            Nenhum anúncio nesta categoria no momento.
            <div className="mt-4">
              <Link
                href="/divulgar-negocios"
                className="inline-flex items-center gap-2 rounded-xl bg-cyan-400 px-5 py-2.5 text-xs font-black uppercase text-slate-950 hover:bg-cyan-300 transition-all"
              >
                Cadastrar o Primeiro Negócio
              </Link>
            </div>
          </div>
        )}
      </div>

      {/* Boost Modal */}
      {boostAd && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 backdrop-blur-md">
          <div className="relative w-full max-w-lg rounded-3xl border-2 border-cyan-400/50 bg-slate-950 p-6 md:p-8 shadow-2xl">
            <button
              onClick={() => setBoostAd(null)}
              className="absolute top-6 right-6 rounded-full bg-slate-800 p-2 text-slate-400 hover:bg-slate-700 hover:text-white"
            >
              ✕
            </button>

            {!boostSuccess ? (
              <form onSubmit={handleBoostSubmit} className="space-y-4">
                <div className="border-b border-slate-800 pb-3">
                  <span className="text-[10px] font-black uppercase tracking-widest text-cyan-400">
                    IMPULSIONAR ANÚNCIO DE NEGÓCIOS
                  </span>
                  <h3 className="text-xl font-black text-white">{boostAd.businessName}</h3>
                  <p className="text-xs text-slate-400">Destaque prioritário no Topo e na vitrine principal.</p>
                </div>

                <div>
                  <label className="mb-1 block text-xs font-bold text-slate-300">Escolha o Plano de Impulsionamento</label>
                  <div className="space-y-2">
                    {boostPlans.map((plan) => (
                      <div
                        key={plan.id}
                        onClick={() => setBoostPlan(plan.id)}
                        className={`cursor-pointer rounded-2xl p-3 border flex items-center justify-between text-xs transition-all ${
                          boostPlan === plan.id
                            ? "border-cyan-400 bg-blue-950/60 text-white font-bold"
                            : "border-slate-800 bg-slate-900 text-slate-400 hover:bg-slate-800"
                        }`}
                      >
                        <div>
                          <span className="font-black text-white block">{plan.name}</span>
                          <span className="text-[10px] text-slate-400">{plan.days} dias de destaque no Topo</span>
                        </div>
                        <span className="text-base font-black text-amber-400">R$ {plan.price.toFixed(2)}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="grid gap-3 md:grid-cols-2">
                  <div>
                    <label className="mb-1 block text-xs font-bold text-slate-300">Responsável</label>
                    <input
                      type="text"
                      required
                      value={boostName}
                      onChange={(e) => setBoostName(e.target.value)}
                      className="w-full rounded-xl bg-slate-900 border border-slate-700 px-3 py-2 text-xs text-white"
                    />
                  </div>
                  <div>
                    <label className="mb-1 block text-xs font-bold text-slate-300">WhatsApp</label>
                    <input
                      type="text"
                      required
                      value={boostPhone}
                      onChange={(e) => setBoostPhone(e.target.value)}
                      className="w-full rounded-xl bg-slate-900 border border-slate-700 px-3 py-2 text-xs text-white"
                    />
                  </div>
                </div>

                {/* Comprovante Pix upload */}
                <div className="rounded-2xl border border-cyan-400/40 bg-slate-900 p-4">
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-xs font-bold text-cyan-300">Pagar R$ {currentBoostPlanObj.price.toFixed(2)} via Pix:</span>
                    <button
                      type="button"
                      onClick={handleCopyPix}
                      className="text-[10px] text-emerald-400 hover:underline font-bold"
                    >
                      {copiedPix ? "Chave Copiada!" : `Copiar Pix: ${pixKey}`}
                    </button>
                  </div>
                  <input
                    type="text"
                    placeholder="Cole a URL ou foto do comprovante..."
                    value={boostReceiptUrl}
                    onChange={(e) => setBoostReceiptUrl(e.target.value)}
                    className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-xs text-white"
                  />
                </div>

                <button
                  type="submit"
                  disabled={boostSending}
                  className="w-full rounded-2xl bg-gradient-to-r from-blue-600 via-cyan-400 to-blue-500 py-3.5 text-xs font-black uppercase text-slate-950 hover:brightness-110 shadow-lg shadow-cyan-400/20 disabled:opacity-60"
                >
                  {boostSending ? "Enviando..." : `Confirmar Impulsionamento (R$ ${currentBoostPlanObj.price.toFixed(2)})`}
                </button>
              </form>
            ) : (
              <div className="text-center space-y-4 py-4">
                <div className="text-4xl">🚀</div>
                <h4 className="text-xl font-black text-white">Solicitação de Impulsionamento Enviada!</h4>
                <p className="text-xs text-slate-300">
                  O administrador irá conferir o comprovante e ativar o destaque de <strong>{currentBoostPlanObj.name}</strong> para {boostAd.businessName}.
                </p>
                <button
                  onClick={() => setBoostAd(null)}
                  className="rounded-2xl bg-cyan-400 px-6 py-2.5 text-xs font-black uppercase text-slate-950 hover:bg-cyan-300"
                >
                  Fechar
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </main>
  );
}
