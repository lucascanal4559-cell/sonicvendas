"use client";
import React, { useState, useEffect } from "react";
import Link from "next/link";
import {
  Briefcase,
  ArrowLeft,
  Sparkles,
  Camera,
  Video,
  Phone,
  Mail,
  MapPin,
  Calendar,
  CheckCircle2,
  Copy,
  Check,
  ShieldCheck,
  UploadCloud,
  Coins,
  Store,
  DollarSign,
  Tag,
  Link2,
} from "lucide-react";
import { playSound } from "@/lib/sounds";

export default function DivulgarNegociosPage() {
  const [form, setForm] = useState({
    businessName: "",
    adTitle: "",
    description: "",
    category: "loja",
    photoUrl: "",
    videoUrl: "",
    productPrice: "",
    buyLink: "",
    phone: "",
    email: "",
    location: "",
    days: 15,
  });

  const [receiptUrl, setReceiptUrl] = useState("");
  const [loading, setLoading] = useState(false);
  const [calculatingAi, setCalculatingAi] = useState(false);
  const [aiBreakdown, setAiBreakdown] = useState<any | null>(null);
  const [createdAd, setCreatedAd] = useState<any | null>(null);
  const [copiedPix, setCopiedPix] = useState(false);

  const pixKey = "75981558007";

  // Calculate AI budget suggestion whenever days, category, video or buyLink changes
  useEffect(() => {
    async function calculatePrice() {
      setCalculatingAi(true);
      try {
        const res = await fetch("/api/business-ads/ai-price", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            days: form.days,
            category: form.category,
            hasVideo: !!form.videoUrl,
            hasBuyLink: !!form.buyLink,
            placement: "home_destaque",
            boostRequested: false,
          }),
        });
        const data = await res.json();
        if (data.ok) {
          setAiBreakdown(data.data);
        }
      } catch {
        // ignore
      } finally {
        setCalculatingAi(false);
      }
    }

    const timer = setTimeout(calculatePrice, 400);
    return () => clearTimeout(timer);
  }, [form.days, form.category, form.videoUrl, form.buyLink]);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);

    try {
      const res = await fetch("/api/business-ads", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...form,
          calculatedPrice: aiBreakdown?.total || (form.days * 2.5).toFixed(2),
          aiPricingBreakdown: aiBreakdown?.breakdown || "Orçamento calculado pela IA com base em categoria e duração.",
          receiptUrl: receiptUrl || null,
        }),
      });

      const data = await res.json();
      if (data.ok) {
        playSound("new_order");
        setCreatedAd(data.data);
      } else {
        alert(data.error || "Erro ao registrar anúncio de negócios.");
      }
    } catch {
      alert("Erro de conexão ao enviar.");
    } finally {
      setLoading(false);
    }
  }

  function handleCopyPix() {
    navigator.clipboard.writeText(pixKey);
    setCopiedPix(true);
    setTimeout(() => setCopiedPix(false), 2000);
  }

  const currentPrice = aiBreakdown?.total || (form.days * 2.5).toFixed(2);

  return (
    <main className="min-h-screen bg-[#040817] text-slate-100 selection:bg-cyan-500 selection:text-black px-4 py-8 md:px-6 md:py-12">
      <div className="mx-auto max-w-4xl">
        {/* Navigation Breadcrumb */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-6">
          <Link
            href="/negocios-anuncios"
            className="inline-flex items-center gap-2 text-sm font-bold text-cyan-400 hover:text-cyan-300 transition-colors"
          >
            <ArrowLeft size={18} /> Ver Todos os Anúncios de Negócios
          </Link>

          <Link
            href="/divulgar-contatos"
            className="rounded-xl border border-amber-400/30 bg-amber-950/40 px-3.5 py-1.5 text-xs font-black uppercase text-amber-300 hover:bg-amber-400 hover:text-slate-950 transition-all"
          >
            👤 Divulgação Pessoal / Contatos (R$ 1/dia)
          </Link>
        </div>

        {/* Header */}
        <div className="mt-8 text-center md:mt-10">
          <div className="inline-flex items-center gap-2 rounded-full bg-cyan-400/10 px-5 py-2 border border-cyan-400/30 shadow-md mb-3">
            <Store className="text-cyan-400" size={18} />
            <span className="text-xs font-black uppercase tracking-wider text-cyan-300">
              DIVULGAÇÃO DE VENDAS & NEGÓCIOS • ORÇAMENTO INTELIGENTE IA
            </span>
          </div>

          <h1 className="text-3xl font-black tracking-tight text-white md:text-5xl">
            DIVULGUE SUA <span className="text-cyan-400">LOJA, PRODUTO OU EMPRESA</span>
          </h1>

          <p className="mx-auto mt-2 max-w-2xl text-xs md:text-sm text-slate-300">
            Alcance novos clientes para sua loja, serviços, promoções ou projetos. Nossa Inteligência Artificial calcula o melhor orçamento personalizado para seu anúncio.
          </p>
        </div>

        {!createdAd ? (
          <form onSubmit={handleSubmit} className="mt-8 rounded-3xl border border-cyan-500/30 bg-gradient-to-b from-blue-950/60 via-slate-900 to-slate-950 p-6 md:p-8 shadow-2xl backdrop-blur-xl space-y-5">
            <div className="border-b border-slate-800 pb-3">
              <h3 className="text-lg font-black text-white flex items-center gap-2">
                <Store className="text-cyan-400" size={20} />
                Dados do Seu Negócio ou Serviço
              </h3>
            </div>

            <div className="grid gap-4 md:grid-cols-2">
              <div>
                <label className="mb-1 block text-xs font-bold text-slate-300">Nome da Empresa / Loja / Marca *</label>
                <input
                  type="text"
                  required
                  placeholder="Ex: Sonic Tech Store"
                  value={form.businessName}
                  onChange={(e) => setForm({ ...form, businessName: e.target.value })}
                  className="w-full rounded-2xl border border-slate-700 bg-slate-950 px-4 py-3 text-sm text-white focus:border-cyan-400 focus:outline-none"
                />
              </div>

              <div>
                <label className="mb-1 block text-xs font-bold text-slate-300">Categoria do Negócio</label>
                <select
                  value={form.category}
                  onChange={(e) => setForm({ ...form, category: e.target.value })}
                  className="w-full rounded-2xl border border-slate-700 bg-slate-950 px-4 py-3 text-sm text-white focus:border-cyan-400 focus:outline-none"
                >
                  <option value="loja">🛒 Loja Virtual / E-commerce</option>
                  <option value="produto">📦 Produto Físico ou Digital</option>
                  <option value="servico">🛠️ Prestação de Serviços</option>
                  <option value="promocao">🔥 Promoção / Oferta Relâmpago</option>
                  <option value="marca">👑 Marca / Branding</option>
                  <option value="empresa">🏢 Empresa / Estabelecimento Local</option>
                  <option value="site">🌐 Site / Aplicativo / Software</option>
                  <option value="projeto">🚀 Projeto / Empreendimento</option>
                </select>
              </div>
            </div>

            <div>
              <label className="mb-1 block text-xs font-bold text-slate-300">Título Chamativo do Anúncio *</label>
              <input
                type="text"
                required
                placeholder="Ex: iPhones Lacrados com 1 Ano de Garantia e Entrega em até 24h"
                value={form.adTitle}
                onChange={(e) => setForm({ ...form, adTitle: e.target.value })}
                className="w-full rounded-2xl border border-slate-700 bg-slate-950 px-4 py-3 text-sm text-white focus:border-cyan-400 focus:outline-none"
              />
            </div>

            <div className="grid gap-4 md:grid-cols-2">
              <div>
                <label className="mb-1 block text-xs font-bold text-slate-300">WhatsApp Comercial *</label>
                <input
                  type="text"
                  required
                  placeholder="(75) 98155-8007"
                  value={form.phone}
                  onChange={(e) => setForm({ ...form, phone: e.target.value })}
                  className="w-full rounded-2xl border border-slate-700 bg-slate-950 px-4 py-3 text-sm text-white focus:border-cyan-400 focus:outline-none"
                />
              </div>

              <div>
                <label className="mb-1 block text-xs font-bold text-slate-300">Localização / Cidade ou "Online / Brasil"</label>
                <input
                  type="text"
                  placeholder="Ex: São Paulo - SP ou Envio para todo o Brasil"
                  value={form.location}
                  onChange={(e) => setForm({ ...form, location: e.target.value })}
                  className="w-full rounded-2xl border border-slate-700 bg-slate-950 px-4 py-3 text-sm text-white focus:border-cyan-400 focus:outline-none"
                />
              </div>
            </div>

            <div className="grid gap-4 md:grid-cols-2">
              <div>
                <label className="mb-1 block text-xs font-bold text-slate-300">Preço do Produto/Serviço (Opcional R$)</label>
                <input
                  type="text"
                  placeholder="Ex: 199.90"
                  value={form.productPrice}
                  onChange={(e) => setForm({ ...form, productPrice: e.target.value })}
                  className="w-full rounded-2xl border border-slate-700 bg-slate-950 px-4 py-3 text-sm text-white focus:border-cyan-400 focus:outline-none"
                />
              </div>

              <div>
                <label className="mb-1 block text-xs font-bold text-slate-300">Link de Compra Direta ou Site (Opcional)</label>
                <input
                  type="text"
                  placeholder="https://seusite.com/produto"
                  value={form.buyLink}
                  onChange={(e) => setForm({ ...form, buyLink: e.target.value })}
                  className="w-full rounded-2xl border border-slate-700 bg-slate-950 px-4 py-3 text-sm text-white focus:border-cyan-400 focus:outline-none"
                />
              </div>
            </div>

            <div className="grid gap-4 md:grid-cols-2">
              <div>
                <label className="mb-1 block text-xs font-bold text-slate-300">URL da Foto / Banner do Anúncio</label>
                <input
                  type="text"
                  placeholder="https://images.unsplash.com/..."
                  value={form.photoUrl}
                  onChange={(e) => setForm({ ...form, photoUrl: e.target.value })}
                  className="w-full rounded-2xl border border-slate-700 bg-slate-950 px-4 py-3 text-xs text-white focus:border-cyan-400 focus:outline-none"
                />
              </div>

              <div>
                <label className="mb-1 block text-xs font-bold text-slate-300">Vídeo Comercial (Até 2 min)</label>
                <input
                  type="text"
                  placeholder="Link do vídeo (MP4 / WebM / YouTube)"
                  value={form.videoUrl}
                  onChange={(e) => setForm({ ...form, videoUrl: e.target.value })}
                  className="w-full rounded-2xl border border-slate-700 bg-slate-950 px-4 py-3 text-xs text-white focus:border-cyan-400 focus:outline-none"
                />
              </div>
            </div>

            <div>
              <label className="mb-1 block text-xs font-bold text-slate-300">Descrição Completa da Oferta / Serviço *</label>
              <textarea
                required
                rows={3}
                placeholder="Descreva detalhadamente seus diferenciais, garantia, formas de envio, parcelamento e condições especiais..."
                value={form.description}
                onChange={(e) => setForm({ ...form, description: e.target.value })}
                className="w-full rounded-2xl border border-slate-700 bg-slate-950 px-4 py-3 text-sm text-white focus:border-cyan-400 focus:outline-none"
              />
            </div>

            <div>
              <label className="mb-1 block text-xs font-bold text-slate-300">Período de Divulgação (Dias)</label>
              <div className="grid grid-cols-4 gap-2 mb-2">
                {[7, 15, 30, 60].map((d) => (
                  <button
                    key={d}
                    type="button"
                    onClick={() => setForm({ ...form, days: d })}
                    className={`rounded-xl py-2 text-xs font-bold transition-all ${
                      form.days === d
                        ? "bg-cyan-400 text-slate-950 font-black shadow-md shadow-cyan-400/20"
                        : "bg-slate-950 border border-slate-800 text-slate-300"
                    }`}
                  >
                    {d} dias {d >= 30 ? "(25% OFF)" : d >= 15 ? "(15% OFF)" : ""}
                  </button>
                ))}
              </div>
              <input
                type="number"
                min={1}
                max={365}
                value={form.days}
                onChange={(e) => setForm({ ...form, days: Math.max(1, parseInt(e.target.value || "1", 10)) })}
                className="w-full rounded-2xl border border-slate-700 bg-slate-950 px-4 py-2.5 text-sm text-white focus:border-cyan-400 focus:outline-none"
              />
            </div>

            {/* Smart AI Pricing Assistant Card */}
            {aiBreakdown && (
              <div className="rounded-2xl border-2 border-cyan-400/50 bg-gradient-to-r from-blue-950/70 to-slate-950 p-5 shadow-xl">
                <div className="flex items-center justify-between border-b border-cyan-500/20 pb-3 mb-3">
                  <div className="flex items-center gap-2 text-cyan-300 font-black text-xs uppercase">
                    <Sparkles size={16} /> Orçamento Inteligente Sugerido pela IA
                  </div>
                  <span className="text-2xl font-black text-amber-400">R$ {currentPrice}</span>
                </div>

                <pre className="text-xs font-mono text-slate-300 whitespace-pre-wrap leading-relaxed">
                  {aiBreakdown.breakdown}
                </pre>
                <p className="mt-2 text-[10px] text-slate-400">
                  O valor final poderá ser ajustado ou aprovado pelo administrador antes da veiculação oficial.
                </p>
              </div>
            )}

            {/* Comprovante Pix Upload with Glowing Highlight */}
            <div className="rounded-2xl border-2 border-cyan-400/60 bg-slate-950 p-5 shadow-lg animate-pulse-gentle">
              <div className="flex items-center gap-2 mb-2">
                <UploadCloud className="text-cyan-400 animate-bounce" size={20} />
                <span className="text-xs font-black uppercase tracking-wider text-cyan-300">
                  ANEXAR COMPROVANTE PIX (CHAVE: 75981558007)
                </span>
              </div>
              <p className="text-xs text-slate-400 mb-3">
                Faça o Pix de <strong>R$ {currentPrice}</strong> para a chave <code>{pixKey}</code> e anexe o link ou foto do comprovante abaixo:
              </p>
              <input
                type="text"
                placeholder="Cole o link ou foto do comprovante Pix..."
                value={receiptUrl}
                onChange={(e) => setReceiptUrl(e.target.value)}
                className="w-full rounded-xl border border-cyan-400/40 bg-slate-900 px-4 py-2.5 text-xs text-white focus:border-cyan-400 focus:outline-none"
              />
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full rounded-2xl bg-gradient-to-r from-blue-600 via-cyan-400 to-blue-500 py-4 text-base font-black uppercase tracking-wider text-slate-950 shadow-xl shadow-cyan-400/20 hover:brightness-110 transition-all disabled:opacity-60"
            >
              {loading ? "Registrando Anúncio..." : `Publicar Anúncio de Negócios (R$ ${currentPrice})`}
            </button>
          </form>
        ) : (
          /* Confirmation card with Pix Key */
          <div className="mt-8 rounded-3xl border-2 border-cyan-400 bg-slate-950 p-8 text-center space-y-4">
            <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-cyan-400/20 text-3xl text-cyan-400">
              ✓
            </div>
            <h3 className="text-2xl font-black text-white">Anúncio de Negócios Registrado!</h3>
            <p className="text-xs text-slate-300 max-w-md mx-auto">
              Sua empresa <strong>{createdAd.businessName}</strong> foi cadastrada para veiculação de {createdAd.days} dias por R$ {Number(createdAd.calculatedPrice).toFixed(2)}. O administrador analisará a proposta e o comprovante.
            </p>

            <div className="rounded-2xl border border-slate-800 bg-slate-900 p-4 max-w-md mx-auto text-left">
              <span className="text-xs font-bold text-slate-400 block mb-1">Chave Pix para Pagamento:</span>
              <div className="flex items-center justify-between">
                <code className="text-base font-mono font-black text-cyan-400">{pixKey}</code>
                <button
                  type="button"
                  onClick={handleCopyPix}
                  className="flex items-center gap-1 rounded-xl bg-cyan-400 px-3 py-1.5 text-xs font-black text-slate-950 hover:bg-cyan-300 transition-colors"
                >
                  {copiedPix ? <Check size={14} /> : <Copy size={14} />}
                  <span>{copiedPix ? "Copiado!" : "Copiar Pix"}</span>
                </button>
              </div>
            </div>

            <div className="flex justify-center gap-3 pt-4">
              <Link
                href="/negocios-anuncios"
                className="rounded-2xl bg-cyan-400 px-6 py-3 text-xs font-black uppercase text-slate-950 hover:bg-cyan-300"
              >
                Ver Anúncios de Negócios
              </Link>
              <button
                type="button"
                onClick={() => setCreatedAd(null)}
                className="rounded-2xl border border-slate-700 bg-slate-900 px-6 py-3 text-xs font-bold text-slate-300 hover:text-white"
              >
                Cadastrar Outro Negócio
              </button>
            </div>
          </div>
        )}
      </div>
    </main>
  );
}
