"use client";
import { useState, useEffect } from "react";
import Link from "next/link";
import { ArrowLeft, User, Image as ImageIcon, Text, Users, Save } from "lucide-react";

export default function PerfilPage() {
  const [token, setToken] = useState("");
  const [user, setUser] = useState<any>(null);
  const [groups, setGroups] = useState<any[]>([]);
  const [form, setForm] = useState({ name: "", description: "", imageUrl: "" });
  const [groupForm, setGroupForm] = useState({ name: "", description: "", imageUrl: "", linkUrl: "" });
  const [saving, setSaving] = useState(false);
  const [groupSaving, setGroupSaving] = useState(false);
  const [message, setMessage] = useState("");

  useEffect(() => {
    const t = localStorage.getItem("sonic_customer_token") || "";
    setToken(t);
    if (t) {
      fetch("/api/customers/me", { headers: { Authorization: `Bearer ${t}` } })
        .then((r) => r.json())
        .then((d) => {
          if (d.ok) setUser(d.user);
        });
    }
    fetch("/api/groups").then((r) => r.json()).then((d) => {
      if (d.ok) setGroups(d.data || []);
    });
  }, []);

  if (!token) {
    return (
      <main className="min-h-screen bg-gradient-to-b from-slate-950 via-slate-900 to-amber-950/20 px-6 py-12 text-center">
        <h1 className="text-3xl font-extrabold text-white">Acesso restrito</h1>
        <Link href="/login" className="mt-6 inline-block rounded-xl bg-amber-400 px-6 py-3 text-sm font-extrabold text-slate-950 hover:bg-amber-300 transition-all">Fazer login</Link>
      </main>
    );
  }

  async function handleProfileSave(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    setMessage("");
    try {
      const res = await fetch("/api/customers/update", {
        method: "PUT",
        headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
        body: JSON.stringify({ name: form.name, profileImage: form.imageUrl }),
      });
      const data = await res.json();
      if (data.ok) {
        setMessage("Perfil atualizado!");
        setUser(data.user);
      } else {
        setMessage("Erro ao atualizar.");
      }
    } catch {
      setMessage("Erro de conexão.");
    } finally {
      setSaving(false);
    }
  }

  async function handleGroupCreate(e: React.FormEvent) {
    e.preventDefault();
    setGroupSaving(true);
    setMessage("");
    try {
      const res = await fetch("/api/groups/create", {
        method: "POST",
        headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
        body: JSON.stringify({ name: groupForm.name, description: groupForm.description, imageUrl: groupForm.imageUrl, linkUrl: groupForm.linkUrl }),
      });
      const data = await res.json();
      if (data.ok) {
        setMessage("Grupo criado! Taxa de R$ 10,00 aplicada.");
        setGroupForm({ name: "", description: "", imageUrl: "", linkUrl: "" });
      } else {
        setMessage("Erro ao criar grupo.");
      }
    } catch {
      setMessage("Erro de conexão.");
    } finally {
      setGroupSaving(false);
    }
  }

  return (
    <main className="min-h-screen bg-gradient-to-b from-slate-950 via-slate-900 to-amber-950/20 px-6 py-12">
      <div className="mx-auto max-w-5xl">
        <Link href="/" className="inline-flex items-center gap-2 text-sm font-bold text-amber-400 hover:text-amber-300 transition-colors mb-8"><ArrowLeft size={18} /> Voltar</Link>
        <h1 className="text-4xl font-extrabold tracking-tight text-white">Meu Perfil</h1>
        <p className="mt-2 text-sm text-slate-400">Gerencie seus dados, foto, descrição e grupos.</p>

        <div className="mt-8 grid gap-8 md:grid-cols-3">
          {/* Perfil */}
          <div className="rounded-3xl border border-slate-800 bg-slate-900/60 p-6 shadow-xl md:col-span-2">
            <h2 className="text-lg font-bold text-amber-400 mb-4">Dados Pessoais</h2>
            <div className="flex gap-6 items-start">
              <img src={user?.profileImage || "https://placehold.co/120x120?text=Foto"} alt="Perfil" className="h-24 w-24 rounded-3xl object-cover bg-slate-950 shadow-lg" />
              <div className="flex-1">
                <h3 className="text-xl font-extrabold text-slate-100">{user?.name || "Cliente"}</h3>
                <p className="text-sm text-slate-400">{user?.email}</p>
                <form onSubmit={handleProfileSave} className="mt-4 space-y-3">
                  <div>
                    <label htmlFor="profileName" className="text-xs font-bold text-slate-300">Nome</label>
                    <input id="profileName" type="text" value={form.name || user?.name || ""} onChange={(e) => setForm({ ...form, name: e.target.value })} className="w-full rounded-xl bg-slate-950 border border-slate-700 px-4 py-2 text-sm text-slate-100 focus:border-amber-400 focus:outline-none" />
                  </div>
                  <div>
                    <label htmlFor="profileDesc" className="text-xs font-bold text-slate-300">Descrição</label>
                    <textarea id="profileDesc" value={form.description || ""} onChange={(e) => setForm({ ...form, description: e.target.value })} className="w-full rounded-xl bg-slate-950 border border-slate-700 px-4 py-2 text-sm text-slate-100 focus:border-amber-400 focus:outline-none" rows={2} placeholder="Fale um pouco sobre você..." />
                  </div>
                  <div>
                    <label htmlFor="profileImage" className="text-xs font-bold text-slate-300">URL da Foto</label>
                    <input id="profileImage" type="text" value={form.imageUrl || user?.profileImage || ""} onChange={(e) => setForm({ ...form, imageUrl: e.target.value })} className="w-full rounded-xl bg-slate-950 border border-slate-700 px-4 py-2 text-sm text-slate-100 focus:border-amber-400 focus:outline-none" placeholder="https://..." />
                  </div>
                  <button type="submit" disabled={saving} className="rounded-xl bg-amber-400 px-5 py-2.5 text-sm font-extrabold text-slate-950 hover:bg-amber-300 disabled:opacity-60 transition-all shadow-lg shadow-amber-400/20">Salvar Perfil</button>
                </form>
                {message && <div className="mt-3 rounded-xl border border-amber-400/30 bg-amber-400/10 px-4 py-2 text-sm text-amber-300">{message}</div>}
              </div>
            </div>
          </div>

          {/* Grupos */}
          <div className="rounded-3xl border border-slate-800 bg-slate-900/60 p-6 shadow-xl">
            <h2 className="text-lg font-bold text-amber-400 mb-4">Criar Grupo</h2>
            <p className="text-xs text-slate-500 mb-4">Taxa de participação: <span className="font-bold text-amber-400">R$ 10,00</span></p>
            <form onSubmit={handleGroupCreate} className="space-y-3">
              <input type="text" placeholder="Nome do grupo" value={groupForm.name} onChange={(e) => setGroupForm({ ...groupForm, name: e.target.value })} className="w-full rounded-xl bg-slate-950 border border-slate-700 px-4 py-2 text-sm text-slate-100 focus:border-amber-400 focus:outline-none" required />
              <textarea placeholder="Descrição" value={groupForm.description} onChange={(e) => setGroupForm({ ...groupForm, description: e.target.value })} className="w-full rounded-xl bg-slate-950 border border-slate-700 px-4 py-2 text-sm text-slate-100 focus:border-amber-400 focus:outline-none" rows={2} />
              <input type="text" placeholder="URL da imagem do grupo" value={groupForm.imageUrl} onChange={(e) => setGroupForm({ ...groupForm, imageUrl: e.target.value })} className="w-full rounded-xl bg-slate-950 border border-slate-700 px-4 py-2 text-sm text-slate-100 focus:border-amber-400 focus:outline-none" />
              <input type="text" placeholder="Link do grupo" value={groupForm.linkUrl} onChange={(e) => setGroupForm({ ...groupForm, linkUrl: e.target.value })} className="w-full rounded-xl bg-slate-950 border border-slate-700 px-4 py-2 text-sm text-slate-100 focus:border-amber-400 focus:outline-none" />
              <button type="submit" disabled={groupSaving} className="w-full rounded-xl bg-amber-400 px-5 py-2.5 text-sm font-extrabold text-slate-950 hover:bg-amber-300 disabled:opacity-60 transition-all shadow-lg shadow-amber-400/20">Criar Grupo (R$ 10,00)</button>
            </form>
          </div>

          {/* Meus Grupos */}
          <div className="md:col-span-2 rounded-3xl border border-slate-800 bg-slate-900/60 p-6 shadow-xl">
            <h2 className="text-lg font-bold text-amber-400 mb-4">Meus Grupos</h2>
            <div className="grid gap-4 md:grid-cols-2">
              {groups.map((g: any) => (
                <a key={g.id} href={g.linkUrl || "#"} className="rounded-2xl border border-slate-800 bg-slate-950 p-4 shadow-lg hover:bg-slate-900 transition-colors flex gap-4 items-center">
                  <img src={g.imageUrl || "https://placehold.co/100x100?text=Grupo"} alt={g.name} className="h-16 w-16 rounded-xl object-cover bg-slate-900 shrink-0" />
                  <div>
                    <h4 className="font-extrabold text-slate-100">{g.name}</h4>
                    <p className="text-xs text-slate-500">{g.description || "Grupo da comunidade Sonic Vendas."}</p>
                    <span className="inline-block mt-2 rounded-full bg-amber-400/10 px-3 py-0.5 text-[10px] font-extrabold text-amber-400">Taxa: R$ 10,00</span>
                  </div>
                </a>
              ))}
            </div>
          </div>
        </div>
      </div>
    </main>
  );
}
