"use client";
import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { ArrowLeft, Image as ImageIcon, Video, Calendar, CheckCircle } from "lucide-react";

export default function DivulgarPage() {
  const [token, setToken] = useState("");
  const [form, setForm] = useState({ name: "", description: "", imageUrl: "", videoUrl: "", linkUrl: "", days: 7, contactPhone: "", contactEmail: "" });
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState("");
  const [success, setSuccess] = useState(false);
  const router = useRouter();

  useEffect(() => {
    setToken(localStorage.getItem("sonic_customer_token") || "");
  }, []);

  const price = form.days * 1.0;

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!token) {
      setMessage("Você precisa estar logado para criar uma divulgação.");
      return;
    }
    setSaving(true);
    setMessage("");
    try {
      const res = await fetch("/api/publications/create", {
        method: "POST",
        headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
        body: JSON.stringify({ name: form.name, description: form.description, imageUrl: form.imageUrl || null, videoUrl: form.videoUrl || null, linkUrl: form.linkUrl || null, days: form.days, price: price.toFixed(2) }),
      });
      const data = await res.json();
      if (data.ok) {
        setSuccess(true);
        setMessage("Divulgação enviada! Após a confirmação do pagamento, ela aparecerá no topo.");
        setForm({ name: "", description: "", imageUrl: "", videoUrl: "", linkUrl: "", days: 7, contactPhone: "", contactEmail: "" });
      } else {
        setMessage(data.error || "Erro ao enviar divulgação.");
      }
    } catch {
      setMessage("Erro de conexão.");
    } finally {
      setSaving(false);
    }
  }

  if (!token) {
    return (
      <main className="min-h-screen bg-gradient-to-b from-slate-950 via-slate-900 to-amber-950/20 px-6 py-12 text-center">
        <h1 className="text-3xl font-extrabold text-white">Acesso restrito</h1>
        <Link href="/login" className="mt-6 inline-block rounded-xl bg-amber-400 px-6 py-3 text-sm font-extrabold text-slate-950 hover:bg-amber-300 transition-all">Fazer login</Link>
      </main>
    );
  }

  return (
    <main className="min-h-screen bg-gradient-to-b from-slate-950 via-slate-900 to-amber-950/20 px-6 py-12">
      <div className="mx-auto max-w-3xl">
        <Link href="/" className="inline-flex items-center gap-2 text-sm font-bold text-amber-400 hover:text-amber-300 transition-colors mb-8"><ArrowLeft size={18} /> Voltar</Link>
        <h1 className="text-4xl font-extrabold tracking-tight text-white">Divulgue no Sonic Vendas</h1>
        <p className="mt-2 text-sm text-slate-400">Crie sua divulgação e apareça no topo do site. Taxa: R$ 1,00 por dia.</p>

        <form onSubmit={handleSubmit} className="mt-8 rounded-3xl border border-slate-800 bg-slate-900/60 p-8 shadow-xl space-y-4">
          <div>
            <label htmlFor="pubName" className="mb-1 block text-sm font-bold text-slate-300">Nome da divulgação</label>
            <input id="pubName" type="text" required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className="w-full rounded-xl bg-slate-950 border border-slate-700 px-4 py-3 text-sm text-slate-100 focus:border-amber-400 focus:outline-none" placeholder="Ex: Netflix, Fone Pro, Grupo VIP" />
          </div>
          <div>
            <label htmlFor="pubDesc" className="mb-1 block text-sm font-bold text-slate-300">Descrição</label>
            <textarea id="pubDesc" value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} className="w-full rounded-xl bg-slate-950 border border-slate-700 px-4 py-3 text-sm text-slate-100 focus:border-amber-400 focus:outline-none" rows={3} placeholder="Descreva seu produto, serviço ou projeto..." />
          </div>
          <div className="grid gap-4 md:grid-cols-2">
            <div>
              <label htmlFor="pubImage" className="mb-1 block text-sm font-bold text-slate-300">URL da Imagem</label>
              <input id="pubImage" type="text" value={form.imageUrl} onChange={(e) => setForm({ ...form, imageUrl: e.target.value })} className="w-full rounded-xl bg-slate-950 border border-slate-700 px-4 py-3 text-sm text-slate-100 focus:border-amber-400 focus:outline-none" placeholder="https://..." />
            </div>
            <div>
              <label htmlFor="pubVideo" className="mb-1 block text-sm font-bold text-slate-300">URL do Vídeo (até 1 min)</label>
              <input id="pubVideo" type="text" value={form.videoUrl} onChange={(e) => setForm({ ...form, videoUrl: e.target.value })} className="w-full rounded-xl bg-slate-950 border border-slate-700 px-4 py-3 text-sm text-slate-100 focus:border-amber-400 focus:outline-none" placeholder="https://..." />
            </div>
          </div>
          <div className="grid gap-4 md:grid-cols-2">
            <div>
              <label htmlFor="pubPhone" className="mb-1 block text-sm font-bold text-slate-300">Telefone / WhatsApp</label>
              <input id="pubPhone" type="text" value={form.contactPhone} onChange={(e) => setForm({ ...form, contactPhone: e.target.value })} className="w-full rounded-xl bg-slate-950 border border-slate-700 px-4 py-3 text-sm text-slate-100 focus:border-amber-400 focus:outline-none" placeholder="(11) 99999-9999" />
            </div>
            <div>
              <label htmlFor="pubEmail" className="mb-1 block text-sm font-bold text-slate-300">E-mail</label>
              <input id="pubEmail" type="email" value={form.contactEmail} onChange={(e) => setForm({ ...form, contactEmail: e.target.value })} className="w-full rounded-xl bg-slate-950 border border-slate-700 px-4 py-3 text-sm text-slate-100 focus:border-amber-400 focus:outline-none" placeholder="seu@email.com" />
            </div>
          </div>
          <div>
            <label htmlFor="pubLink" className="mb-1 block text-sm font-bold text-slate-300">Link de destino</label>
            <input id="pubLink" type="text" value={form.linkUrl} onChange={(e) => setForm({ ...form, linkUrl: e.target.value })} className="w-full rounded-xl bg-slate-950 border border-slate-700 px-4 py-3 text-sm text-slate-100 focus:border-amber-400 focus:outline-none" placeholder="https://seusite.com" />
          </div>
          <div>
            <label htmlFor="pubDays" className="mb-1 block text-sm font-bold text-slate-300">Dias de divulgação</label>
            <input id="pubDays" type="number" min={1} value={form.days} onChange={(e) => setForm({ ...form, days: parseInt(e.target.value || "1", 10) })} className="w-full rounded-xl bg-slate-950 border border-slate-700 px-4 py-3 text-sm text-slate-100 focus:border-amber-400 focus:outline-none" />
          </div>
          <div className="rounded-xl bg-amber-400/10 border border-amber-400/20 px-4 py-3 flex items-center justify-between">
            <span className="text-sm font-bold text-amber-400">Preço total:</span>
            <span className="text-2xl font-extrabold text-amber-400">R$ {price.toFixed(2)}</span>
          </div>
          <p className="text-xs text-slate-500">Valor: R$ 1,00 por dia. A divulgação ficará ativa após a confirmação do pagamento e aprovação administrativa.</p>
          {message && <div className="rounded-xl border border-amber-400/30 bg-amber-400/10 px-4 py-3 text-sm text-amber-300">{message}</div>}
          {success && <div className="rounded-xl border border-green-500/30 bg-green-500/10 px-4 py-3 text-sm text-green-300 flex items-center gap-2"><CheckCircle size={18} /> Divulgação enviada! Aguardando aprovação.</div>}
          <button type="submit" disabled={saving || success} className="w-full rounded-xl bg-amber-400 px-6 py-4 text-base font-extrabold text-slate-950 hover:bg-amber-300 disabled:opacity-60 transition-all shadow-xl shadow-amber-400/20">Enviar Divulgação (R$ {price.toFixed(2)})</button>
        </form>
      </div>
    </main>
  );
}
