"use client";
import React, { useState, useEffect, useRef } from "react";
import Link from "next/link";
import {
  Gift,
  Sparkles,
  ArrowLeft,
  Copy,
  Check,
  CheckCircle2,
  Trophy,
  Flame,
  Volume2,
  VolumeX,
} from "lucide-react";

export default function RoletaPage() {
  const [prizes, setPrizes] = useState<any[]>([]);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [spinning, setSpinning] = useState(false);
  const [rotation, setRotation] = useState(0);
  const [wonPrize, setWonPrize] = useState<any | null>(null);
  const [copied, setCopied] = useState(false);
  const [soundEnabled, setSoundEnabled] = useState(true);

  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    fetch("/api/roulette/prizes")
      .then((r) => r.json())
      .then((data) => {
        if (data.ok && data.data) {
          setPrizes(data.data);
        }
      });
  }, []);

  // Draw the wheel on canvas
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas || !prizes.length) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const numSlices = prizes.length;
    const arc = (2 * Math.PI) / numSlices;
    const radius = canvas.width / 2;

    ctx.clearRect(0, 0, canvas.width, canvas.height);

    prizes.forEach((prize, i) => {
      const angle = i * arc;
      ctx.beginPath();
      ctx.fillStyle = prize.color || (i % 2 === 0 ? "#06b6d4" : "#f59e0b");
      ctx.moveTo(radius, radius);
      ctx.arc(radius, radius, radius - 8, angle, angle + arc);
      ctx.lineTo(radius, radius);
      ctx.fill();
      ctx.stroke();

      // Border line
      ctx.strokeStyle = "#040817";
      ctx.lineWidth = 3;
      ctx.stroke();

      // Draw text
      ctx.save();
      ctx.translate(radius, radius);
      ctx.rotate(angle + arc / 2);
      ctx.textAlign = "right";
      ctx.fillStyle = "#ffffff";
      ctx.font = "bold 13px system-ui, sans-serif";
      ctx.shadowColor = "rgba(0,0,0,0.8)";
      ctx.shadowBlur = 4;
      ctx.fillText(prize.value || prize.title, radius - 20, 5);
      ctx.restore();
    });

    // Draw center hub
    ctx.beginPath();
    ctx.arc(radius, radius, 32, 0, 2 * Math.PI);
    ctx.fillStyle = "#040817";
    ctx.fill();
    ctx.strokeStyle = "#f59e0b";
    ctx.lineWidth = 4;
    ctx.stroke();

    ctx.beginPath();
    ctx.arc(radius, radius, 14, 0, 2 * Math.PI);
    ctx.fillStyle = "#f59e0b";
    ctx.fill();
  }, [prizes]);

  // Audio tone effect for tick and win
  function playTickSound(isWin = false) {
    if (!soundEnabled || typeof window === "undefined") return;
    try {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioCtx) return;
      const ctx = new AudioCtx();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = isWin ? "triangle" : "sine";
      osc.frequency.setValueAtTime(isWin ? 587.33 : 440, ctx.currentTime);
      if (isWin) {
        osc.frequency.exponentialRampToValueAtTime(880, ctx.currentTime + 0.3);
      }

      gain.gain.setValueAtTime(0.15, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + (isWin ? 0.4 : 0.08));

      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + (isWin ? 0.4 : 0.08));
    } catch {
      // Audio not permitted or supported
    }
  }

  async function handleSpin(e: React.FormEvent) {
    e.preventDefault();
    if (spinning || !prizes.length) return;
    if (!name || !email) {
      alert("Por favor, preencha seu nome e e-mail.");
      return;
    }

    setSpinning(true);
    setWonPrize(null);

    try {
      const res = await fetch("/api/roulette/spin", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          customerName: name,
          customerEmail: email,
          customerPhone: phone,
        }),
      });

      const data = await res.json();
      if (!data.ok) {
        alert(data.error || "Erro ao girar.");
        setSpinning(false);
        return;
      }

      const numSlices = prizes.length;
      const sliceAngle = 360 / numSlices;
      const targetIndex = data.prizeIndex || 0;

      // Pointer is at the top (270 deg or 90 deg depending on canvas coordinate)
      // Standard canvas 0 deg is right (3 o'clock). Top is 270 deg.
      const targetSliceCenter = targetIndex * sliceAngle + sliceAngle / 2;
      const stopAngle = 270 - targetSliceCenter;

      const extraRotations = 5 * 360; // 5 full turns
      const finalRotation = rotation + extraRotations + ((stopAngle - (rotation % 360) + 360) % 360);

      setRotation(finalRotation);

      // Sound interval
      const soundInterval = setInterval(() => playTickSound(false), 200);

      setTimeout(() => {
        clearInterval(soundInterval);
        playTickSound(true);
        setWonPrize(data.prize);
        setSpinning(false);
      }, 4000);
    } catch {
      alert("Erro de conexão ao girar.");
      setSpinning(false);
    }
  }

  function handleCopyCoupon(code: string) {
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  }

  return (
    <main className="min-h-screen bg-[#040817] text-slate-100 selection:bg-pink-500 selection:text-black">
      {/* Ambient background light */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden">
        <div className="absolute -top-40 left-1/2 -translate-x-1/2 w-[700px] h-[500px] bg-gradient-to-b from-pink-600/20 via-purple-600/15 to-transparent blur-3xl" />
        <div className="absolute top-[40%] -left-32 w-[400px] h-[400px] bg-pink-700/10 blur-[140px]" />
        <div className="absolute top-[60%] -right-32 w-[400px] h-[400px] bg-amber-600/10 blur-[140px]" />
      </div>

      <div className="relative z-10 mx-auto max-w-5xl px-4 py-8 md:px-6 md:py-12">
        {/* Navigation Breadcrumb */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-6">
          <Link
            href="/sorteios"
            className="inline-flex items-center gap-2 text-sm font-bold text-amber-400 hover:text-amber-300 transition-colors"
          >
            <ArrowLeft size={18} /> Voltar aos Sorteios
          </Link>

          <button
            type="button"
            onClick={() => setSoundEnabled(!soundEnabled)}
            className="flex items-center gap-1.5 rounded-full border border-slate-800 bg-slate-900 px-3 py-1.5 text-xs text-slate-300 hover:text-white"
          >
            {soundEnabled ? <Volume2 size={14} className="text-pink-400" /> : <VolumeX size={14} />}
            <span>{soundEnabled ? "Som Ativado" : "Mudo"}</span>
          </button>
        </div>

        {/* Header */}
        <div className="mt-8 text-center">
          <div className="inline-flex items-center gap-2 rounded-full bg-gradient-to-r from-pink-600/20 via-purple-600/20 to-pink-600/20 px-5 py-2 border border-pink-400/40 shadow-lg shadow-pink-500/20 mb-3 animate-pulse">
            <Gift className="text-pink-400" size={18} />
            <span className="text-xs font-black uppercase tracking-wider text-pink-300">
              ROLETA DA SORTE • GIRO PROMOCIONAL
            </span>
          </div>

          <h1 className="text-4xl font-black tracking-tight text-white md:text-6xl drop-shadow-[0_0_30px_rgba(236,72,153,0.5)]">
            GIRE E GANHE <span className="bg-gradient-to-r from-pink-400 via-purple-400 to-amber-300 bg-clip-text text-transparent">PRÊMIOS!</span>
          </h1>

          <p className="mx-auto mt-3 max-w-xl text-sm md:text-base text-slate-300">
            Preencha seus dados, gire a roleta e ganhe descontos exclusivos, cotas bônus e benefícios especiais na Sonic Vendas!
          </p>
        </div>

        {/* Wheel & Form Section */}
        <div className="mt-10 grid gap-10 md:grid-cols-12 items-center">
          {/* Left Canvas Wheel */}
          <div className="flex flex-col items-center justify-center md:col-span-6">
            <div className="relative flex items-center justify-center p-4">
              {/* Pointer indicator at Top */}
              <div className="absolute top-2 left-1/2 -translate-x-1/2 z-20 flex flex-col items-center">
                <div className="w-0 h-0 border-l-[14px] border-l-transparent border-r-[14px] border-r-transparent border-t-[28px] border-t-amber-400 filter drop-shadow-[0_4px_8px_rgba(0,0,0,0.6)] animate-bounce" />
              </div>

              {/* Glowing ring container */}
              <div className="rounded-full p-2.5 bg-gradient-to-tr from-pink-600 via-amber-400 to-purple-600 shadow-[0_0_50px_rgba(236,72,153,0.4)]">
                <canvas
                  ref={canvasRef}
                  width={340}
                  height={340}
                  className="rounded-full bg-slate-950 transition-transform duration-[4000ms] cubic-bezier(0.15,0.9,0.25,1)"
                  style={{
                    transform: `rotate(${rotation}deg)`,
                  }}
                />
              </div>
            </div>
          </div>

          {/* Right Form */}
          <div className="md:col-span-6">
            <div className="rounded-3xl border border-pink-500/30 bg-gradient-to-b from-slate-950 via-slate-900 to-slate-950 p-6 md:p-8 shadow-2xl backdrop-blur-xl">
              <h3 className="text-xl font-black text-white flex items-center gap-2">
                <Sparkles className="text-pink-400" size={20} />
                Seus Dados para o Giro da Sorte
              </h3>
              <p className="mt-1 text-xs text-slate-400">
                Seu cupom ou prêmio será enviado para o e-mail informado.
              </p>

              <form onSubmit={handleSpin} className="mt-6 space-y-4">
                <div>
                  <label className="mb-1 block text-xs font-bold text-slate-300">Seu Nome</label>
                  <input
                    type="text"
                    required
                    placeholder="Ex: Lucas Gabriel"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    disabled={spinning}
                    className="w-full rounded-2xl border border-slate-700 bg-slate-900 px-4 py-3 text-sm text-white focus:border-pink-400 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="mb-1 block text-xs font-bold text-slate-300">E-mail</label>
                  <input
                    type="email"
                    required
                    placeholder="seu@email.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    disabled={spinning}
                    className="w-full rounded-2xl border border-slate-700 bg-slate-900 px-4 py-3 text-sm text-white focus:border-pink-400 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="mb-1 block text-xs font-bold text-slate-300">WhatsApp (Opcional)</label>
                  <input
                    type="text"
                    placeholder="(75) 98155-8007"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    disabled={spinning}
                    className="w-full rounded-2xl border border-slate-700 bg-slate-900 px-4 py-3 text-sm text-white focus:border-pink-400 focus:outline-none"
                  />
                </div>

                <button
                  type="submit"
                  disabled={spinning || !prizes.length}
                  className="w-full rounded-2xl bg-gradient-to-r from-pink-500 via-purple-500 to-amber-400 py-4 text-base font-black uppercase tracking-wider text-slate-950 shadow-xl shadow-pink-500/25 hover:scale-[1.02] transition-all disabled:opacity-60"
                >
                  {spinning ? "GIRANDO A ROLETA..." : "🎯 GIRAR ROLETA AGORA!"}
                </button>
              </form>

              {/* Won Prize Popup Card */}
              {wonPrize && (
                <div className="mt-6 rounded-2xl border-2 border-emerald-400 bg-emerald-950/60 p-5 text-center animate-fadeIn">
                  <div className="text-3xl">🎉</div>
                  <div className="text-xs font-bold uppercase tracking-wider text-emerald-300 mt-1">
                    VOCÊ GANHOU:
                  </div>
                  <h4 className="text-xl font-black text-white mt-0.5">{wonPrize.title}</h4>
                  <div className="mt-1 text-2xl font-black text-amber-400">{wonPrize.value}</div>

                  {wonPrize.couponCode && (
                    <div className="mt-4 flex items-center justify-between rounded-xl bg-slate-950 p-2.5 border border-emerald-400/40">
                      <code className="text-sm font-mono font-black text-white tracking-widest">
                        {wonPrize.couponCode}
                      </code>
                      <button
                        type="button"
                        onClick={() => handleCopyCoupon(wonPrize.couponCode)}
                        className="flex items-center gap-1 rounded-lg bg-emerald-400 px-3 py-1.5 text-xs font-black text-slate-950 hover:bg-emerald-300 transition-colors"
                      >
                        {copied ? <Check size={14} /> : <Copy size={14} />}
                        <span>{copied ? "Copiado!" : "Copiar"}</span>
                      </button>
                    </div>
                  )}
                  <p className="mt-2 text-[11px] text-slate-300">
                    Utilize este cupom no checkout ou no sorteio da Sonic Vendas!
                  </p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </main>
  );
}
