// Sound notification system using Web Audio API synthesis
// Guarantees zero latency, zero broken external audio URLs, and works on all browsers

export type SoundEventType =
  | "new_order"
  | "order_shipped"
  | "order_delivered"
  | "order_cancelled"
  | "new_message"
  | "payment_confirmed"
  | "order_preparing";

export interface SoundConfig {
  name: string;
  description: string;
  type: SoundEventType;
}

export const SOUND_DEFINITIONS: SoundConfig[] = [
  {
    type: "new_order",
    name: "Novo Pedido (Caixa Registradora / Alerta ADM)",
    description: "Som de caixa registradora e sino triunfante para quando um novo pedido é registrado.",
  },
  {
    type: "payment_confirmed",
    name: "Pagamento Confirmado (Sucesso Duplo)",
    description: "Harmonia de vitória e confirmação segura de pagamento aprovado.",
  },
  {
    type: "order_shipped",
    name: "Pedido Enviado (Trânsito & Envio)",
    description: "Som dinâmico ascendente indicando que a mercadoria está a caminho.",
  },
  {
    type: "order_delivered",
    name: "Pedido Entregue (Comemoração Suave)",
    description: "Fanfarra alegre e harmônica avisando que a entrega foi concluída.",
  },
  {
    type: "order_preparing",
    name: "Pedido em Preparação",
    description: "Pulso rítmico agradável avisando que o produto está sendo separado.",
  },
  {
    type: "order_cancelled",
    name: "Pedido Cancelado",
    description: "Tom suave descendente informando cancelamento ou estorno.",
  },
  {
    type: "new_message",
    name: "Nova Mensagem (Chat Bubble Pop)",
    description: "Chime pop cristalino e amigável quando chega mensagem no chat.",
  },
];

let globalAudioCtx: AudioContext | null = null;

function getAudioContext(): AudioContext | null {
  if (typeof window === "undefined") return null;
  const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
  if (!AudioCtx) return null;
  if (!globalAudioCtx || globalAudioCtx.state === "closed") {
    globalAudioCtx = new AudioCtx();
  }
  if (globalAudioCtx.state === "suspended") {
    globalAudioCtx.resume().catch(() => {});
  }
  return globalAudioCtx;
}

export function playSound(type: SoundEventType, volumePercent: number = 80) {
  const ctx = getAudioContext();
  if (!ctx) return;

  const masterVol = Math.max(0, Math.min(1, volumePercent / 100));
  const now = ctx.currentTime;

  try {
    switch (type) {
      case "new_order": {
        // Cash register chime: coin clink + chord
        [523.25, 659.25, 783.99, 1046.5].forEach((freq, idx) => {
          const osc = ctx.createOscillator();
          const gain = ctx.createGain();
          osc.type = "triangle";
          osc.frequency.setValueAtTime(freq, now + idx * 0.06);
          gain.gain.setValueAtTime(0.18 * masterVol, now + idx * 0.06);
          gain.gain.exponentialRampToValueAtTime(0.001, now + idx * 0.06 + 0.35);
          osc.connect(gain);
          gain.connect(ctx.destination);
          osc.start(now + idx * 0.06);
          osc.stop(now + idx * 0.06 + 0.35);
        });
        break;
      }

      case "payment_confirmed": {
        // Double harp ping: 880Hz -> 1318Hz
        [880, 1174.66, 1318.51, 1760].forEach((freq, idx) => {
          const osc = ctx.createOscillator();
          const gain = ctx.createGain();
          osc.type = "sine";
          osc.frequency.setValueAtTime(freq, now + idx * 0.08);
          gain.gain.setValueAtTime(0.22 * masterVol, now + idx * 0.08);
          gain.gain.exponentialRampToValueAtTime(0.001, now + idx * 0.08 + 0.45);
          osc.connect(gain);
          gain.connect(ctx.destination);
          osc.start(now + idx * 0.08);
          osc.stop(now + idx * 0.08 + 0.45);
        });
        break;
      }

      case "order_shipped": {
        // Rising swoosh pulse
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = "sine";
        osc.frequency.setValueAtTime(320, now);
        osc.frequency.exponentialRampToValueAtTime(840, now + 0.25);
        gain.gain.setValueAtTime(0.16 * masterVol, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.3);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(now);
        osc.stop(now + 0.3);
        break;
      }

      case "order_delivered": {
        // Triumphant victory major triad (C-E-G-C)
        [523.25, 659.25, 783.99, 1046.5, 1318.51].forEach((freq, idx) => {
          const osc = ctx.createOscillator();
          const gain = ctx.createGain();
          osc.type = "triangle";
          osc.frequency.setValueAtTime(freq, now + idx * 0.09);
          gain.gain.setValueAtTime(0.2 * masterVol, now + idx * 0.09);
          gain.gain.exponentialRampToValueAtTime(0.001, now + idx * 0.09 + 0.5);
          osc.connect(gain);
          gain.connect(ctx.destination);
          osc.start(now + idx * 0.09);
          osc.stop(now + idx * 0.09 + 0.5);
        });
        break;
      }

      case "order_preparing": {
        // Double warm pulse
        [440, 554.37].forEach((freq, idx) => {
          const osc = ctx.createOscillator();
          const gain = ctx.createGain();
          osc.type = "sine";
          osc.frequency.setValueAtTime(freq, now + idx * 0.12);
          gain.gain.setValueAtTime(0.15 * masterVol, now + idx * 0.12);
          gain.gain.exponentialRampToValueAtTime(0.001, now + idx * 0.12 + 0.25);
          osc.connect(gain);
          gain.connect(ctx.destination);
          osc.start(now + idx * 0.12);
          osc.stop(now + idx * 0.12 + 0.25);
        });
        break;
      }

      case "order_cancelled": {
        // Descending low alert (580Hz -> 280Hz)
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = "sawtooth";
        osc.frequency.setValueAtTime(480, now);
        osc.frequency.linearRampToValueAtTime(240, now + 0.3);
        gain.gain.setValueAtTime(0.12 * masterVol, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.35);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(now);
        osc.stop(now + 0.35);
        break;
      }

      case "new_message": {
        // Crisp message pop (700Hz -> 1050Hz)
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = "sine";
        osc.frequency.setValueAtTime(698.46, now);
        osc.frequency.exponentialRampToValueAtTime(1046.5, now + 0.1);
        gain.gain.setValueAtTime(0.18 * masterVol, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.18);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(now);
        osc.stop(now + 0.18);
        break;
      }
    }
  } catch {
    // Audio synthesis failure caught gracefully
  }
}
